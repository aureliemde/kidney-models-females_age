# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# # Compute electro-convective-diffusive fluxes  

import numpy as np
from numba import njit

from values import *
from glo import *

@njit
def compute_ecd_fluxes(C, EP, area, sig, h, Jvol):
    Jsol = np.zeros((NS, NC, NC))
    delmu = np.zeros((NS, NC, NC))
    dmu = np.zeros((NS, NC))

    eps = 1.0e-6  # For exponential (Peclet) terms

    # Compute electrochemical potential
    for i in range(NS):
        for k in range(NC):
            cval = np.abs(C[i, k])
            if cval < eps:
                cval = eps
            dmu[i, k] = RT * np.log(cval) + zval[i] * F * EPref * EP[k]

    # Begin flux calculation
    for i in range(NS):
        for k in range(NC - 1):
            for l in range(k + 1, NC):
                XI = zval[i] * F * EPref / RT * (EP[k] - EP[l])
                dint = np.exp(-XI)

                if np.abs(1.0 - dint) < eps:
                    flux = area[k, l] * h[i, k, l] * (C[i, k] - C[i, l])
                else:
                    flux = area[k, l] * h[i, k, l] * XI * (C[i, k] - C[i, l] * dint) / (1.0 - dint)

                # Convective component
                concdiff = C[i, k] - C[i, l]
                if np.abs(concdiff) > eps and C[i, l] > 0:
                    concmean = concdiff / np.log(np.abs(C[i, k] / C[i, l]))
                    dimless = (Pfref * Vwbar * Cref) / href
                    convect = (1.0 - sig[i, k, l]) * concmean * Jvol[k, l] * dimless
                    flux += convect

                Jsol[i, k, l] = flux
                delmu[i, k, l] = dmu[i, k] - dmu[i, l]

    return Jsol, delmu
