# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# NCX exchanger module

#---------------------------------------------------------------------72
# NCX EXCHANGER AT BASOLATERAL MEMBRANE OF CELL
# n is for Na, c is for Ca
# p (or prime) is for the luminal compartment (M)
# pp (or double prime) is for the cytosolic compartment (I)
#---------------------------------------------------------------------72

import numpy as np

from values import *    

def compute_ncx_fluxes(var_ncx):
    
    nai = var_ncx[1-1]  # Na+
    nao5 = var_ncx[2-1]
    nao6 = var_ncx[3-1]
    cai = var_ncx[4-1]  # Ca2+
    cao5 = var_ncx[5-1]
    cao6 = var_ncx[6-1]
    epi = var_ncx[7-1]
    epo5 = var_ncx[8-1]
    epo6 = var_ncx[9-1]
    area5 = var_ncx[10-1]
    area6 = var_ncx[11-1]
    xNCX = var_ncx[12-1]
    
    fmod = ((cai/dKm_ncx) ** 2) / (1.0 + ((cai/dKm_ncx) ** 2))
    
    phir5 = np.exp((gamma_ncx - 1.0) * F * EPref / RT * (epi - epo5))
    phir6 = np.exp((gamma_ncx - 1.0) * F * EPref / RT * (epi - epo6))
    phif5 = np.exp(gamma_ncx * F * EPref / RT * (epi - epo5))
    phif6 = np.exp(gamma_ncx * F * EPref / RT * (epi - epo6))

    g5 = ( (nao5**3)*cai + (nai**3)*cao5 + (dKmNao**3)*cai + (nai**3)*dKmCao
          + (dKmNai**3)*cao5*(1.0 + cai/dKmCai)
          + (nao5**3)*dKmCai*(1 + (nai/dKmNai)**3) )

    g6 = ( (nao6**3)*cai + (nai**3)*cao6 + (dKmNao**3)*cai + (nai**3)*dKmCao 
          + (dKmNai**3)*cao6*(1.0 + cai/dKmCai) 
          + (nao6**3)*dKmCai*(1 + (nai/dKmNai)**3) )

    fac5 = ( (phir5*(nao5**3)*cai -
            phif5*(nai**3)*cao5)/g5/(1 + dKsat_ncx * phir5) )

    fac6 = (phir6*(nao6**3)*cai - phif6*(nai**3)*cao6)/g6/(1 + dKsat_ncx * phir6)

    dJNCXca5 = area5 * xNCX * fmod * fac5
    dJNCXca6 = area6 * xNCX * fmod * fac6

    return dJNCXca5, dJNCXca6
