# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# NHE3 exchanger modules
#---------------------------------------------------------------------72
# NHE3 EXCHANGER AT LUMINAL MEMBRANE OF CELL
# n is for Na, c is for Cl
# p (or prime) is for the luminal compartment (M)
# pp (or double prime) is for the cytosolic compartment (I)
#---------------------------------------------------------------------72

import numpy as np

from numba import njit

from values import *

@njit      
def compute_nhe3_fluxes(C, area, xNHE3):

    # output
    ap = C[0, 0]  # Na+
    bp = C[11, 0]  # H+
    cp = C[10, 0]  # NH4+
    
    app = C[0, 1]
    bpp = C[11, 1]
    cpp = C[10, 1]

    alp = ap / dKaNH
    alpp = app / dKaNH
    betap = bp / dKbNH
    betapp = bpp / dKbNH
    gamp = cp / dKcNH
    gampp = cpp / dKcNH

    fmod = fMNH * C[11, 1] / (C[11, 1] + dKINH)

    sum1 = (1 + alp + betap + gamp) * (PaNH * alpp + PbNH * betapp + PcNH * gampp)
    sum2 = (1 + alpp + betapp + gampp) * (PaNH * alp + PbNH * betap + PcNH * gamp)
    sum_tot = sum1 + sum2

    termNaH = fmod * PaNH * PbNH * (alp * betapp - alpp * betap)
    termNaNH4 = fmod * PaNH * PcNH * (alp * gampp - alpp * gamp)
    termHNH4 = fmod * PbNH * PcNH * (betap * gampp - betapp * gamp)

    dJNHEsod = area * xNHE3 * (termNaH + termNaNH4) / sum_tot
    dJNHEprot = area * xNHE3 * (-termNaH + termHNH4) / sum_tot
    dJNHEamm = area * xNHE3 * (-termNaNH4 - termHNH4) / sum_tot
    
    return dJNHEsod, dJNHEprot, dJNHEamm
