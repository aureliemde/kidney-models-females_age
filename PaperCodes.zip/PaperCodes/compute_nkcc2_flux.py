# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
# This subroutine computes K, Cl, and NH4 fluxes across basolateral
# KCC4 cotransporters
#---------------------------------------------------------------------72

import numpy as np

from numba import njit

from values import *
from glo import *
    
@njit  
def compute_nkcc2_flux(C, area, xNKCC2, bn2, bk2, bc2, bm2, 
                       popnkcc, pnkccp, pnmccp, poppnkcc, pnkccpp, pnmccpp):
    
    alp1 = C[0, 0] / bn2
    alp2 = C[0, 1] / bn2
    bet1 = C[1, 0] / bk2
    bet2 = C[1, 1] / bk2
    gam1 = C[2, 0] / bc2
    gam2 = C[2, 1] / bc2
    dnu1 = C[10, 0] / bm2
    dnu2 = C[10, 1] / bm2

    sig1 = 1.0 + alp1 + alp1 * gam1 * (1.0 + bet1 + bet1 * gam1 + dnu1 + dnu1 * gam1)
    sig2 = 1.0 + gam2 * (1.0 + bet2 + bet2 * gam2 + bet2 * gam2 * alp2 + dnu2 + dnu2 * gam2 + dnu2 * gam2 * alp2)

    rho1 = popnkcc + pnkccp * alp1 * bet1 * (gam1**2) + pnmccp * alp1 * dnu1 * (gam1**2)
    rho2 = poppnkcc + pnkccpp * alp2 * bet2 * (gam2**2) + pnmccpp * alp2 * dnu2 * (gam2**2)

    bigsum = sig1 * rho2 + sig2 * rho1

# Flux calculations across the lateral membrane
    t1 = poppnkcc * pnkccp * alp1 * bet1 * (gam1**2) - popnkcc * pnkccpp * alp2 * bet2 * (gam2**2)
    t2 = poppnkcc * pnmccp * alp1 * dnu1 * (gam1**2) - popnkcc * pnmccpp * alp2 * dnu2 * (gam2**2)
    t3 = pnmccpp * alp2 * dnu2 * (gam2**2) * pnkccp * alp1 * bet1 * (gam1**2)
    t4 = pnmccp * alp1 * dnu1 * (gam1**2) * pnkccpp * alp2 * bet2 * (gam2**2)

    dJnNKCC2 = xNKCC2 * area * (t1 + t2) / bigsum
    dJkNKCC2 = xNKCC2 * area * (t1 + t3 - t4) / bigsum
    dJmNKCC2 = xNKCC2 * area * (t2 + t4 - t3) / bigsum
    dJcNKCC2 = 2 * dJnNKCC2

    return dJnNKCC2, dJkNKCC2, dJcNKCC2, dJmNKCC2
