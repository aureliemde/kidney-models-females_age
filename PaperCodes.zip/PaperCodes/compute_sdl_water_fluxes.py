# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
# COMPUTE SDL WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# The hydraulic and oncotic pressures are made non-dimensional
# by dividing by RT*Cref

import numpy as np

from numba import njit

from values import *
from glo import *
from defs import * 
 
@njit 
def compute_sdl_water_fluxes(C, PM, Vol, Vol0, area, sig, dLPV, PTinitVol):
    
# outputs
    Jvol = np.zeros((NC,NC))
    
# local variables
    PRES = np.zeros(NC)
    ONC = np.zeros(NC)
    
# The hydraulic and oncotic pressures are made non-dimensional
# by dividing by RT*Cref

    PRES[1-1] = PM / (RTosm * Cref)
    PRES[6-1] = PbloodPT / (RTosm * Cref)
    ONC[1-1] = LumImperm * PTinitVol / Vol[1-1]
    ONC[6-1] = BathImperm

    OSM = 0.0
    for J in range(1, NS2 + 1):
        OSM += sig[J-1, 1-1, 6-1] * (C[J-1, 1-1] - C[J-1, 6-1])

    Jvol[1-1, 6-1] = ( (area[1-1, 2-1] * dLPV[1-1, 2-1] + area[1-1, 5-1] * dLPV[1-1, 5-1]) * 
                 (PRES[1-1] - PRES[6-1] - ONC[1-1] + ONC[6-1] - OSM) )
    Jvol[6-1, 1-1] = -Jvol[1-1, 6-1]

    return Jvol
