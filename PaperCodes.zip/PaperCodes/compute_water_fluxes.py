# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

import numpy as np

from numba import njit

from values import *
from glo import *
from defs import * 

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# The hydraulic and oncotic pressures are made non-dimensional
# by dividing by RT*Cref
           
@njit                
def compute_water_fluxes(C, PM, PB, Vol, Vol0, VolEinit, VolPinit, CPimpref, 
                         VolAinit, CAimpref, VolBinit, CBimpref, area, sig, dLPV, compl, PTinitVol):
    
# outputs
    Jvol = np.zeros((NC, NC))
    
# local variables
    PRES = np.zeros(NC)
    ONC = np.zeros(NC)
    
# The hydraulic and oncotic pressures are made non-dimensional
# by dividing by RT*Cref
    PRES[0] = PM / (RTosm * Cref)
    PRES[1] = PRES[0]
    PRES[2] = PRES[0]
    PRES[3] = PRES[0]
    PRES[5] = PbloodPT / (RTosm * Cref)
    
    PRES[4] = PRES[5] + (Vol[4] / VolEinit - 1.0) / (compl) / (RTosm * Cref)

    ONC[0] = LumImperm * PTinitVol / Vol[0]
    ONC[1] = CPimpref * VolPinit / Vol[1]
    
    ONC[2] = 0.0
    ONC[3] = 0.0
    
    ONC[4] = 0.0
    ONC[5] = BathImperm

    for K in range(1, NC-1 + 1):
        for L in range(K+1, NC + 1):
            OSM = 0.0
            for J in range(1, NS2 + 1):
                if J < 13 or J > 14:  # Adjusting for zero-based index in Python
                    OSM += sig[J-1, K-1, L-1] * (C[J-1, K-1] - C[J-1, L-1])
                    
            Jvol[K-1, L-1] = area[K-1, L-1] * dLPV[K-1, L-1] * (PRES[K-1] - PRES[L-1] - ONC[K-1] + ONC[L-1] - OSM)
    
    for K in range(1, NC-1 + 1):
        for L in range(K+1, NC + 1):
            Jvol[L-1, K-1] = -Jvol[K-1, L-1]
    
    return Jvol
