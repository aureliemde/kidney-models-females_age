# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
# *************************** H-K-ATPase ***************************
#---------------------------------------------------------------------72
# This subroutine computes the H-K-ATPase concentration variables
# The units for the kinetic constants are M (moles) - per Alan's email

import numpy as np

from numba import njit

from values import *

@njit 
def fatpase(n,hkconc):
    
    Amat = np.zeros((n,n))

    for i in range(1, n + 1):
        Amat[1-1, i-1] = 1.0
        
        for j in range(2, n + 1):
            Amat[j-1, i-1] = 0.0
            
# Fix reaction rates

    dkf1 = 1.30e7
    dkb1 = 6.50
    dkf2a = 8.90e3
    dkb2a = 7.30e4
    dkf2b = 8.90e3
    dkb2b = 7.30e4
    dkf3a = 5.30e9
    dkb3a = 6.60e2
    dkf3b = 5.30e9
    dkb3b = 6.60e2
    dkf4 = 5.0e1
    dkb4 = 2.50e6
    dkf5 = 4.0e1
    dkb5 = 2.0e2
    dkf6a = 5.0e7
    dkb6a = 8.0e12
    dkf6b = 5.0e7
    dkb6b = 8.0e12
    dkf7a = 2.60e10
    dkb7a = 1.50e8
    dkf7b = 2.60e10
    dkb7b = 1.50e8
    dkf8 = 5.40e1
    dkb8 = 3.20e1
    dkf9 = 1.75
    dkb9 = 3.50e1
    dkf10 = 5.0e4
    dkb10 = 5.0e1
    dkf11 = 5.0e2
    dkb11 = 5.0

# Fix cellular concentrations of ATP, ADP, Pi
    catp = 2.0*1e-3  # convert from mM to M
    cadp = 0.04*1e-3
    cpi = 5.0*1e-3

# Assign 14 H-K-ATPase variables
# species 1 = K2-E1, 2 = K2-E1-ATP, 3 = K-E1-ATP, 4 = E1-ATP, 5 = H-E1-AT!
# species 6 = H2-E1-ATP, 7 = H2-E1-P, 8=H2-E2-P, 9 = H-E2-P, 10 = E2-P
# species 11 = K-E2-P, 12 = K2-E2-P, 13 = K2-E2, 14 = K2-E2-ATP
    kin = hkconc[1-1]*1e-3  # convert from mM to M
    kout = hkconc[2-1]*1e-3
    hin = hkconc[3-1]*1e-3
    hout = hkconc[4-1]*1e-3

# Determine matrix to inverse
    Amat[2-1, 2-1] = dkf2a
    Amat[2-1, 3-1] = -(dkb2a * kin + dkf2b)
    Amat[2-1, 4-1] = dkb2b * kin
    Amat[3-1, 3-1] = dkf2b
    Amat[3-1, 4-1] = -(dkb2b * kin + dkf3a * hin)
    Amat[3-1, 5-1] = dkb3a
    Amat[4-1, 4-1] = dkf3a * hin
    Amat[4-1, 5-1] = -(dkb3a + dkf3b * hin)
    Amat[4-1, 6-1] = dkb3b
    Amat[5-1, 5-1] = dkf3b * hin
    Amat[5-1, 6-1] = -(dkb3b + dkf4)
    Amat[5-1, 7-1] = dkb4 * cadp
    Amat[6-1, 6-1] = dkf4
    Amat[6-1, 7-1] = -(dkb4 * cadp + dkf5)
    Amat[6-1, 8-1] = dkb5
    Amat[7-1, 7-1] = dkf5
    Amat[7-1, 8-1] = -(dkb5 + dkf6a)
    Amat[7-1, 9-1] = dkb6a * hout
    Amat[8-1, 8-1] = dkf6a
    Amat[8-1, 9-1] = -(dkb6a * hout + dkf6b)
    Amat[8-1, 10-1] = dkb6b * hout
    Amat[9-1, 9-1] = dkf6b
    Amat[9-1, 10-1] = -(dkb6b * hout + dkf7a * kout)
    Amat[9-1, 11-1] = dkb7a
    Amat[10-1, 10-1] = dkf7a * kout
    Amat[10-1, 11-1] = -(dkb7a + dkf7b * kout)
    Amat[10-1, 12-1] = dkb7b
    Amat[11-1, 11-1] = dkf7b * kout
    Amat[11-1, 12-1] = -(dkb7b + dkf8)
    Amat[11-1, 13-1] = dkb8 * cpi
    Amat[12-1, 1-1] = dkb9
    Amat[12-1, 12-1] = dkf8
    Amat[12-1, 13-1] = -(dkb8 * cpi + dkf9 + dkf10 * catp)
    Amat[12-1, 14-1] = dkb10
    Amat[13-1, 2-1] = dkb11
    Amat[13-1, 13-1] = dkf10 * catp
    Amat[13-1, 14-1] = -(dkb10 + dkf11)
    Amat[14-1, 1-1] = dkf1 * catp
    Amat[14-1, 2-1] = -(dkb1 + dkf2a + dkb11)
    Amat[14-1, 3-1] = dkb2a * kin
    Amat[14-1, 14-1] = dkf11
        
    return Amat
    