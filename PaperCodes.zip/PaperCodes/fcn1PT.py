# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This subroutine yields the non-linear equations to be solved at the inlet
# in order to determine the concentrations, volumes, and EP
# in P, A, B, and E
# It is used to compute values at the entry of the PT.
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 
    

def fcn1PT(n, x, iflag, numpar, pars, pt, idid, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    fvec = np.zeros(n)
        
    S = np.zeros(NUPT)
    y = np.zeros(NDPT)
    
    C = np.zeros((NSPT, NC))
    Vol = np.zeros(NC)
    EP = np.zeros(NC)
    ph = np.zeros(NC)
    
    dkd = np.zeros(NC)
    dkh = np.zeros(NC)
    
#  dcompl, dtorq: compliance and torque effects
    
# Assign concentrations, volumes, and potentials in lumen and blood
    C[:, 0] = pt[0].conc[:, 0]
    C[:, 5] = pt[0].conc[:, 5]
    ph[0] = -np.log10(C[12-1, 1-1] / 1.0e3) 
    ph[5] = -np.log10(C[12-1, 6-1] / 1.0e3)
    
    EP[5] = pt[0].ep[5]
    
    VolEinit = pars[0]
    VolPinit = pars[1]
    CPimpref = pars[2]
    CPbuftot1 = pars[3]
    dkd[2-1] = pars[5-1]
    dkd[5-1] = pars[6-1]
    dkh[2-1] = pars[7-1]
    dkh[5-1] = pars[8-1]
    dcompl = pars[8]
    dtorq = pars[9]

# Assign concentrations, volumes, and potentials in P, A, B, and E
    for i in range(1, NSPT + 1):
        C[i-1, 2-1] = x[1 + 2 * (i-1) -1]
        C[i-1, 5-1] = x[2 + 2 * (i-1) -1]
    
    ph[1] = -np.log10(C[11, 1] / 1.0e3) 
    ph[4] = -np.log10(C[11, 4] / 1.0e3)
    
    Vol[1] = x[1 + 2 * NSPT -1]
    Vol[4] = x[2 + 2 * NSPT -1]
    EP[0] = x[3 + 2 * NSPT -1]
    EP[1] = x[4 + 2 * NSPT -1]
    EP[4] = x[5 + 2 * NSPT -1]
    
#---------------------------------------------------------------------72
# Initialize source terms
#---------------------------------------------------------------------72
    
    for k in range(1, NUPT + 1):
        S[k-1] = 0.0
        fvec[k-1] = 0.0
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR SOLUTE I IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    for i in range(1, NSPT + 1):
        y[1 + 3 * (i-1) -1] = pt[0].conc[i-1, 1-1]
        y[2 + 3 * (i-1) -1] = C[i-1, 2-1]
        y[3 + 3 * (i-1) -1] = C[i-1, 5-1]
    
    Vol0 = pt[0].vol[0]
    y[1 + 3 * NSPT -1] = Vol0
    y[2 + 3 * NSPT -1] = Vol[1]
    y[3 + 3 * NSPT -1] = Vol[4]
    y[4 + 3 * NSPT -1] = EP[0]
    y[5 + 3 * NSPT -1] = EP[1]
    y[6 + 3 * NSPT -1] = EP[4]
    y[7 + 3 * NSPT -1] = PMinitPT

    from qflux1PT import qflux1PT
    Jvol_3, Jsol_3 = qflux1PT(y, C[:, 6-1], EP[6-1], pt, Vol0, dcompl, dtorq, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    
    Jvol = Jvol_3
    Jsol = Jsol_3
    
    for i in range(1, NSPT + 1):
        S[1 + 2 * (i-1) -1] = -Jsol[i-1, 1-1, 2-1] + Jsol[i-1, 2-1, 5-1] + Jsol[i-1, 2-1, 6-1]
        S[2 + 2 * (i-1) -1] = -Jsol[i-1, 1-1, 5-1] - Jsol[i-1, 2-1, 5-1] + Jsol[i-1, 5-1, 6-1]
   
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    S[1 + 2 * NSPT -1] = -Jvol[0, 1] + Jvol[1, 4] + Jvol[1, 5]
    S[2 + 2 * NSPT -1] = -Jvol[0, 4] - Jvol[1, 4] + Jvol[4, 5]
    
#---------------------------------------------------------------------72
# Convert to equations of the form F(X) = 0
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# For I = 1-3, and 9 (non-reacting solutes)
#---------------------------------------------------------------------72
    
    for m in range(1, 6+1):
        fvec[m-1] = S[m-1]
    
    fvec[16] = S[16]
    fvec[17] = S[17]
    
#---------------------------------------------------------------------72
# For glucose, with consumption term linked to Na,K-ATPase activity
#---------------------------------------------------------------------72

    Pumpactivity = pt[0].FNaK / (href * Cref * np.pi * pt[0].diam * 60 / 10 * 1.0e9)
    Gluconsumption = Pumpactivity / (pt[0].TQ * 6)
    fvec[28] = S[28] + Gluconsumption * 0  # Multiply by 0 to not account for consumption
    fvec[29] = S[29]
    
#---------------------------------------------------------------------72
# For Ca2+
#---------------------------------------------------------------------72

    fvec[30] = S[30]
    fvec[31] = S[31]
    
#---------------------------------------------------------------------72
# For CO2/HCO3/H2CO3
#---------------------------------------------------------------------72
    
    facnd = Vref / href
    
    fvec[6] = S[6] + S[8] + S[10]
    fvec[7] = S[7] + S[9] + S[11]
    fvec[8] = ph[1] - pKHCO3 - np.log10(abs(C[3, 1] / C[4, 1]))
    fvec[9] = ph[4] - pKHCO3 - np.log10(abs(C[3, 4] / C[4, 4]))
    fvec[10] = S[10] + Vol[1] * (dkh[1] * C[5, 1] - dkd[1] * C[4, 1]) * facnd
    fvec[11] = S[11] + max(Vol[4], VolEinit) * (dkh[4] * C[5, 4] - dkd[4] * C[4, 4]) * facnd
  
#---------------------------------------------------------------------72
# For HPO4(2-)/H2PO4(-)
#---------------------------------------------------------------------72

    fvec[12] = S[12] + S[14]
    fvec[13] = S[13] + S[15]
    fvec[14] = ph[1] - pKHPO4 - np.log10(abs(C[6, 1] / C[7, 1])) 
    fvec[15] = ph[4] - pKHPO4 - np.log10(abs(C[6, 4] / C[7, 4]))
    
#---------------------------------------------------------------------72
# For NH3/NH4 with ammoniagenesis within lumen
#---------------------------------------------------------------------72
    
    if dcompl < 0:
        RMtorq = pt[0].diam / 2.0  # non-compliant tubule
    else:
        RMtorq = torqR * (1.0 + torqvm * (PMinitPT - PbloodPT))
    
    factor1 = 8.0 * visc * (Vol0 * Vref) * torqL / (RMtorq ** 2)
    factor2 = 1.0 + (torqL + torqd) / RMtorq + 0.50 * ((torqL / RMtorq) ** 2)
    Torque = factor1 * factor2
    
    if dtorq < 0:
        Scaletorq = 1.0  # No torque effect on transporter density
    else:
        Scaletorq = 1.0 + TS * pt[0].scaleT * (Torque / pt[0].TM0 - 1.0)
    
    Scaletorq = max(Scaletorq, 0.001)  # To avoid issues with negative values
    
# The rate of ammoniagenesis also scales with the torque
    if idid == 0:
        Qnh4 = pt[0].qnh4 * Scaletorq
    else:
        Qnh4 = 0.0
    
    fvec[18] = S[18] + S[20] - Qnh4
    fvec[19] = S[19] + S[21]
    fvec[20] = ph[1] - pKNH3 - np.log10(abs(C[9, 1] / C[10, 1]))
    fvec[21] = ph[4] - pKNH3 - np.log10(abs(C[9, 4] / C[10, 4]))
    
#---------------------------------------------------------------------72
# For HCO2-/H2CO2
#---------------------------------------------------------------------72
    
    fvec[24] = S[24] + S[26]
    fvec[25] = S[25] + S[27]
    fvec[26] = ph[1] - pKHCO2 - np.log10(abs(C[12, 1] / C[13, 1]))
    fvec[27] = ph[4] - pKHCO2 - np.log10(abs(C[12, 4] / C[13, 4]))
    
#---------------------------------------------------------------------72
# For pH
#---------------------------------------------------------------------72
    
    fvec[22] = S[22] + S[20] - S[12] - S[6] - S[24]
    fvec[23] = S[23] + S[21] - S[13] - S[7] - S[25]
    
#---------------------------------------------------------------------72
# For volume
#---------------------------------------------------------------------72
    
    fvec[1 + 2 * NSPT -1] = S[1 + 2 * NSPT -1]
    fvec[2 + 2 * NSPT -1] = S[2 + 2 * NSPT -1]
    
#---------------------------------------------------------------------72
# For EP, need to satisfy electroneutrality
#---------------------------------------------------------------------72
    
    volPrat = VolPinit / Vol[1]
    CimpP = CPimpref * volPrat
    facP = np.exp(np.log(10.0) * (ph[1] - pKbuf))
    CbufP = CPbuftot1 * volPrat * facP / (facP + 1)
    
    elecP = zPimpPT * CimpP - CbufP
    elecE = 0.0
    
    for i in range(1, NSPT + 1):
        elecP += zval[i-1] * C[i-1, 2-1]
        elecE += zval[i-1] * C[i-1, 5-1]
    
    fvec[3 + 2 * NSPT -1] = elecP
    fvec[4 + 2 * NSPT -1] = elecE
    
    # Electroneutrality/Zero-current in lumen
    currM = 0.0
    
    for i in range(1, NSPT + 1):
        currM += zval[i-1] * (Jsol[i-1, 1-1, 2-1] + Jsol[i-1, 1-1, 5-1])
    
    fvec[5 + 2 * NSPT -1] = currM
     
    return fvec
