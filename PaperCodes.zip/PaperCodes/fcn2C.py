# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################
 
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This subroutine yields the non-linear equations to be solved at any
# point below the inlet, in order to determine the concentrations, volumes,
# and EP in P, A, B, E, and the lumen M.
# It is used to compute values below the entry to the CNT and the CCD.
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 

def fcn2C(n, x, iflag, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    fvec = np.zeros(n)
    S = np.zeros(n)
    
    y = np.zeros(n)
    
    Ca = np.zeros((NS, NC)) 
    Vola = np.zeros(NC)
    EPa = np.zeros(NC)
    pha = np.zeros(NC)
    
    Cb = np.zeros((NS, NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    Jva = np.zeros((NC,NC)) 
    Jsa = np.zeros((NS,NC,NC))
    
    Jvb = np.zeros((NC,NC)) 
    Jsb = np.zeros((NS,NC,NC))
    
    CaBT = np.zeros(NC)
    
# Ca(K) denotes the known concentrations at Lz (same with pH, Vol, EP)
# y is the associated vector, of known variables

# Cb(K) denotes the concentrations at Lz+1 (same with pH, Vol, EP)
# x is the associated vector, of unknown variables

#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials in peritubular solution
#---------------------------------------------------------------------72
  
    for J in range(1, NS + 1):
        Ca[J-1 , 6-1] = tube[Lz+1].conc[J-1, 6-1]
        Cb[J-1 , 6-1] = tube[Lz+1].conc[J-1, 6-1]
        
    EPa[6-1] = tube[Lz+1].ep[6-1]
    EPb[6-1] = tube[Lz+1].ep[6-1]
        
#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in P, A, B, E, and the lumen M at Lz+1
#---------------------------------------------------------------------

    for K in range(1, NC - 1 + 1):
        for I in range(1, NS2 + 1):
            Ca[I-1, K-1] = pars[I + (K-1)*NS -1]
            y[K + 5*(I-1) -1] = Ca[I-1, K-1]
        
        pha[K-1] = -np.log10(Ca[11, K-1] / 1.0e3)
        Vola[K-1] = pars[K + (NC-1)*NS - 1]  # where Vol(1) is the non-dim volume flux
        y[K + 5*NS2 -1] = Vola[K-1]
        EPa[K-1] = pars[K + (NC-1)*(NS+1) - 1]
        y[K + 5 + 5*NS2 - 1] = EPa[K-1]
    
    PMa = pars[1+ (NC-1)*(NS+2) -1]
    y[11 + 5*NS2 - 1] = PMa
    
    if idid == 6: 
        from qflux2C import qflux2C
        Jvol_3, Jsol_3 = qflux2C(y, tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    elif idid == 7: 
        from qflux2CCD import qflux2CCD
        Jvol_3, Jsol_3 = qflux2CCD(y, tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    Jva = Jvol_3
    Jsa = Jsol_3

#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in P, A, B, E, and the lumen M at Lz+1
#---------------------------------------------------------------------

    for I in range(1, NS2 + 1):
            Cb[I-1, 1-1] = x[1 + 5*(I-1) - 1]
            Cb[I-1, 2-1] = x[2 + 5*(I-1) - 1]
            Cb[I-1, 3-1] = x[3 + 5*(I-1) - 1]
            Cb[I-1, 4-1] = x[4 + 5*(I-1) - 1]
            Cb[I-1, 5-1] = x[5 + 5*(I-1) - 1]

    for K in range(1, NC + 1):
        phb[K-1] = -np.log10(Cb[11, K-1] / 1.0e3)
        Volb[K-1] = x[K+ 5*NS2 -1]
        EPb[K-1] = x[K+ 5+ 5*NS2 -1]
    
    PMb = x[11 + 5*NS2 - 1]  # Hydraulic pressure in lumen

    if idid == 6: 
        from qflux2C import qflux2C
        Jvol_4, Jsol_4 = qflux2C(x, tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    elif idid == 7: 
        from qflux2CCD import qflux2CCD
        Jvol_4, Jsol_4 = qflux2CCD(x, tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    Jvb = Jvol_4
    Jsb = Jsol_4
#---------------------------------------------------------------------72
# Initialize source terms
#---------------------------------------------------------------------72

    for K in range(1, n + 1):
        S[K-1] = 0
        fvec[K-1] = 0
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR FLOW OF SOLUTE I IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# (Vref/href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    coalesce = tube[Lz+1].coalesce
    
    Bm = np.pi * tube[Lz+1].diam * coalesce
    Am = np.pi * ( tube[Lz+1].diam ** 2) / 4.0 * coalesce
    
    for I in range(1, NS2 + 1):
        sumJsa = (Jsa[I-1,1-1,2-1] + Jsa[I-1,1-1,3-1] + Jsa[I-1,1-1,4-1] + Jsa[I-1,1-1,5-1])
        sumJsb = (Jsb[I-1,1-1,2-1] + Jsb[I-1,1-1,3-1] + Jsb[I-1,1-1,4-1] + Jsb[I-1,1-1,5-1])
        fsola = Vola[1-1] * Ca[I-1,1-1] * Vref / href
        fsolb = Volb[1-1] * Cb[I-1,1-1] * Vref / href
        S[1+ 5*(I-1) -1] = fsolb - fsola + Bm * tube[Lz+1].dimL * sumJsb / NZ

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR SOLUTE I IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    for i in range(1, NS2 + 1):
        S[2+ 5*(i-1) -1] = Jsb[i-1, 1, 4] + Jsb[i-1, 1, 5] - Jsb[i-1, 0, 1]  # solute I in P
        S[3+ 5*(i-1) -1] = Jsb[i-1, 2, 4] + Jsb[i-1, 2, 5] - Jsb[i-1, 0, 2]  # solute I in A
        S[4+ 5*(i-1) -1] = Jsb[i-1, 3, 4] + Jsb[i-1, 3, 5] - Jsb[i-1, 0, 3]  # solute I in B
        S[5+ 5*(i-1) -1] = -1 * Jsb[i-1, 0, 4] - Jsb[i-1, 1, 4] - Jsb[i-1, 2, 4] - Jsb[i-1, 3, 4] + Jsb[i-1, 4, 5]  # solute I in E
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME FLOW IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# Vref/(Pfref.Vwbar.Cref)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    fvmult = Pfref * Vwbar * Cref
    sumJva = (Jva[0, 1] + Jva[0, 2] + Jva[0, 3] + Jva[0, 4]) * fvmult
    sumJvb = (Jvb[0, 1] + Jvb[0, 2] + Jvb[0, 3] + Jvb[0, 4]) * fvmult
    fvola = Vola[0] * Vref
    fvolb = Volb[0] * Vref
    S[1 + 5*NS2 - 1] = fvolb - fvola + Bm * tube[Lz+1].dimL * sumJvb / NZ
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    S[2 + 5*NS2 -1] = Jvb[2-1, 5-1] + Jvb[2-1, 6-1] - Jvb[1-1, 2-1]  # volume in P
    S[3 + 5*NS2 -1] = Jvb[3-1, 5-1] + Jvb[3-1, 6-1] - Jvb[1-1, 3-1]  # in A
    S[4 + 5*NS2 -1] = Jvb[4-1, 5-1] + Jvb[4-1, 6-1] - Jvb[1-1, 4-1]  # in B
    S[5 + 5*NS2 -1] = -1 * Jvb[1-1, 5-1] - Jvb[2-1, 5-1] - Jvb[3-1, 5-1] - Jvb[4-1, 5-1] + Jvb[5-1, 6-1]  # in E

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Convert to equations of the form F(X) = 0
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# For I = 1-3 & 9 (non-reacting solutes)
#---------------------------------------------------------------------

    for M in range(1, 15 + 1): 
        fvec[M-1] = S[M-1]
        
    fvec[41 - 1] = S[41 - 1] # Urea - solute 9; index = 1+5*(9-1)
    fvec[42 - 1] = S[42 - 1]
    fvec[43 - 1] = S[43 - 1]
    fvec[44 - 1] = S[44 - 1]
    fvec[45 - 1] = S[45 - 1]
    
    fvec[71 - 1] = S[71 - 1] # Glucose - solute 15; index = 1+5*(15-1)
    fvec[72 - 1] = S[72 - 1]
    fvec[73 - 1] = S[73 - 1]
    fvec[74 - 1] = S[74 - 1]
    fvec[75 - 1] = S[75 - 1]
    
    fvec[76 -1] = S[76 -1] # Calcium - solute 16; index = 1+5*(16-1)
    fvec[77 -1] = S[77 -1]
    fvec[78 -1] = S[78 -1]
    fvec[79 -1] = S[79 -1]
    fvec[80 -1] = S[80 -1]
    
# HCO2-/H2CO2 equations modified below
    for M in range(13, 16 + 1): 
        fvec[1+ 5*(M-1) -1] = S[1+ 5*(M-1) -1]
        fvec[2+ 5*(M-1) -1] = S[2+ 5*(M-1) -1]
        fvec[3+ 5*(M-1) -1] = S[3+ 5*(M-1) -1]
        fvec[4+ 5*(M-1) -1] = S[4+ 5*(M-1) -1]
        fvec[5+ 5*(M-1) -1] = S[5+ 5*(M-1) -1]

#---------------------------------------------------------------------72
# For CO2/HCO3/H2CO3
# The dimensional factor for the kinetic term in the lumen is
# Am/Bm = Pi R^2 / 2 PI R = R / 2 = D / 4
#---------------------------------------------------------------------

    fvec[16-1] = S[16-1] + S[21-1] + S[26-1]
    fvec[17-1] = S[17-1] + S[22-1] + S[27-1]
    fvec[18-1] = S[18-1] + S[23-1] + S[28-1]
    fvec[19-1] = S[19-1] + S[24-1] + S[29-1]
    fvec[20-1] = S[20-1] + S[25-1] + S[30-1]
    fvec[21-1] = phb[1-1] - pKHCO3 - np.log10(Cb[4-1,1-1] / Cb[5-1,1-1])
    fvec[22-1] = phb[2-1] - pKHCO3 - np.log10(Cb[4-1,2-1] / Cb[5-1,2-1])
    fvec[23-1] = phb[3-1] - pKHCO3 - np.log10(Cb[4-1,3-1] / Cb[5-1,3-1])
    fvec[24-1] = phb[4-1] - pKHCO3 - np.log10(Cb[4-1,4-1] / Cb[5-1,4-1])
    fvec[25-1] = phb[5-1] - pKHCO3 - np.log10(Cb[4-1,5-1] / Cb[5-1,5-1])

    fkin1 = (tube[Lz+1].dkh[1-1] * Ca[6-1,1-1] - tube[Lz+1].dkd[1-1] * Ca[5-1,1-1])
    fkin2 = (tube[Lz+1].dkh[1-1] * Cb[6-1,1-1] - tube[Lz+1].dkd[1-1] * Cb[5-1,1-1])
    fvec[26-1] = S[26-1] + Am * tube[Lz+1].dimL * fkin2 / NZ / href

    facnd = Vref / href
    fvec[27-1] = S[27-1] + Volb[2-1] * (tube[Lz+1].dkh[2-1] * Cb[6-1,2-1] - tube[Lz+1].dkd[2-1] * Cb[5-1,2-1]) * facnd
    fvec[28-1] = S[28-1] + Volb[3-1] * (tube[Lz+1].dkh[3-1] * Cb[6-1,3-1] - tube[Lz+1].dkd[3-1] * Cb[5-1,3-1]) * facnd
    fvec[29-1] = S[29-1] + Volb[4-1] * (tube[Lz+1].dkh[4-1] * Cb[6-1,4-1] - tube[Lz+1].dkd[4-1] * Cb[5-1,4-1]) * facnd
    fvec[30-1] = S[30-1] + max(Volb[5-1], tube[Lz+1].volEinit) * (tube[Lz+1].dkh[5-1] * Cb[6-1,5-1] - tube[Lz+1].dkd[5-1] * Cb[5-1,5-1]) * facnd

#---------------------------------------------------------------------72
# For HPO4(2-)/H2PO4(-)
#---------------------------------------------------------------------72

    fvec[31-1] = S[31-1] + S[36-1]
    fvec[32-1] = S[32-1] + S[37-1]
    fvec[33-1] = S[33-1] + S[38-1]
    fvec[34-1] = S[34-1] + S[39-1]
    fvec[35-1] = S[35-1] + S[40-1]
    fvec[36-1] = phb[1-1] - pKHPO4 - np.log10(Cb[7-1,1-1] / Cb[8-1,1-1])
    fvec[37-1] = phb[2-1] - pKHPO4 - np.log10(Cb[7-1,2-1] / Cb[8-1,2-1])
    fvec[38-1] = phb[3-1] - pKHPO4 - np.log10(Cb[7-1,3-1] / Cb[8-1,3-1])
    fvec[39-1] = phb[4-1] - pKHPO4 - np.log10(Cb[7-1,4-1] / Cb[8-1,4-1])
    fvec[40-1] = phb[5-1] - pKHPO4 - np.log10(Cb[7-1,5-1] / Cb[8-1,5-1])

#---------------------------------------------------------------------72
# For NH3/NH4
#---------------------------------------------------------------------72

    fvec[46-1] = S[46-1] + S[51-1]
    fvec[47-1] = S[47-1] + S[52-1]
    fvec[48-1] = S[48-1] + S[53-1]
    fvec[49-1] = S[49-1] + S[54-1]
    fvec[50-1] = S[50-1] + S[55-1]
    fvec[51-1] = phb[1-1] - pKNH3 - np.log10(Cb[10-1,1-1] / Cb[11-1,1-1])
    fvec[52-1] = phb[2-1] - pKNH3 - np.log10(Cb[10-1,2-1] / Cb[11-1,2-1])
    fvec[53-1] = phb[3-1] - pKNH3 - np.log10(Cb[10-1,3-1] / Cb[11-1,3-1])
    fvec[54-1] = phb[4-1] - pKNH3 - np.log10(Cb[10-1,4-1] / Cb[11-1,4-1])
    fvec[55-1] = phb[5-1] - pKNH3 - np.log10(Cb[10-1,5-1] / Cb[11-1,5-1])

#---------------------------------------------------------------------72
# For HCO2-/H2CO2
#---------------------------------------------------------------------72

    fvec[61-1] = S[61-1] + S[66-1]
    fvec[62-1] = S[62-1] + S[67-1]
    fvec[63-1] = S[63-1] + S[68-1]
    fvec[64-1] = S[64-1] + S[69-1]
    fvec[65-1] = S[65-1] + S[70-1]
    
    fvec[66-1] = phb[1-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,1-1] / Cb[14-1,1-1]))
    fvec[67-1] = phb[2-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,2-1] / Cb[14-1,2-1]))
    fvec[68-1] = phb[3-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,3-1] / Cb[14-1,3-1]))
    fvec[69-1] = phb[4-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,4-1] / Cb[14-1,4-1]))
    fvec[70-1] = phb[5-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,5-1] / Cb[14-1,5-1]))

#---------------------------------------------------------------------72
# For pH
#---------------------------------------------------------------------72

    fvec[56-1] = S[56-1] + S[51-1] - S[16-1] - S[31-1] - S[61-1]  # pH in M
    fvec[57-1] = S[57-1] + S[52-1] - S[17-1] - S[32-1] - S[62-1]  # pH in P
    fvec[58-1] = S[58-1] + S[53-1] - S[18-1] - S[33-1] - S[63-1]  # pH in A
    fvec[59-1] = S[59-1] + S[54-1] - S[19-1] - S[34-1] - S[64-1]  # pH in B
    fvec[60-1] = S[60-1] + S[55-1] - S[20-1] - S[35-1] - S[65-1]  # pH in E

#---------------------------------------------------------------------72
# For volume
#---------------------------------------------------------------------

    fvec[1 + 5*NS2 -1] = S[1 + 5*NS2 -1]
    fvec[2 + 5*NS2 -1] = S[2 + 5*NS2 -1]
    fvec[3 + 5*NS2 -1] = S[3 + 5*NS2 -1]
    fvec[4 + 5*NS2 -1] = S[4 + 5*NS2 -1]
    fvec[5 + 5*NS2 -1] = S[5 + 5*NS2 -1]

#---------------------------------------------------------------------72
# For EP, need to satisfy electroneutrality in epithelial compartments
# and zero-current condition in lumen
#---------------------------------------------------------------------

    currM = 0.0
    for I in range(1, NS2 + 1):
        for K in range(2, 5 + 1):
            currM += zval[I-1] * Jsb[I-1,1-1,K-1]
    fvec[6 + 5*NS2 -1] = currM

    volPrat = tube[Lz+1].volPinit / Volb[2-1]
    volArat = tube[Lz+1].volAinit / Volb[3-1]
    volBrat = tube[Lz+1].volBinit / Volb[4-1]

    CimpP = tube[Lz+1].cPimpref * volPrat
    CimpA = tube[Lz+1].cAimpref * volArat
    CimpB = tube[Lz+1].cBimpref * volBrat

    facP = np.exp( np.log(10.0) * (phb[2-1] - pKbuf) )
    facA = np.exp( np.log(10.0) * (phb[3-1] - pKbuf) )
    facB = np.exp( np.log(10.0) * (phb[4-1] - pKbuf) )

    CbufP = tube[Lz+1].cPbuftot * volPrat * facP / (facP + 1)
    CbufA = tube[Lz+1].cAbuftot * volArat * facA / (facA + 1)
    CbufB = tube[Lz+1].cBbuftot * volBrat * facB / (facB + 1)

    elecP = tube[Lz+1].zPimp * CimpP - CbufP
    elecA = tube[Lz+1].zAimp * CimpA - CbufA
    elecB = tube[Lz+1].zBimp * CimpB - CbufB

    elecE = 0.0
    for I in range(1, NS2 + 1):
        elecP += zval[I-1] * Cb[I-1,2-1]
        elecA += zval[I-1] * Cb[I-1,3-1]
        elecB += zval[I-1] * Cb[I-1,4-1]
        elecE += zval[I-1] * Cb[I-1,5-1]
        
    fvec[7 + 5*NS2 -1] = elecP
    fvec[8 + 5*NS2 -1] = elecA
    fvec[9 + 5*NS2 -1] = elecB
    fvec[10 + 5*NS2 -1] = elecE
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Equation for pressure
# Flow must be multiplied by Vref
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    ratio = 8.0 * np.pi * visc / (Am ** 2)

    if idid == 6:  
        ratio = ratio * coalesce * 2
# correct extra coalescence factor in Am, add extra resistance from merging
    elif idid == 7:  
        ratio = ratio * coalesce 
# correct extra coalescence factor in Am
        
    fvec[11 + 5*NS2 -1] = PMb - PMa + ratio * Volb[1-1] * Vref * tube[Lz+1].dimL / NZ

    return fvec
