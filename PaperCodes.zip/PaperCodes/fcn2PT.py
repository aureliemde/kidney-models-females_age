# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################
 
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This subroutine yields the non-linear equations to be solved at any
# point below the inlet, in order to determine the concentrations, volumes,
# and EP in P, A, B, E, and the lumen M.
# It is used to compute values below the entry to the PT.
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 

def fcn2PT(n, x, iflag, numpar, pars, pt, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    fvec = np.zeros(n)
    S = np.zeros(NDPT)
    
    Ca = np.zeros((NSPT, NC)) 
    Vola = np.zeros(NC)
    
    Cb = np.zeros((NSPT, NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    dkd = np.zeros(NC)
    dkh = np.zeros(NC)

# Ca(K) denotes the known concentrations at Lz (same with pH, Vol, EP)
# y is the associated vector, of known variables
# Cb(K) denotes the concentrations at Lz+1 (same with pH, Vol, EP)
# x is the associated vector, of unknown variables
#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in P, A, B, E, and the lumen M at Lz
#---------------------------------------------------------------------72

    Ca[:, 0] = pars[1-1:NS +1-1]
    Ca[:, 1] = pars[1+ NS -1:2*NS +1-1]
    Ca[:, 4] = pars[1+ 2*NS -1:3*NS +1-1]
    Ca[:, 5] = pars[1+ 3*NS -1:4*NS +1-1]
    
    Vola[0] = pars[1 + 4*NSPT -1]
    Vola[1] = pars[2 + 4*NSPT -1]
    Vola[4] = pars[3 + 4*NSPT -1]
    
    PMa = pars[4 + 4*NSPT -1]
    
#---------------------------------------------------------------------72
# Extract other parameters
#---------------------------------------------------------------------72

    VolEinit = pars[4 + 4*NSPT]
    VolPinit = pars[5 + 4*NSPT]
    dimL = pars[6 + 4*NSPT]
    CPimpref = pars[7 + 4*NSPT]
    CPbuftot1 = pars[8 + 4*NSPT]
    
    dkd[1 -1] = pars[10+ 4*NSPT -1]
    dkd[2 -1] = pars[11+ 4*NSPT -1]
    dkd[5 -1] = pars[12+ 4*NSPT -1]
    dkh[1 -1] = pars[13+ 4*NSPT -1]
    dkh[2 -1] = pars[14+ 4*NSPT -1]
    dkh[5 -1] = pars[15+ 4*NSPT -1]

    dcompl = pars[15 + 4*NSPT]  
    dtorq = pars[16 + 4*NSPT]  
    vol0 = pars[17 + 4*NSPT]  
    
#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in P, A, B, E, and the lumen M at Lz+1
#---------------------------------------------------------------------72

    for i in range(1, NSPT + 1):
        Cb[i-1, 1-1] = x[1 + 3*(i-1) -1]
        Cb[i-1, 2-1] = x[2 + 3*(i-1) -1]
        Cb[i-1, 5-1] = x[3 + 3*(i-1) -1]
    
    Cb[:, 5] = pt[Lz+1].conc[:, 5]
    EPb[5] = pt[Lz+1].ep[5]

    phb[0] = -np.log10(Cb[11, 0] / 1.0e3)
    phb[1] = -np.log10(Cb[11, 1] / 1.0e3)
    phb[4] = -np.log10(Cb[11, 4] / 1.0e3)
    
    Volb[0] = x[0 + 3*NSPT]
    Volb[1] = x[1 + 3*NSPT]
    Volb[4] = x[2 + 3*NSPT]
    EPb[0] = x[3 + 3*NSPT]
    EPb[1] = x[4 + 3*NSPT]
    EPb[4] = x[5 + 3*NSPT]
    PMb = x[6 + 3*NSPT]

    from qflux2PT import qflux2PT
    Jvol_3, Jsol_3 = qflux2PT(x, Cb[:, 6-1], EPb[6-1], pt, vol0, dcompl, dtorq, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    
    Jvb = Jvol_3
    Jsb = Jsol_3
    
#---------------------------------------------------------------------72
# Initialize source terms
#---------------------------------------------------------------------72

    for K in range(1, NDPT + 1):
        S[K-1] = 0
        fvec[K-1] = 0
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR FLOW OF SOLUTE I IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# (Vref/href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    Bm = np.pi * pt[Lz+1].diam
    Am = np.pi * ( (pt[Lz+1].diam) ** 2) / 4.0
    
    RMcompl = torqR * (1.0 + torqvm * (PMb - PbloodPT))
    Bmcompl = 2 * np.pi * RMcompl  # Do not assume a change in perimeter for absorption
# Already accounted for via torque effects
    
    for i in range(1, NSPT + 1):
        sumJsb = Jsb[i-1,1-1,2-1] + Jsb[i-1,1-1,5-1]
        fsola = Vola[0] * Ca[i-1, 0] * Vref / href
        fsolb = Volb[0] * Cb[i-1, 0] * Vref / href
        S[1+ 3*(i-1) -1] = fsolb - fsola + Bm * dimL * sumJsb / NZ
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR SOLUTE I IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    for i in range(1, NSPT + 1):
        S[2+ 3*(i-1) -1] = Jsb[i-1, 1, 4] + Jsb[i-1, 1, 5] - Jsb[i-1, 0, 1]  # solute I in P
        S[3+ 3*(i-1) -1] = Jsb[i-1, 4, 5] - Jsb[i-1, 0, 4] - Jsb[i-1, 1, 4]  # solute I in E
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME FLOW IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# Vref/(Pfref.Vwbar.Cref)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    fvmult = Pfref * Vwbar * Cref
    sumJvb = (Jvb[0, 1] + Jvb[0, 4]) * fvmult
    fvola = Vola[0] * Vref
    fvolb = Volb[0] * Vref
    S[0 + 3*NSPT] = fvolb - fvola + Bm * dimL * sumJvb / NZ
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    S[1 + 3*NSPT] = Jvb[1, 4] + Jvb[1, 5] - Jvb[0, 1]  # volume in P
    S[2 + 3*NSPT] = Jvb[4, 5] - Jvb[0, 4] - Jvb[1, 4]  # volume in E
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Convert to equations of the form F(X) = 0
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# For I = 1-3, and 9 (non-reacting solutes)
#---------------------------------------------------------------------72

    for M in range(1, 9 + 1):
        fvec[M-1] = S[M-1]
        
    fvec[24] = S[24]
    fvec[25] = S[25]
    fvec[26] = S[26]
    
# ---------------------------------------------------------------------72
# For glucose, with consumption term linked to Na,K-ATPase activity
# ---------------------------------------------------------------------72

    Pumpactivity = pt[Lz+1].FNaK / (href * Cref * np.pi * pt[Lz+1].diam * 60 / 10 * 1.0e9)
    Gluconsumption = Pumpactivity / (pt[Lz+1].TQ * 6)

    fvec[43-1] = S[43-1]
    fvec[44-1] = S[44-1] + Gluconsumption * 0
    fvec[45-1] = S[45-1]
    
#---------------------------------------------------------------------72
# For Ca2+
#---------------------------------------------------------------------72

    fvec[46-1] = S[46-1]
    fvec[47-1] = S[47-1]
    fvec[48-1] = S[48-1]
    
#---------------------------------------------------------------------72
# For CO2/HCO3/H2CO3
# The dimensional factor for the kinetic term in the lumen is
# Am/Bm = Pi R^2 / 2 PI R = R / 2 = D / 4
#---------------------------------------------------------------------72

    fvec[10-1] = S[10-1] + S[13-1] + S[16-1]
    fvec[11-1] = S[11-1] + S[14-1] + S[17-1]
    fvec[12-1] = S[12-1] + S[15-1] + S[18-1]
    fvec[13-1] = phb[1-1] - pKHCO3 - np.log10(Cb[4-1,1-1] / Cb[5-1,1-1])
    fvec[14-1] = phb[2-1] - pKHCO3 - np.log10(Cb[4-1,2-1] / Cb[5-1,2-1])
    fvec[15-1] = phb[5-1] - pKHCO3 - np.log10(Cb[4-1,5-1] / Cb[5-1,5-1])

    fkin1 = (dkh[1-1] * Ca[6-1,1-1] - dkd[1-1] * Ca[5-1,1-1])
    fkin2 = (dkh[1-1] * Cb[6-1,1-1] - dkd[1-1] * Cb[5-1,1-1])
    fvec[16-1] = S[16-1] + Am * dimL * fkin2 / NZ / href

    facnd = Vref / href
    fvec[17-1] = S[17-1] + Volb[2-1] * (dkh[2-1] * Cb[6-1,2-1] - dkd[2-1] * Cb[5-1,2-1]) * facnd
    fvec[18-1] = S[18-1] + max(Volb[5-1], VolEinit) * (dkh[5-1] * Cb[6-1,5-1] - dkd[5-1] * Cb[5-1,5-1]) * facnd

#---------------------------------------------------------------------72
# For HPO4(2-)/H2PO4(-)
#---------------------------------------------------------------------72

    fvec[19-1] = S[19-1] + S[22-1]
    fvec[20-1] = S[20-1] + S[23-1]
    fvec[21-1] = S[21-1] + S[24-1]
    fvec[22-1] = phb[1-1] - pKHPO4 - np.log10(Cb[7-1,1-1] / Cb[8-1,1-1])
    fvec[23-1] = phb[2-1] - pKHPO4 - np.log10(Cb[7-1,2-1] / Cb[8-1,2-1])
    fvec[24-1] = phb[5-1] - pKHPO4 - np.log10(Cb[7-1,5-1] / Cb[8-1,5-1])

#---------------------------------------------------------------------72
# For NH3/NH4 with ammoniagenesis within lumen
#---------------------------------------------------------------------72

    if dcompl < 0:
        RMtorq = pt[Lz+1].diam / 2.0  # non-compliant tubule
    else:
        RMtorq = torqR * (1.0 + torqvm * (PMb - PbloodPT))

    factor1 = 8.0 * visc * (Volb[1-1] * Vref) * torqL / (RMtorq**2)
    factor2 = 1.0 + (torqL + torqd) / RMtorq + 0.5 * ((torqL / RMtorq)**2)
    Torque = factor1 * factor2

    if dtorq < 0:
        Scaletorq = 1.0  # No torque effect on transporter density
    else:
        Scaletorq = 1.0 + TS * pt[Lz+1].scaleT * (Torque / ( pt[Lz+1].TM0 ) - 1.0)
    Scaletorq = max(Scaletorq, 0.001)
    
# The rate of ammoniagenesis also scales with the torque
    if idid == 0:
        Qnh4 = pt[Lz+1].qnh4 * Scaletorq
    else:
        Qnh4 = 0.0

    fvec[28-1] = S[28-1] + S[31-1]
    fvec[29-1] = S[29-1] + S[32-1] - Qnh4
    fvec[30-1] = S[30-1] + S[33-1]
    fvec[31-1] = phb[1-1] - pKNH3 - np.log10(Cb[10-1,1-1] / Cb[11-1,1-1])
    fvec[32-1] = phb[2-1] - pKNH3 - np.log10(Cb[10-1,2-1] / Cb[11-1,2-1])
    fvec[33-1] = phb[5-1] - pKNH3 - np.log10(Cb[10-1,5-1] / Cb[11-1,5-1])

#---------------------------------------------------------------------72
# For HCO2-/H2CO2
#---------------------------------------------------------------------72

    fvec[37-1] = S[37-1] + S[40-1]
    fvec[38-1] = S[38-1] + S[41-1]
    fvec[39-1] = S[39-1] + S[42-1]
    fvec[40-1] = phb[1-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,1-1] / Cb[14-1,1-1]))
    fvec[41-1] = phb[2-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,2-1] / Cb[14-1,2-1]))
    fvec[42-1] = phb[5-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,5-1] / Cb[14-1,5-1]))

#---------------------------------------------------------------------72
# For pH
#---------------------------------------------------------------------72

    fvec[34-1] = S[34-1] + S[31-1] - S[19-1] - S[10-1] - S[37-1]  # pH in M
    fvec[35-1] = S[35-1] + S[32-1] - S[20-1] - S[11-1] - S[38-1]  # pH in P
    fvec[36-1] = S[36-1] + S[33-1] - S[21-1] - S[12-1] - S[39-1]  # pH in E

#---------------------------------------------------------------------72
# For volume
#---------------------------------------------------------------------72

    fvec[1 + 3*NSPT -1] = S[1 + 3*NSPT -1]
    fvec[2 + 3*NSPT -1] = S[2 + 3*NSPT -1]
    fvec[3 + 3*NSPT -1] = S[3 + 3*NSPT -1]
    
#---------------------------------------------------------------------72
# For EP, need to satisfy electroneutrality in epithelial compartments
# and zero-current condition in lumen
#---------------------------------------------------------------------7

    currM = 0.0
    for I in range(1, NSPT + 1):
        currM += zval[I-1] * (Jsb[I-1,1-1,2-1] + Jsb[I-1,1-1,5-1])
    fvec[4 + 3*NSPT -1] = currM

    volPrat = VolPinit / Volb[2-1]
    CimpP = CPimpref * volPrat
    facP = np.exp( np.log(10.0) * (phb[2-1] - pKbuf) )
    CbufP = CPbuftot1 * volPrat * facP / (facP + 1)

    elecP = zPimpPT * CimpP - CbufP
    elecE = 0.0
    for I in range(1, NSPT + 1):
        elecP += zval[I-1] * Cb[I-1,2-1]
        elecE += zval[I-1] * Cb[I-1,5-1]
    fvec[5 + 3*NSPT -1] = elecP
    fvec[6 + 3*NSPT -1] = elecE
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Equation for pressure - Poiseuille law
# Flow must be multiplied by Vref
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# For a compliant tubule, the radius and area vary with pressure

    RMcompl = torqR * (1.0 + torqvm * (PMb - PbloodPT))
    Amcompl = np.pi * (RMcompl**2)

    if dcompl < 0:  # non-compliant PT
        factor1 = 8.0 * np.pi * visc / (Am**2)
    else:
        factor1 = 8.0 * np.pi * visc / (Amcompl**2)
    
    fvec[7 + 3*NSPT -1] = PMb - PMa + factor1 * Volb[1-1] * Vref * dimL / NZ

    return fvec
