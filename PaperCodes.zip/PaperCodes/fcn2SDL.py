# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This subroutine yields the non-linear equations to be solved at any
# point below the SDL inlet, in order to determine the *luminal*
# concentrations, volumes, and EP
# It is used to compute values below the entry to the SDL.
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 
    
def fcn2SDL(n, x, iflag, numpar, pars, sdl, idid, Lz, PTinitVol):
    
    fvec = np.zeros(n)
    S = np.zeros(NDA)
    
    fsola = np.zeros(n)
    fsolb = np.zeros(n)

    Ca = np.zeros((NS, NC))
    Vola = np.zeros(NC)
    
    Cb = np.zeros((NS, NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    Jva = np.zeros((NC,NC)) 
    Jsa = np.zeros((NS,NC,NC))
    
    Jvb = np.zeros((NC,NC)) 
    Jsb = np.zeros((NS,NC,NC))
    
    CaBT = np.zeros(NC) 
    dkh = np.zeros(NC) 
    dkd = np.zeros(NC)
    
# Ca(K) denotes the known concentrations at Lz (same with pH, Vol, EP)
# y is the associated vector, of known variables
# Cb(K) denotes the concentrations at Lz+1 (same with pH, Vol, EP)
# x is the associated vector, of unknown variables
#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in P, A, B, E, and the lumen M at Lz
#---------------------------------------------------------------------72
      
    for i in range(1, NS+1):
        Ca[i-1, 1-1] = pars[i-1]
        Ca[i-1, 2-1] = pars[i-1 + NS]
        Ca[i-1, 5-1] = pars[i-1 + 2*NS]
        
    Vola[1-1] = pars[1 + 3*NS - 1]
    Vola[2-1] = pars[2 + 3*NS - 1]
    Vola[5-1] = pars[3 + 3*NS - 1]
    
    PMa = pars[4 + 3*NS - 1]
    
#---------------------------------------------------------------------72
# Assign concentrations and potentials in peritubular solution
#---------------------------------------------------------------------72

    for j in range(1, NS+1):
        Ca[j-1, 6-1] = pars[j + 4 + 3*NS - 1]
        
    Cb[:, 6-1] = sdl[Lz+1].conc[:, 6-1]
    EPb[6-1] = sdl[Lz+1].ep[6-1]

#---------------------------------------------------------------------72
# Extract other parameters
#---------------------------------------------------------------------72

    dimL = pars[5 + 4 * NS -1]
    CPimpref = pars[6 + 4 * NS -1]
    Diam = pars[7 + 4 * NS -1]
    Vol0 = pars[8 + 4 * NS -1]
    
#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in the lumen at Lz+1; don't care about other compartments
#---------------------------------------------------------------------72

    for i in range(1, NS2 +1):
        Cb[i-1, 1-1] = x[i-1]
        
    Volb[1-1] = x[1+ NS2 -1]
    PMb = x[2+ NS2 -1]
    phb[1-1] = -np.log10(abs(Cb[12-1, 1-1] / 1000.0))
    
# SDL is a little water permeable, but completely solute impermeable

    from compute_sdl_water_fluxes import compute_sdl_water_fluxes
    Jvb = compute_sdl_water_fluxes(Cb, PMb, Volb, Vol0, sdl[Lz+1].area, sdl[Lz+1].sig, sdl[Lz+1].dLPV, PTinitVol)

#---------------------------------------------------------------------72
# Initialize source terms
#---------------------------------------------------------------------
    
    for K in range(1, n + 1):
        S[K-1] = 0
        fvec[K-1] = 0
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR FLOW OF SOLUTE I IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# (Vref/href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Bm = np.pi * Diam
    Am = np.pi * (Diam ** 2) / 4.0
    
    for i in range(1, NS2 + 1):
        sumJsb = 0.0  # assume solute impermeable
        fsola[i-1] = Vola[1-1] * Ca[i-1, 1-1] * Vref / href
        fsolb[i-1] = Volb[1-1] * Cb[i-1, 1-1] * Vref / href
        S[i-1] = fsolb[i-1] - fsola[i-1] + Bm * dimL * sumJsb / NZ

# Assign non-reacting species
    fvec[1-1] = S[1-1]
    fvec[2-1] = S[2-1]
    fvec[3-1] = S[3-1]
    fvec[9-1] = S[9-1]
    fvec[15-1] = S[15-1]
    fvec[16-1] = S[16-1]
    
#---------------------------------------------------------------------72
# For CO2/HCO3/H2CO3
#---------------------------------------------------------------------72

    dkhuncat = 0.145
    dkduncat = 49.60
    
    fvec[4-1] = S[4-1] + S[5-1] + S[6-1]
    fvec[5-1] = phb[1-1] - pKHCO3 - np.log10(abs(Cb[4-1, 1-1] / Cb[5-1, 1-1]))
    fklum = (dkhuncat * Cb[6-1, 1-1] - dkduncat * Cb[5-1, 1-1])
    fvec[6-1] = S[6-1] + Am * dimL * fklum / NZ / href

#---------------------------------------------------------------------72
# For HPO4(2-)/H2PO4(-)
#---------------------------------------------------------------------72
     
    fvec[7-1] = S[7-1] + S[8-1]
    fvec[8-1] = phb[1-1] - pKHPO4 - np.log10(abs(Cb[7-1, 1-1] / Cb[8-1, 1-1]))

#---------------------------------------------------------------------72
# For NH3/NH4
#---------------------------------------------------------------------

    fvec[10-1] = S[10-1] + S[11-1]
    fvec[11-1] = phb[1-1] - pKNH3 - np.log10(abs(Cb[10-1, 1-1] / Cb[11-1, 1-1]))

#---------------------------------------------------------------------72
# For HCO2-/H2CO2
#---------------------------------------------------------------------

    fvec[13-1] = S[13-1] + S[14-1] 
    fvec[14-1] = phb[1-1] - pKHCO2 - np.log10(abs(Cb[13-1, 1-1] / Cb[14-1, 1-1]))

#---------------------------------------------------------------------72
# For pH
#---------------------------------------------------------------------

    fvec[12-1] = S[12-1]+S[11-1]-S[4-1]-S[7-1]-S[13-1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME FLOW IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# Vref/(Pfref.Vwbar.Cref)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    fvmult = Pfref * Vwbar * Cref
    sumJvb = Jvb[1-1, 6-1] * fvmult
    fvola = Vola[1-1] * Vref
    fvolb = Volb[1-1] * Vref
    fvec[1 + NS2 -1] = fvolb - fvola + Bm * dimL * sumJvb / NZ

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Equation for pressure
# Flow must be multiplied by Vref
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    ratio = 8.0 * visc / (np.pi * ((0.5 * Diam) ** 4))
    fvec[2 + NS2 - 1] = PMb - PMa + ratio * Volb[1-1] * Vref * dimL / NZ

    return fvec
