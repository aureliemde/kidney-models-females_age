# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################
 
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This subroutine yields the non-linear equations to be solved at any
# point below the inlet, in order to determine the concentrations, volumes,
# and EP in P, A, B, E, and the lumen M.
# It is used to compute values below the entry of segments that only have
# principal cells (except for the PT): mTAL, cTAL, DCT and IMCD.
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 

def fcn2b(n, x, iflag, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    fvec = np.zeros(n)
    S = np.zeros(NDA)
    
    Ca = np.zeros((NS, NC)) 
    Vola = np.zeros(NC)
    
    Cb = np.zeros((NS, NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    Jva = np.zeros((NC,NC)) 
    Jsa = np.zeros((NS,NC,NC))
    
    Jvb = np.zeros((NC,NC)) 
    Jsb = np.zeros((NS,NC,NC))
    
    CaBT = np.zeros(NC)
    
# Ca(K) denotes the known concentrations at Lz (same with pH, Vol, EP)
# y is the associated vector, of known variables

# Cb(K) denotes the concentrations at Lz+1 (same with pH, Vol, EP)
# x is the associated vector, of unknown variables

#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in P, A, B, E, and the lumen M at Lz
#---------------------------------------------------------------------72
    
    for I in range(1, NS + 1):
        Ca[I-1 , 1-1] = pars[I -1]
        Ca[I-1 , 2-1] = pars[I -1 + NS]
        Ca[I-1 , 5-1] = pars[I -1 + 2*NS]
    
    Vola[0] = pars[1 + 3*NS -1]
    Vola[1] = pars[2 + 3*NS -1]
    Vola[4] = pars[3 + 3*NS -1]
    
    PMa = pars[4 + 3*NS -1]
    
#---------------------------------------------------------------------72
# Assign concentrations and potentials in peritubular solution
#---------------------------------------------------------------------72
    
    for J in range(1, NS + 1):
        Ca[J-1 , 6-1] = pars[J-1 +4+3*NS]
        Cb[J-1 , 6-1] = pars[J-1 +4+4*NS]
    
    EPb[6-1] = pars[5 -1 +5*NS]    
    
#---------------------------------------------------------------------72
# Extract other parameters
#---------------------------------------------------------------------72

    dimL = pars[6 + 5*NS -1]
    CPimpref = pars[7 + 5*NS -1]
    Diam = pars[8 + 5*NS -1]
    
    if idid == 3: #mTAL
        CPbuffer = CPbuftotA
        
    elif idid == 4: #cTAL
        CPbuffer = CPbuftotT
        
    elif idid == 5: # DCT
        CPbuffer= CPbuftotD
        
    elif idid == 9: # IMCD
        CPbuffer= CPbuftotIMC
        
#---------------------------------------------------------------------72
# Assign concentrations, volumes, and potentials
# in P, A, B, E, and the lumen M at Lz+1
#---------------------------------------------------------------------

    for i in range(1, NS2 + 1):
        Cb[i-1, 1-1] = x[1 + 3*(i-1) -1]
        Cb[i-1, 2-1] = x[2 + 3*(i-1) -1]
        Cb[i-1, 5-1] = x[3 + 3*(i-1) -1]
        
    phb[0] = -np.log10(Cb[11, 0] / 1.0e3)
    phb[1] = -np.log10(Cb[11, 1] / 1.0e3)
    phb[4] = -np.log10(Cb[11, 4] / 1.0e3)
    
    Volb[0] = x[0 + 3*NS2]
    Volb[1] = x[1 + 3*NS2]
    Volb[4] = x[2 + 3*NS2]
    EPb[0] = x[3 + 3*NS2]
    EPb[1] = x[4 + 3*NS2]
    EPb[4] = x[5 + 3*NS2]
    PMb = x[6 + 3*NS2]
    
    if idid == 3: #mTAL
        from qflux2A import qflux2A
        Jvol_3, Jsol_3 = qflux2A(x, tube[Lz+1].conc[:,6-1], tube[Lz+1].ep[6-1], tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    elif idid == 4: #cTAL
        from qflux2T import qflux2T
        Jvol_3, Jsol_3 = qflux2T(x, tube[Lz+1].conc[:,6-1], tube[Lz+1].ep[6-1], tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    elif idid == 5: # DCT
        from qflux2D import qflux2D
        Jvol_3, Jsol_3 = qflux2D(x, tube[Lz+1].conc[:,6-1], tube[Lz+1].ep[6-1], tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    elif idid == 9: # IMCD
        from qflux2IMC import qflux2IMC
        Jvol_3, Jsol_3 = qflux2IMC(x, tube[Lz+1].conc[:,6-1], tube[Lz+1].ep[6-1], tube, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
    Jvb = Jvol_3
    Jsb = Jsol_3
    
#---------------------------------------------------------------------72
# Initialize source terms
#---------------------------------------------------------------------72

    for K in range(1, n + 1):
        S[K-1] = 0
        fvec[K-1] = 0
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR FLOW OF SOLUTE I IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# (Vref/href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Bm = np.pi * Diam
    Am = np.pi * ( Diam ** 2) / 4.0
    
    if idid == 9: 
        Bm = Bm * tube[Lz+1].coalesce
        Am = Am * tube[Lz+1].coalesce
    
    for i in range(1, NS2 + 1):
        sumJsb = Jsb[i-1,1-1,2-1] + Jsb[i-1,1-1,5-1]
        fsola = Vola[0] * Ca[i-1, 0] * Vref / href
        fsolb = Volb[0] * Cb[i-1, 0] * Vref / href
        S[1+ 3*(i-1) -1] = fsolb - fsola + Bm * dimL * sumJsb / NZ
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR SOLUTE I IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    for i in range(1, NS2 + 1):
        S[2+ 3*(i-1) -1] = Jsb[i-1, 1, 4] + Jsb[i-1, 1, 5] - Jsb[i-1, 0, 1]  # solute I in P
        S[3+ 3*(i-1) -1] = Jsb[i-1, 4, 5] - Jsb[i-1, 0, 4] - Jsb[i-1, 1, 4]  # solute I in E
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME FLOW IN THE LUMEN
# The non-dimensional volume flux needs to be multiplied by
# Vref/(Pfref.Vwbar.Cref)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    fvmult = Pfref * Vwbar * Cref
    sumJvb = (Jvb[0, 1] + Jvb[0, 4]) * fvmult
    fvola = Vola[0] * Vref
    fvolb = Volb[0] * Vref
    S[0 + 3*NS2] = fvolb - fvola + Bm * dimL * sumJvb / NZ
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOURCE TERMS FOR VOLUME IN EACH CELLULAR COMPARTMENT
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    S[1 + 3*NS2] = Jvb[1, 4] + Jvb[1, 5] - Jvb[0, 1]  # volume in P
    S[2 + 3*NS2] = Jvb[4, 5] - Jvb[0, 4] - Jvb[1, 4]  # volume in E
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Convert to equations of the form F(X) = 0
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# For I = 1-3 & 9 & 13 & 16 (non-reacting solutes)
#---------------------------------------------------------------------

    for M in range(1, 9 + 1): # Na+, K+, Cl
        fvec[M-1] = S[M-1]
        
    fvec[25 - 1] = S[25 - 1] # Urea - solute 9; index = 1+3*(9-1)
    fvec[26 - 1] = S[26 - 1]
    fvec[27 - 1] = S[27 - 1]
    
    fvec[43 - 1] = S[43 - 1] # Glucose - solute 15; index = 1+3*(15-1)
    fvec[44 - 1] = S[44 - 1]
    fvec[45 - 1] = S[45 - 1]
    
    fvec[46 -1] = S[46 -1] # Calcium - solute 16; index = 1+3*(16-1)
    fvec[47 -1] = S[47 -1]
    fvec[48 -1] = S[48 -1]
    
#---------------------------------------------------------------------72
# For CO2/HCO3/H2CO3
# The dimensional factor for the kinetic term in the lumen is
# Am/Bm = Pi R^2 / 2 PI R = R / 2 = D / 4
#---------------------------------------------------------------------

    fvec[10-1] = S[10-1] + S[13-1] + S[16-1]
    fvec[11-1] = S[11-1] + S[14-1] + S[17-1]
    fvec[12-1] = S[12-1] + S[15-1] + S[18-1]
    fvec[13-1] = phb[1-1] - pKHCO3 - np.log10(Cb[4-1,1-1] / Cb[5-1,1-1])
    fvec[14-1] = phb[2-1] - pKHCO3 - np.log10(Cb[4-1,2-1] / Cb[5-1,2-1])
    fvec[15-1] = phb[5-1] - pKHCO3 - np.log10(Cb[4-1,5-1] / Cb[5-1,5-1])

    fkin1 = (tube[Lz+1].dkh[1-1] * Ca[6-1,1-1] - tube[Lz+1].dkd[1-1] * Ca[5-1,1-1])
    fkin2 = (tube[Lz+1].dkh[1-1] * Cb[6-1,1-1] - tube[Lz+1].dkd[1-1] * Cb[5-1,1-1])
    fvec[16-1] = S[16-1] + Am * dimL * fkin2 / NZ / href

    facnd = Vref / href
    fvec[17-1] = S[17-1] + Volb[2-1] * (tube[Lz+1].dkh[2-1] * Cb[6-1,2-1] - tube[Lz+1].dkd[2-1] * Cb[5-1,2-1]) * facnd
    fvec[18-1] = S[18-1] + max(Volb[5-1], tube[Lz+1].volEinit) * (tube[Lz+1].dkh[5-1] * Cb[6-1,5-1] - tube[Lz+1].dkd[5-1] * Cb[5-1,5-1]) * facnd

#---------------------------------------------------------------------72
# For HPO4(2-)/H2PO4(-)
#---------------------------------------------------------------------72

    fvec[19-1] = S[19-1] + S[22-1]
    fvec[20-1] = S[20-1] + S[23-1]
    fvec[21-1] = S[21-1] + S[24-1]
    fvec[22-1] = phb[1-1] - pKHPO4 - np.log10(Cb[7-1,1-1] / Cb[8-1,1-1])
    fvec[23-1] = phb[2-1] - pKHPO4 - np.log10(Cb[7-1,2-1] / Cb[8-1,2-1])
    fvec[24-1] = phb[5-1] - pKHPO4 - np.log10(Cb[7-1,5-1] / Cb[8-1,5-1])

#---------------------------------------------------------------------72
# For NH3/NH4
#---------------------------------------------------------------------72

    fvec[28-1] = S[28-1] + S[31-1]
    fvec[29-1] = S[29-1] + S[32-1]
    fvec[30-1] = S[30-1] + S[33-1]
    fvec[31-1] = phb[1-1] - pKNH3 - np.log10(Cb[10-1,1-1] / Cb[11-1,1-1])
    fvec[32-1] = phb[2-1] - pKNH3 - np.log10(Cb[10-1,2-1] / Cb[11-1,2-1])
    fvec[33-1] = phb[5-1] - pKNH3 - np.log10(Cb[10-1,5-1] / Cb[11-1,5-1])

#---------------------------------------------------------------------72
# For HCO2-/H2CO2
#---------------------------------------------------------------------72

    fvec[37-1] = S[37-1] + S[40-1]
    fvec[38-1] = S[38-1] + S[41-1]
    fvec[39-1] = S[39-1] + S[42-1]
    fvec[40-1] = phb[1-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,1-1] / Cb[14-1,1-1]))
    fvec[41-1] = phb[2-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,2-1] / Cb[14-1,2-1]))
    fvec[42-1] = phb[5-1] - pKHCO2 - np.log10(np.abs(Cb[13-1,5-1] / Cb[14-1,5-1]))

#---------------------------------------------------------------------72
# For pH
#---------------------------------------------------------------------72

    fvec[34-1] = S[34-1] + S[31-1] - S[19-1] - S[10-1] - S[37-1]  # pH in M
    fvec[35-1] = S[35-1] + S[32-1] - S[20-1] - S[11-1] - S[38-1]  # pH in P
    fvec[36-1] = S[36-1] + S[33-1] - S[21-1] - S[12-1] - S[39-1]  # pH in E

#---------------------------------------------------------------------72
# For volume
#---------------------------------------------------------------------

    fvec[1 + 3*NS2 -1] = S[1 + 3*NS2 -1]
    fvec[2 + 3*NS2 -1] = S[2 + 3*NS2 -1]
    fvec[3 + 3*NS2 -1] = S[3 + 3*NS2 -1]

#---------------------------------------------------------------------72
# For EP, need to satisfy electroneutrality in epithelial compartments
# and zero-current condition in lumen
#---------------------------------------------------------------------

    currM = 0.0
    for I in range(1, NS + 1):
        currM += zval[I-1] * (Jsb[I-1,1-1,2-1] + Jsb[I-1,1-1,5-1])
    fvec[4 + 3*NS2 -1] = currM

    volPrat = tube[Lz+1].volPinit / Volb[2-1]
    CimpP = CPimpref * volPrat
    facP = np.exp( np.log(10.0) * (phb[2-1] - pKbuf) )
    CbufP = CPbuffer * volPrat * facP / (facP + 1)

    elecP = zPimpPT * CimpP - CbufP
    elecE = 0.0
    for I in range(1, NS2 + 1):
        elecP += zval[I-1] * Cb[I-1,2-1]
        elecE += zval[I-1] * Cb[I-1,5-1]
    fvec[5 + 3*NS2 -1] = elecP
    fvec[6 + 3*NS2 -1] = elecE
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Equation for pressure - Poiseuille's law
# Flow must be multiplied by Vref
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Am is the luminal cross-sectional area, given by PI*(DiamPT**2)/4.0d0

    ratio = 8.0 * np.pi * visc / (Am**2)

    if idid == 9:  # non-compliant PT
        ratio = ratio * (tube[Lz+1].coalesce) * 2
# correct extra coalescence factor in Am, add extra resistance from merging
    
    fvec[7 + 3*NS2 -1] = PMb - PMa + ratio * Volb[1-1] * Vref * dimL / NZ

    return fvec
