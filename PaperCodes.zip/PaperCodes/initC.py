# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine.
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 

def initC(cnt):
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
    Pf = np.zeros((NC,NC))
    dLA = np.zeros((NS,NS,NC,NC))

    pos = np.zeros(NZ+1)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Solute Indices: 1 = Na+, 2 = K+, 3 = Cl-, 4 = HCO3-, 5 = H2CO3, 6 = CO2
# 7 = HPO4(2-), 8 = H2PO4-, 9 = urea, 10 = NH3, 11 = NH4+, 12 = H+
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Data for rat (AMW model, AJP Renal 2005)
#---------------------------------------------------------------------

# tubular length and luminal diameter

    for p in cnt:
        p.dimL = dimLC
        p.diam = DiamC

    SlumPinitcnt = 1.2
    SbasPinitcnt = 1.2
    SlatPinitcnt = 6.9
    
    SlumAinitcnt = 0.58
    SbasAinitcnt = 0.58
    SlatAinitcnt = 1.25
    
    SlumBinitcnt = 0.17
    SbasBinitcnt = 0.17
    SlatBinitcnt = 1.50
    
    SlumEinitcnt = 0.001

    for p in cnt:
        p.sbasEinit = 0.020
        
        p.volPinit = 6.0
        p.volAinit = 2.7
        p.volBinit = 1.8
        p.volEinit = 0.20
       
#---------------------------------------------------------------------72
# Assign membrane surface area except for basal membrane of E
#---------------------------------------------------------------------72        
        
    for p in cnt:
        p.area[1-1, 2-1] = SlumPinitcnt
        p.area[1-1, 3-1] = SlumAinitcnt
        p.area[1-1, 4-1] = SlumBinitcnt
        p.area[1-1, 5-1] = SlumEinitcnt
        
        p.area[2-1, 5-1] = SlatPinitcnt
        p.area[3-1, 5-1] = SlatAinitcnt
        p.area[4-1, 5-1] = SlatBinitcnt
        
        p.area[2-1, 6-1] = SbasPinitcnt
        p.area[3-1, 6-1] = SbasAinitcnt
        p.area[4-1, 6-1] = SbasBinitcnt

    for K in range(1, NC -1 +1):
        for L in range(K + 1, NC + 1):
            for p in cnt:
                p.area[L-1, K-1] = p.area[K-1, L-1]
            
    for p in cnt:
        p.zPimp = -1.0
        p.zAimp = -1.0
        p.zBimp = -1.0
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Water permeabilities
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    PfMP = 2.4 * 0.036
    PfPE = 2.4 * 0.44
    PfPS = 2.4 * 0.44
    
    PfMA = 0.22e-3
    PfAE = 5.50e-3
    PfAS = 5.50e-3
    
    PfMB = 0.22e-3
    PfBE = 5.50e-3
    PfBS = 5.50e-3
    
    PfES = 110
    PfME = 1.1
    
    Pf = np.zeros((NC, NC))

    Pf[1-1,2-1] = PfMP
    Pf[1-1,3-1] = PfMA
    Pf[1-1,4-1] = PfMB
    Pf[1-1,5-1] = PfME
    Pf[2-1,5-1] = PfPE
    Pf[3-1,5-1] = PfAE
    Pf[4-1,5-1] = PfBE
    Pf[2-1,6-1] = PfPS
    Pf[3-1,6-1] = PfAS
    Pf[4-1,6-1] = PfBS
    Pf[5-1,6-1] = PfES
    
# Units of dimensional water flux: cm3/s/cm2 epith
# Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
# Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
# dLPV = Pf/Pfref

    for K in range(1, NC + 1):
        for L in range(1, NC + 1):
            for p in cnt:
                p.dLPV[K-1, L-1] = Pf[K-1, L-1] / Pfref

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# sig(I,K,L) = reflection coefficient of Ith solute between K and L
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(1, NC + 1):
                for p in cnt:
                    p.sig[i-1, k-1, l-1] = 1.0
            
# Values at the basement membrane (ES)
    for i in range(1, NS + 1):
        for p in cnt:
            p.sig[i-1, 5-1, 6-1] = 0.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional Solute permeabilities
# h(I,K,L) = permeability of ith solute at the K-L interface
# h(I,K,L) in 10-5 cm/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    PICAchlo = 11.0
    PICBchlo = 3.20
    PPCh2co3 = 130
    PICh2co3 = 10
    PPCco2 = 15.0e3
    PICco2 = 900
    PPChpo4 = 8.00e-3
    PICAhpo4 = 7.20e-3
    PICBhpo4 = 4.80e-3
    PPCprot = 2000
    PICAprot = 9.0
    PICBprot = 6.0
    PPCamon = 2000
    PICamon = 900
    Purea = 0.10

# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in cnt:
                    p.h[i-1, k-1, l-1] = 0.0

# Original values for ENaC expression in CNT, CCD, OMCD and IMCD multiplied by fscaleENaC
# Original values for Na/K-ATPase expression in principal cells in CNT through IMCD multiplied by fscaleNaK

    fscaleENaC = 2.50
    fscaleNaK = 1.25
    fscaleNaK_PC = 1.25
    
# Female-to-male ENaC expression ratio in cortex (CNT and CCD)
    FM_cENaC = 1.20 * 0.85

# Values at the MP interface (1-2)

# ENaC activity modified by local factors, including pH. Use hENaC_CNT as basal value of expression
### - FEMALE ADJUSTMENT ENaC x 1.20
    hENaC_CNT = FM_cENaC * 35.0

# ROMK activity modified by local factors, including pH. Use hROMK_CNT as basal value of expression
# cnt(:)%h(2,1,2) = 8.0d0 - Not used, replaced with hROMK
    hROMK_CNT = 8.0

    for p in cnt:
        p.h[3-1,1-1,2-1] = 0.80
        p.h[4-1,1-1,2-1] = 0.16
        p.h[5-1,1-1,2-1] = PPCh2co3
        p.h[6-1,1-1,2-1] = PPCco2
        p.h[7-1,1-1,2-1] = 1.0e-3/1.20
        p.h[8-1,1-1,2-1] = 1.0e-3/1.20
        p.h[9-1,1-1,2-1] = Purea
        p.h[10-1,1-1,2-1] = PPCamon
        p.h[11-1,1-1,2-1] = p.h[2-1,1-1,2-1] * 0.20  #AMW rule of thumb
        p.h[12-1,1-1,2-1] = PPCprot
        p.h[13-1,1-1,2-1] = 0.0
        p.h[14-1,1-1,2-1] = 0.0
        p.h[15-1,1-1,2-1] = 0.0
        p.h[16-1,1-1,2-1] = 0.0
        
# Values at the PE interface (2-5)
        p.h[1-1, 2-1, 5-1] = 0.000
        p.h[2-1, 2-1, 5-1] = 4
        p.h[3-1, 2-1, 5-1] = 0.2
        p.h[4-1, 2-1, 5-1] = p.h[3-1,2-1,5-1] * 0.20  #AMW rule of thumb
        p.h[5-1, 2-1, 5-1] = PPCh2co3
        p.h[6-1, 2-1, 5-1] = PPCco2
        p.h[7-1, 2-1, 5-1] = 8.0e-3
        p.h[8-1, 2-1, 5-1] = 8.0e-3
        p.h[9-1, 2-1, 5-1] = Purea
        p.h[10-1, 2-1, 5-1] = PPCamon
        p.h[11-1, 2-1, 5-1] = p.h[2-1,2-1,5-1] * 0.20  #AMW rule of thumb
        p.h[12-1, 2-1, 5-1] = PPCprot
        p.h[13-1, 2-1, 5-1] = 1.0e-4
        p.h[14-1, 2-1, 5-1] = 1.0e-4
        p.h[15-1, 2-1, 5-1] = 1.0e-4
        p.h[16-1, 2-1, 5-1] = 0.0
                
# Values at the MA interface (1-3)

        p.h[1-1,1-1,3-1] = 0.0
        p.h[2-1,1-1,3-1] = 0.00  
        p.h[3-1,1-1,3-1] = 0.0
        p.h[4-1,1-1,3-1] = 0.0
        p.h[5-1,1-1,3-1] = PICh2co3
        p.h[6-1,1-1,3-1] = PICco2
        p.h[7-1,1-1,3-1] = 0.0
        p.h[8-1,1-1,3-1] = 0.0
        p.h[9-1,1-1,3-1] = Purea
        p.h[10-1,1-1,3-1] = PICamon
        p.h[11-1,1-1,3-1] = 0.00
        p.h[12-1,1-1,3-1] = 0.0
        p.h[13-1,1-1,3-1] = 0.0
        p.h[14-1,1-1,3-1] = 0.0
        p.h[15-1,1-1,3-1] = 0.0
        p.h[16-1,1-1,3-1] = 1.0e-5

# Values at the AE interface (3-5)

        p.hCLCA = PICAchlo
    
        p.h[1-1,3-1,5-1] = 0.0
        p.h[2-1,3-1,5-1] = 0.448
        p.h[3-1,3-1,5-1] = PICAchlo
        p.h[4-1,3-1,5-1] = 1.50
        p.h[5-1,3-1,5-1] = PICh2co3
        p.h[6-1,3-1,5-1] = PICco2
        p.h[7-1,3-1,5-1] = PICAhpo4
        p.h[8-1,3-1,5-1] = PICAhpo4
        p.h[9-1,3-1,5-1] = Purea
        p.h[10-1,3-1,5-1] = PICamon
        p.h[11-1,3-1,5-1] = 0.18
        p.h[12-1,3-1,5-1] = PICAprot
        p.h[13-1,3-1,5-1] = 1.0e-4
        p.h[14-1,3-1,5-1] = 1.0e-4
        p.h[15-1,3-1,5-1] = 1.0e-4
        p.h[16-1,3-1,5-1] = 1.0e-5

# Values at the MB interface (1-4)
        p.h[1-1,1-1,4-1] = 0.0
        p.h[2-1,1-1,4-1] = 0.0
        p.h[3-1,1-1,4-1] = 0.0
        p.h[4-1,1-1,4-1] = 0.0
        p.h[5-1,1-1,4-1] = PICh2co3
        p.h[6-1,1-1,4-1] = PICco2
        p.h[7-1,1-1,4-1] = 0.0
        p.h[8-1,1-1,4-1] = 0.0
        p.h[9-1,1-1,4-1] = Purea
        p.h[10-1,1-1,4-1] = PICamon
        p.h[11-1,1-1,4-1] = 0.0
        p.h[12-1,1-1,4-1] = 0.0
        p.h[13-1,1-1,4-1] = 0.0
        p.h[14-1,1-1,4-1] = 0.0
        p.h[15-1,1-1,4-1] = 0.0
        p.h[16-1,1-1,4-1] = 1.0e-5

# Values at the BE interface (4-5)
        p.hCLCB = PICBchlo
        p.h[1-1,4-1,5-1] = 0.0
        p.h[2-1,4-1,5-1] = 0.12
        p.h[3-1,4-1,5-1] = PICBchlo
        p.h[4-1,4-1,5-1] = 0.40
        p.h[5-1,4-1,5-1] = PICh2co3
        p.h[6-1,4-1,5-1] = PICco2
        p.h[7-1,4-1,5-1] = PICBhpo4
        p.h[8-1,4-1,5-1] = PICBhpo4
        p.h[9-1,4-1,5-1] = Purea
        p.h[10-1,4-1,5-1] = PICamon
        p.h[11-1,4-1,5-1] = 0.12
        p.h[12-1,4-1,5-1] = PICBprot
        p.h[13-1,4-1,5-1] = 1.0e-4
        p.h[14-1,4-1,5-1] = 1.0e-4
        p.h[15-1,4-1,5-1] = 1.0e-4
        p.h[16-1,4-1,5-1] = 1.0e-5

# Values at basal interfaces (2-6), (3-6), (4-6)

    for I in range(1, NS + 1):
        for p in cnt:
            p.h[I-1, 2-1, 6-1] = p.h[I-1, 2-1, 5-1]
            p.h[I-1, 3-1, 6-1] = p.h[I-1, 3-1, 5-1]
            p.h[I-1, 4-1, 6-1] = p.h[I-1, 4-1, 5-1]
            
# Values at the ME interface (1-5)
    ClTJperm = 1000.0  # Assume TJ resistivity of 5 mS/cm2
 
    for p in cnt:
        p.h[1-1, 1-1, 5-1] = (1.00 / FM_cENaC) * 1.0*ClTJperm
        p.h[2-1, 1-1, 5-1] = (1.00 / FM_cENaC) * 1.2*ClTJperm
# Cl permeability modified by local factors, including pH. Use hCltj_CNT as basal value of expression
# cnt(:)%h(3,1,5) = ClTJperm*1.2d0 - Not used, replaced with hCltj
        hCltj_CNT = 1.3 * ClTJperm * 1.2
        
        p.h[4-1, 1-1, 5-1] = 0.6*ClTJperm
        p.h[5-1, 1-1, 5-1] = 2.0*ClTJperm
        p.h[6-1, 1-1, 5-1] = 2.0*ClTJperm
        p.h[7-1, 1-1, 5-1] = 0.14*ClTJperm
        p.h[8-1, 1-1, 5-1] = 0.14*ClTJperm
        p.h[9-1, 1-1, 5-1] = 0.40*ClTJperm
        p.h[10-1, 1-1, 5-1] = 6.0*ClTJperm
        p.h[11-1, 1-1, 5-1] = 1.2*ClTJperm
        p.h[12-1, 1-1, 5-1] = 10.0*ClTJperm
        p.h[13-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[14-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[15-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[16-1, 1-1, 5-1] = 0.0001*ClTJperm   
            
# Values at the ES interface (5-6)
# All values are from AWM model

    areafactor = 50
    
    for p in cnt:
        p.h[1-1, 5-1, 6-1] = 240.0*areafactor
        p.h[2-1, 5-1, 6-1] = 320.0*areafactor
        p.h[3-1, 5-1, 6-1] = 320.0*areafactor
        p.h[4-1, 5-1, 6-1] = 160.0*areafactor
        p.h[5-1, 5-1, 6-1] = 240.0*areafactor
        p.h[6-1, 5-1, 6-1] = 240.0*areafactor
        p.h[7-1, 5-1, 6-1] = 160.0*areafactor
        p.h[8-1, 5-1, 6-1] = 160.0*areafactor
        p.h[9-1, 5-1, 6-1] = 160.0*areafactor
        p.h[10-1, 5-1, 6-1] = 320.0*areafactor
        p.h[11-1, 5-1, 6-1] = 320.0*areafactor
        p.h[12-1, 5-1, 6-1] = 16000.0*areafactor
        p.h[13-1, 5-1, 6-1] = 4.0*areafactor
        p.h[14-1, 5-1, 6-1] = 4.0*areafactor
        p.h[15-1, 5-1, 6-1] = 4.0*areafactor
        p.h[16-1, 5-1, 6-1] = ( p.h[1-1,5-1,6-1] ) * (7.93/13.3)            

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional Solute permeabilities
# Divide h(I,K,L) by (href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            for L in range(K, NC + 1):
                for p in cnt:
                    p.h[I-1, K-1, L-1] *= 1.0e-5 / href
                    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional NET coefficients
# dLA(I,J,K,L) = coefficient of ith and jth solute at the K-L interface
# dLA(I,J,K,L) in mmol2/J/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    dLA[I-1, J-1, K-1, L-1] = 0.0
                   
# Na/H exchangers on all basolateral membranes
    dLA[1-1,12-1,2-1,5-1] = 20.0e-9
    dLA[1-1,12-1,2-1,6-1] = 20.0e-9
    dLA[1-1,12-1,3-1,5-1] = 36.0e-9
    dLA[1-1,12-1,3-1,6-1] = 36.0e-9
    dLA[1-1,12-1,4-1,5-1] = 24.0e-9
    dLA[1-1,12-1,4-1,6-1] = 24.0e-9

# Na2/HPO4 co-transporters on all basolateral membranes
    dLA[1-1,7-1,2-1,5-1] = 2.0e-9
    dLA[1-1,7-1,2-1,6-1] = 2.0e-9
    dLA[1-1,7-1,3-1,5-1] = 1.2e-9
    dLA[1-1,7-1,3-1,6-1] = 1.2e-9
    dLA[1-1,7-1,4-1,5-1] = 0.80e-9
    dLA[1-1,7-1,4-1,6-1] = 0.80e-9

# Apical NCC in PC !!!!!!!! Removed
    xNCC = 20.0e-9 * 0
# dLA(1,3,1,2)=20.0d-9*0

# Basolateral Cl/HCO3 exchanger in PC
    dLA[3-1,4-1,2-1,5-1] = 2.0e-9
    dLA[3-1,4-1,2-1,6-1] = 2.0e-9

# Basolateral Cl/HCO3 exchanger in IC-B !!!!!!!! Removed
    dLA[3-1,4-1,4-1,5-1] = 16.0e-9 * 0
    dLA[3-1,4-1,4-1,6-1] = 16.0e-9 * 0

# AE1 in IC-A only
    xAE1 = 150e-9  # AE1 exchanger

# Transporters in IC-B only
# dLA(3,4,1,4)=136.d-9/0.17 ! for Alan's model
    dLA[3-1,4-1,1-1,4-1] = 800e-9
         
    xPendrin = 1.2 * dLA[3-1,4-1,1-1,4-1] / 1400
    
#---------------------------------------------------------------------72
# Specific calcium transporters
#---------------------------------------------------------------------72
# Basolateral NCX exchanger
    xNCX = 25.0e-9 * 1.60

# Basolateral PMCA pump
    PMCA = 2.0e-9 * 0.40

# Apical TRPV5
    xTRPV5 = 8.0e6
    
# Apical TRPV4 channel: density of channels times single channel permeability
# See Parikh et al., Biophys J 2015
    Po_TRPV4 = 1.0 / (1.0 + 780/37)
    PCa_TRPV4 = 4.5e-8
    xPTRPV4 = Po_TRPV4 * PCa_TRPV4

#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS - 1 + 1):
        for J in range(I+1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(1, NC + 1):
                        dLA[J-1, I-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional ATPase coefficients
# ATPcoeff in mmol/s or mmol
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Na-K-ATPase (basolateral in PC and IC)
    ATPNaKPES = FM_cENaC * 3410e-9 * 1.25
    ATPNaKAES = 450e-9
    ATPNaKBES = 300e-9

# H-ATPase (apical in IC-A, basolateral in IC-B)
    ATPHMA = 12000.0e-9
    ATPHBES = 400e-9 * 15
# Note: Adjusted parameter

# H-K-ATPase (apical in PC and IC)
    ATPHKMP = 0
    ATPHKMA = 720e-9
    ATPHKMB = 0.0e-9

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional coefficients
# Divide dLA(I,J,K,L) by (href)*Cref for consistency with other
# solute flux terms
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    for p in cnt:
                        p.dLA[I-1, J-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1] / (href * Cref)

    for p in cnt:
        p.xPendrin = xPendrin / (href*Cref)
        p.xAE1 = xAE1 / (href*Cref)
       
        p.xNCX = xNCX / (href*Cref)
        p.PMCA= PMCA / (href*Cref)
        
    xTRPV5_cnt = xTRPV5 / (href*Cref)
    xPTRPV4_cnt = xPTRPV4 / (href*Cref)
        
    for p in cnt:
        p.ATPNaK[2-1,5-1] = ATPNaKPES / (href*Cref)
        p.ATPNaK[2-1,6-1] = ATPNaKPES / (href*Cref)
        p.ATPNaK[3-1,5-1] = ATPNaKAES / (href*Cref)
        p.ATPNaK[3-1,6-1] = ATPNaKAES / (href*Cref)
        p.ATPNaK[4-1,5-1] = ATPNaKBES / (href*Cref)
        p.ATPNaK[4-1,6-1] = ATPNaKBES / (href*Cref)
        
        p.ATPH[1-1,3-1] = ATPHMA / (href*Cref)
        p.ATPH[4-1,5-1] = ATPHBES / (href*Cref)
        p.ATPH[4-1,6-1] = ATPHBES / (href*Cref)
        
        p.ATPHK[1-1,2-1] = ATPHKMP / (href*Cref)
        p.ATPHK[1-1,3-1] = ATPHKMA / (href*Cref)
        p.ATPHK[1-1,4-1] = ATPHKMB / (href*Cref)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Other kinetic parameters
# Units of kinetic constants are s-1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# KINETIC PARAMETERS

    dkhuncat = 0.145
    dkduncat = 49.6
    dkhP = 1.45
    dkdP = 496.0
    dkhA = 1.45e3
    dkdA = 496.0e3
    dkhB = 1.45e3
    dkdB = 496.0e3
    dkhE = 0.145e3
    dkdE = 49.6e3

    for p in cnt:
        p.dkd[1-1] = dkduncat * 10.0
        p.dkh[1-1] = dkhuncat * 10.0
        p.dkd[2-1] = dkdP
        p.dkh[2-1] = dkhP
        p.dkd[3-1] = dkdA
        p.dkh[3-1] = dkhA
        p.dkd[4-1] = dkdB
        p.dkh[4-1] = dkhB
        p.dkd[5-1] = dkdE
        p.dkh[5-1] = dkhE
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# READ ENTERING AND PERITUBULAR CONDITIONS FROM DCT OUTLET FILE
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    with open('DCToutlet', 'r') as f:
        for I in range(1, 5):
            cnt[0].conc[I-1,1-1], cnt[0].conc[I-1,6-1] = map(float, f.readline().split())
        for I in range(5, NS + 1):
            cnt[0].conc[I-1,1-1], cnt[0].conc[I-1,6-1] = map(float, f.readline().split())
        cnt[0].ph[1-1], cnt[0].ph[6-1] = map(float, f.readline().split())
        cnt[0].ep[1-1], cnt[0].ep[6-1] = map(float, f.readline().split())
        cnt[0].vol[1-1], cnt[0].pres = map(float, f.readline().split())

    for p in cnt:
        p.volLuminit = cnt[0].vol[1-1]    
        
        p.ep[6-1] = cnt[0].ep[6-1]
       
    for jz in range(0, NZ + 1):
        pos[jz] = 0  # stays near cortex surface
        
    from set_intconc import set_intconc
    set_intconc(cnt, NZ, 1, pos)

# reference impermeant concentrations
    for p in cnt:
        p.cPimpref = 50.0
        p.cAimpref = 18.0
        p.cBimpref = 18.0

# total buffer concentrations
        p.cPbuftot = 32.0
        p.cAbuftot = 40.0
        p.cBbuftot = 40.0

# initialize coalescence parameter
    for jz in range(0, NZ + 1):
        cnt[jz].coalesce = 2.00 ** (-2.32 * (jz)/NZ )

#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------72

    for p in cnt:
        p.TQ = 15.0 if not bdiabetes else 12.0 
        # !TNa-QO2 ratio in normal CNT, else TNa-QO2 ratio in diabetic CNT
        
#--------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------72
       
    elecM = 0.0
    elecS = 0.0
    elecS_out = 0.0
    
    for I in range(1, NS + 1):
        elecM += zval[I-1] * cnt[0].conc[I-1,1-1]
        elecS += zval[I-1] * cnt[0].conc[I-1,6-1]
        elecS_out += zval[I-1] * ( cnt[NZ].conc[I-1,6-1] )

    return
