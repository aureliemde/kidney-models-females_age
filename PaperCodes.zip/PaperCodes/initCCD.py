# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine.
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 


def initCCD(ccd):
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
    Pf = np.zeros((NC,NC))
    dLA = np.zeros((NS,NS,NC,NC))

    pos = np.zeros(NZ+1)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Solute Indices: 1 = Na+, 2 = K+, 3 = Cl-, 4 = HCO3-, 5 = H2CO3, 6 = CO2
# 7 = HPO4(2-), 8 = H2PO4-, 9 = urea, 10 = NH3, 11 = NH4+, 12 = H+
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Data for rat (AMW model, AJP Renal 2005)
#---------------------------------------------------------------------

# tubular length and luminal diameter

    for p in ccd:
        p.dimL = dimLCCD
        p.diam = DiamCCD

    SlumPinitccd = 1.2
    SbasPinitccd = 1.2
    SlatPinitccd = 6.9
    
    SlumAinitccd = 0.58
    SbasAinitccd = 0.58
    SlatAinitccd = 1.25
    
    SlumBinitccd = 0.17
    SbasBinitccd = 0.17
    SlatBinitccd = 1.50  
    
    SlumEinitccd = 0.001

    for p in ccd:
        p.sbasEinit = 0.020
        
        p.volPinit = 4.0  
        p.volAinit = 1.8  
        p.volBinit = 1.2  
        p.volEinit = 0.20
       
#---------------------------------------------------------------------72
# Assign membrane surface area except for basal membrane of E
#---------------------------------------------------------------------72        
        
    for p in ccd:
        p.area[1-1, 2-1] = SlumPinitccd
        p.area[1-1, 3-1] = SlumAinitccd
        p.area[1-1, 4-1] = SlumBinitccd
        p.area[1-1, 5-1] = SlumEinitccd
        
        p.area[2-1, 5-1] = SlatPinitccd
        p.area[3-1, 5-1] = SlatAinitccd
        p.area[4-1, 5-1] = SlatBinitccd
        
        p.area[2-1, 6-1] = SbasPinitccd
        p.area[3-1, 6-1] = SbasAinitccd
        p.area[4-1, 6-1] = SbasBinitccd

    for K in range(1, NC -1 +1):
        for L in range(K + 1, NC + 1):
            for p in ccd:
                p.area[L-1, K-1] = p.area[K-1, L-1]

    for p in ccd:
        p.zPimp = -1.0
        p.zAimp = -1.0
        p.zBimp = -1.0
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Water permeabilities
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# The permeabilities have already been multiplied by the area (cm2/cm2 epith)
# dLPV(K,L) = hydraulic permeability at the K-L interface
# dLPV(K,L) in cm/s/mmHg
# Pf(K,L) = osmotic permeability at the K-L interface
# Pf(K,L) in cm/s
# Relationship between the two: LPV=Pf*(Vwbar/RT)
# WATER PERMEABILITIES
 
    PfMP = 2.4 * 0.20/1.2
    PfPE = 2.4 * 0.11*3  # factor of 3 from DN model
    PfPS = 2.4 * 0.11*3  # factor of 3 from DN model
    
    PfMA = 0.22e-3
    PfAE = 5.50e-3
    PfAS = 5.50e-3
    
    PfMB = 0.22e-3
    PfBE = 5.50e-3
    PfBS = 5.50e-3
    
    PfME = 1.1
    PfES = 110
    
    Pf = np.zeros((NC, NC))

    Pf[1-1,2-1] = PfMP
    Pf[1-1,3-1] = PfMA
    Pf[1-1,4-1] = PfMB
    Pf[1-1,5-1] = PfME
    Pf[2-1,5-1] = PfPE
    Pf[3-1,5-1] = PfAE
    Pf[4-1,5-1] = PfBE
    Pf[2-1,6-1] = PfPS
    Pf[3-1,6-1] = PfAS
    Pf[4-1,6-1] = PfBS
    Pf[5-1,6-1] = PfES
    
# Units of dimensional water flux: cm3/s/cm2 epith
# Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
# Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
# dLPV = Pf/Pfref

    for K in range(1, NC + 1):
        for L in range(1, NC + 1):
            for p in ccd:
                p.dLPV[K-1, L-1] = Pf[K-1, L-1] / Pfref

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# sig(I,K,L) = reflection coefficient of Ith solute between K and L
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(1, NC + 1):
                for p in ccd:
                    p.sig[i-1, k-1, l-1] = 1.0
            
# Values at the basement membrane (ES)
    for i in range(1, NS + 1):
        for p in ccd:
            p.sig[i-1, 5-1, 6-1] = 0.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional Solute permeabilities
# h(I,K,L) = permeability of ith solute at the K-L interface
# h(I,K,L) in 10-5 cm/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    PICAchlo = 10.0
    PICBchlo = 3.20
    PPCh2co3 = 130
    PICh2co3 = 10
    PPCco2 = 15.0e3
    PICco2 = 900
    PPChpo4 = 8.00e-3
    PICAhpo4 = 4.80e-3
    PICBhpo4 = 4.80e-3
    PPCprot = 2000
    PICAprot = 9.0
    PICBprot = 6.0
    PPCamon = 2000
    PICamon = 900
    Purea = 0.10
    
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in ccd:
                    p.h[i-1, k-1, l-1] = 0.0

    fac4 = 1.0/4.0
    fac6 = 1.0/1.0
    fac9 = 1.0/1.0
    
# Values at the MP interface (1-2)
# ENaC activity modified by local factors, including pH. Use hENaC_CCD as basal
# value of expression
# ccd(:)%hNaMP = 14.00*fac4*fscaleENaC ! - Not used, replaced with hENaC

    fscaleENaC = 2.50
    fscaleNaK = 1.25
    fscaleNaK_PC = 1.25
    
# Female-to-male ENaC expression ratio in cortex (CNT and CCD)
    FM_cENaC = 1.20 * 0.85

# ENaC activity modified by local factors, including pH. Use hENaC_CNT as basal value of expression
### - FEMALE ADJUSTMENT ENaC x 1.20
    hENaC_CCD = FM_cENaC * 35.00 * fac4

# ROMK activity modified by local factors, including pH. Use hROMK_CCD as basal
# value of expression
# ccd(:)%h(2,1,2) = 8.0d0*fac4 - Not used, replaced with hROMK
    hROMK_CCD = 8.0 * fac4

    for p in ccd:
        p.h[3-1,1-1,2-1] = 0.80 * fac4
        p.h[4-1,1-1,2-1] = 0.16 * fac4
        p.h[5-1,1-1,2-1] = PPCh2co3
        p.h[6-1,1-1,2-1] = PPCco2
        p.h[7-1,1-1,2-1] = 1.0e-3/1.20  # as in CNT - Different in AMW model
        p.h[8-1,1-1,2-1] = 1.0e-3/1.20  # as in CNT - Different in AMW model
        p.h[9-1,1-1,2-1] = Purea
        p.h[10-1,1-1,2-1] = PPCamon
        p.h[11-1,1-1,2-1] = p.h[2-1,1-1,2-1] * 0.20  #AMW rule of thumb
        p.h[12-1,1-1,2-1] = PPCprot * fac4
        p.h[13-1,1-1,2-1] = 0.0
        p.h[14-1,1-1,2-1] = 0.0
        p.h[15-1,1-1,2-1] = 0.0
        p.h[16-1,1-1,2-1] = 0.00010
        
# Values at the PE interface (2-5)
        p.h[1-1, 2-1, 5-1] = 0.000
        p.h[2-1, 2-1, 5-1] = 4 * fac4
        p.h[3-1, 2-1, 5-1] = 0.2 * fac4
        p.h[4-1, 2-1, 5-1] = p.h[3-1,2-1,5-1] * 0.20  #AMW rule of thumb
        p.h[5-1, 2-1, 5-1] = PPCh2co3
        p.h[6-1, 2-1, 5-1] = PPCco2
        p.h[7-1, 2-1, 5-1] = 8.0e-3  # as in CNT - Different in AMW model
        p.h[8-1, 2-1, 5-1] = 8.0e-3  # as in CNT - Different in AMW model
        p.h[9-1, 2-1, 5-1] = Purea
        p.h[10-1, 2-1, 5-1] = PPCamon
        p.h[11-1, 2-1, 5-1] = p.h[2-1,2-1,5-1] * 0.20  #AMW rule of thumb
        p.h[12-1, 2-1, 5-1] = PPCprot * fac4
        p.h[13-1, 2-1, 5-1] = 1.0e-4
        p.h[14-1, 2-1, 5-1] = 1.0e-4
        p.h[15-1, 2-1, 5-1] = 1.0e-4
        p.h[16-1, 2-1, 5-1] = 0.00010
                
# Values at the MA interface (1-3)

        p.h[1-1,1-1,3-1] = 0.0
        p.h[2-1,1-1,3-1] = 0.00  
        p.h[3-1,1-1,3-1] = 0.0
        p.h[4-1,1-1,3-1] = 0.0
        p.h[5-1,1-1,3-1] = PICh2co3
        p.h[6-1,1-1,3-1] = PICco2
        p.h[7-1,1-1,3-1] = 0.0
        p.h[8-1,1-1,3-1] = 0.0
        p.h[9-1,1-1,3-1] = Purea
        p.h[10-1,1-1,3-1] = PICamon
        p.h[11-1,1-1,3-1] = 0.00
        p.h[12-1,1-1,3-1] = 0.0
        p.h[13-1,1-1,3-1] = 0.0
        p.h[14-1,1-1,3-1] = 0.0
        p.h[15-1,1-1,3-1] = 0.0
        p.h[16-1,1-1,3-1] = 0.00010  # TO BE ADJUSTED

# Values at the AE interface (3-5)

        p.hCLCA = PICAchlo  # Different in AMW model
    
        p.h[1-1,3-1,5-1] = 0.0
        p.h[2-1,3-1,5-1] = 0.050
        p.h[3-1,3-1,5-1] = 1.20
        p.h[4-1,3-1,5-1] = 0.18
        p.h[5-1,3-1,5-1] = PICh2co3
        p.h[6-1,3-1,5-1] = PICco2
        p.h[7-1,3-1,5-1] = 0.0120  # Different in AMW model
        p.h[8-1,3-1,5-1] = 0.0120  # Different in AMW model
        p.h[9-1,3-1,5-1] = Purea
        p.h[10-1,3-1,5-1] = PICamon
        p.h[11-1,3-1,5-1] = 0.030
        p.h[12-1,3-1,5-1] = 1.50
        p.h[13-1,3-1,5-1] = 1.0e-4
        p.h[14-1,3-1,5-1] = 1.0e-4
        p.h[15-1,3-1,5-1] = 1.0e-4
        p.h[16-1,3-1,5-1] = 0.00010  # TO BE ADJUSTED

# Values at the MB interface (1-4)
        p.h[1-1,1-1,4-1] = 0.0
        p.h[2-1,1-1,4-1] = 0.0  
        p.h[3-1,1-1,4-1] = 0.0
        p.h[4-1,1-1,4-1] = 0.0
        p.h[5-1,1-1,4-1] = PICh2co3
        p.h[6-1,1-1,4-1] = PICco2
        p.h[7-1,1-1,4-1] = 0.0
        p.h[8-1,1-1,4-1] = 0.0
        p.h[9-1,1-1,4-1] = Purea
        p.h[10-1,1-1,4-1] = PICamon
        p.h[11-1,1-1,4-1] = 0.0
        p.h[12-1,1-1,4-1] = 0.0
        p.h[13-1,1-1,4-1] = 0.0
        p.h[14-1,1-1,4-1] = 0.0
        p.h[15-1,1-1,4-1] = 0.0
        p.h[16-1,1-1,4-1] = 0.00010

# Values at the BE interface (4-5)
        p.hCLCB = PICBchlo
        p.h[1-1,4-1,5-1] = 0.0
        p.h[2-1,4-1,5-1] = 0.12 * fac4
        p.h[3-1,4-1,5-1] = PICBchlo * fac4
# ccd(:)%h(4,4,5) = ccd(:)%h(3,4,5)*0.20d0 !AMW rule of thumb
        p.h[4-1,4-1,5-1] = 0.40 * fac4
        p.h[5-1,4-1,5-1] = PICh2co3
        p.h[6-1,4-1,5-1] = PICco2
        # p.h[7-1,4-1,5-1] = PICBhpo4 * fac4
        # p.h[8-1,4-1,5-1] = PICBhpo4 * fac4
        p.h[7-1,4-1,5-1] = 0.120  # Different in AMW model
        p.h[8-1,4-1,5-1] = 0.120  # Different in AMW model
        p.h[9-1,4-1,5-1] = Purea
        p.h[10-1,4-1,5-1] = PICamon
        p.h[11-1,4-1,5-1] = 0.12 * fac4
        p.h[12-1,4-1,5-1] = PICBprot * fac4
        p.h[13-1,4-1,5-1] = 1.0e-4
        p.h[14-1,4-1,5-1] = 1.0e-4
        p.h[15-1,4-1,5-1] = 1.0e-4
        p.h[16-1,4-1,5-1] = 0.00010

# Values at basal interfaces (2-6), (3-6), (4-6)

    for I in range(1, NS + 1):
        for p in ccd:
            p.h[I-1, 2-1, 6-1] = p.h[I-1, 2-1, 5-1]
            p.h[I-1, 3-1, 6-1] = p.h[I-1, 3-1, 5-1]
            p.h[I-1, 4-1, 6-1] = p.h[I-1, 4-1, 5-1]
            
# Values at the ME interface (1-5)
# Account for factor 2 increase (DN model, 2008)
    ClTJperm = 1000.0  
     
    for p in ccd:
        p.h[1-1, 1-1, 5-1] = (1.00 / FM_cENaC) * 1.0*ClTJperm
        p.h[2-1, 1-1, 5-1] = (1.00 / FM_cENaC) * 1.2*ClTJperm
        
# Cl permeability modified by local factors, including pH. Use hCltj_CNT as basal
# value of expression
# ccd(:)%h(3,1,5) = ClTJperm*1.2d0 - Not used, replaced with hCltj

        hCltj_CCD = 1.3 * ClTJperm * 1.2
        p.h[4-1, 1-1, 5-1] = 0.3*ClTJperm  # Changed from 0.15 on 04/30/19
        p.h[5-1, 1-1, 5-1] = 2.0*ClTJperm
        p.h[6-1, 1-1, 5-1] = 2.0*ClTJperm
        p.h[7-1, 1-1, 5-1] = 0.14*ClTJperm
        p.h[8-1, 1-1, 5-1] = 0.14*ClTJperm
        p.h[9-1, 1-1, 5-1] = 0.40*ClTJperm
        p.h[10-1, 1-1, 5-1] = 6.0*ClTJperm
        p.h[11-1, 1-1, 5-1] = 1.2*ClTJperm
        p.h[12-1, 1-1, 5-1] = 10.0*ClTJperm
        p.h[13-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[14-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[15-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[16-1, 1-1, 5-1] = 0.0140 * ClTJperm  # See my 2015 AJP and Carney 1988   
            
# Values at the ES interface (5-6)

    areafactor = 100
    
    for p in ccd:
        p.h[1-1, 5-1, 6-1] = 97*areafactor
        p.h[2-1, 5-1, 6-1] = 130.0*areafactor
        p.h[3-1, 5-1, 6-1] = 130.0*areafactor
        p.h[4-1, 5-1, 6-1] = 65.0*areafactor
        p.h[5-1, 5-1, 6-1] = 97.0*areafactor
        p.h[6-1, 5-1, 6-1] = 97.0*areafactor
        p.h[7-1, 5-1, 6-1] = 65.0*areafactor
        p.h[8-1, 5-1, 6-1] = 65.0*areafactor
        p.h[9-1, 5-1, 6-1] = 65.0*areafactor
        p.h[10-1, 5-1, 6-1] = 130.0*areafactor
        p.h[11-1, 5-1, 6-1] = 130.0*areafactor
        p.h[12-1, 5-1, 6-1] = 6490.0*areafactor
        p.h[13-1, 5-1, 6-1] = 4.0*areafactor
        p.h[14-1, 5-1, 6-1] = 4.0*areafactor
        p.h[15-1, 5-1, 6-1] = 4.0*areafactor
        p.h[16-1, 5-1, 6-1] = ( p.h[1-1,5-1,6-1] ) * (7.93/13.3)            

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional Solute permeabilities
# Divide h(I,K,L) by (href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            for L in range(K, NC + 1):
                for p in ccd:
                    p.h[I-1, K-1, L-1] *= 1.0e-5 / href
                    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional NET coefficients
# dLA(I,J,K,L) = coefficient of ith and jth solute at the K-L interface
# dLA(I,J,K,L) in mmol2/J/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    dLA[I-1, J-1, K-1, L-1] = 0.0
                   
# Na/H exchangers on all basolateral membranes
    dLA[1-1,12-1,2-1,5-1] = 20.0e-9 * fac4
    dLA[1-1,12-1,2-1,6-1] = 20.0e-9 * fac4
    dLA[1-1,12-1,3-1,5-1] = 24.0e-9 * fac4
    dLA[1-1,12-1,3-1,6-1] = 24.0e-9 * fac4
    dLA[1-1,12-1,4-1,5-1] = 24.0e-9 * fac4
    dLA[1-1,12-1,4-1,6-1] = 24.0e-9 * fac4

# Na2/HPO4 co-transporters on all basolateral membranes
    dLA[1-1,7-1,2-1,5-1] = 2.0e-9
    dLA[1-1,7-1,2-1,6-1] = 2.0e-9
    dLA[1-1,7-1,3-1,5-1] = 0.80e-9
    dLA[1-1,7-1,3-1,6-1] = 0.80e-9
    dLA[1-1,7-1,4-1,5-1] = 0.80e-9
    dLA[1-1,7-1,4-1,6-1] = 0.80e-9

# Basolateral Cl/HCO3 exchanger in PC
    dLA[3-1,4-1,2-1,5-1] = 2.0e-9 * fac4
    dLA[3-1,4-1,2-1,6-1] = 2.0e-9 * fac4

# Basolateral Cl/HCO3 exchanger in IC-B !!!!!!!! Removed
    dLA[3-1,4-1,4-1,5-1] = 16.0e-9 * fac4 * 0
    dLA[3-1,4-1,4-1,6-1] = 16.0e-9 * fac4 * 0

# AE1 in IC-A only
    xAE1 = 15e-9 * 0.20  # AE1 exchanger
# Density of AE1 times 0.20 in DN model (AMW 2008)    
    
# Transporters in IC-B only
    dLA[3-1,4-1,1-1,4-1] = 800e-9 * fac4
    
# Changed for female    
    xPendrin = 1.2 * dLA[3-1,4-1,1-1,4-1] / 1700
    
    xNDBCE = 0.00  # NDCBE

#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS - 1 + 1):
        for J in range(I+1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(1, NC + 1):
                        dLA[J-1, I-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional ATPase coefficients
# ATPcoeff in mmol/s or mmol
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Na-K-ATPase (basolateral in PC and IC)
    ATPNaKPES = FM_cENaC * 3410e-9 * 1.25 * fac4
    ATPNaKAES = 300e-9 * fac4
    ATPNaKBES = 300e-9 * fac4

# H-ATPase (apical in IC-A, basolateral in IC-B)
    ATPHMA = 1000.0e-9
    ATPHBES = 400e-9 * 15 * fac4
# Note: Adjusted parameter

# H-K-ATPase (apical in PC and IC)
    ATPHKMP = 0
    ATPHKMA = 60.0e-9
    ATPHKMB = 0.0e-9

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional coefficients
# Divide dLA(I,J,K,L) by (href)*Cref for consistency with other
# solute flux terms
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    for p in ccd:
                        p.dLA[I-1, J-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1] / (href * Cref)

    for p in ccd:
        p.xPendrin = xPendrin / (href*Cref)
        p.xAE1 = xAE1 / (href*Cref)
        p.xNDBCE = xNDBCE/(href*Cref)
        
        p.ATPNaK[2-1,5-1] = ATPNaKPES / (href*Cref)
        p.ATPNaK[2-1,6-1] = ATPNaKPES / (href*Cref)
        p.ATPNaK[3-1,5-1] = ATPNaKAES / (href*Cref)
        p.ATPNaK[3-1,6-1] = ATPNaKAES / (href*Cref)
        p.ATPNaK[4-1,5-1] = ATPNaKBES / (href*Cref)
        p.ATPNaK[4-1,6-1] = ATPNaKBES / (href*Cref)
        
        p.ATPH[1-1,3-1] = ATPHMA / (href*Cref)
        p.ATPH[4-1,5-1] = ATPHBES / (href*Cref)
        p.ATPH[4-1,6-1] = ATPHBES / (href*Cref)
        
        p.ATPHK[1-1,2-1] = ATPHKMP / (href*Cref)
        p.ATPHK[1-1,3-1] = ATPHKMA / (href*Cref)
        p.ATPHK[1-1,4-1] = ATPHKMB / (href*Cref)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Other kinetic parameters
# Units of kinetic constants are s-1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# KINETIC PARAMETERS

    dkhuncat = 0.145
    dkduncat = 49.6
    dkhP = 1.45
    dkdP = 496.0
    dkhA = 1.45e3
    dkdA = 496.0e3
    dkhB = 1.45e3
    dkdB = 496.0e3
    dkhE = 0.145e3
    dkdE = 49.6e3

    for p in ccd:
        p.dkd[1-1] = dkduncat * 10.0
        p.dkh[1-1] = dkhuncat * 10.0
        p.dkd[2-1] = dkdP
        p.dkh[2-1] = dkhP
        p.dkd[3-1] = dkdA
        p.dkh[3-1] = dkhA
        p.dkd[4-1] = dkdB
        p.dkh[4-1] = dkhB
        p.dkd[5-1] = dkdE
        p.dkh[5-1] = dkhE
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# READ ENTERING AND PERITUBULAR CONDITIONS FROM DCT OUTLET FILE
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    with open('CNToutlet', 'r') as f:
        for I in range(1, 5):
            ccd[0].conc[I-1,1-1], ccd[0].conc[I-1,6-1] = map(float, f.readline().split())
        for I in range(5, NS + 1):
            ccd[0].conc[I-1,1-1], ccd[0].conc[I-1,6-1] = map(float, f.readline().split())
        ccd[0].ph[1-1], ccd[0].ph[6-1] = map(float, f.readline().split())
        ccd[0].ep[1-1], ccd[0].ep[6-1] = map(float, f.readline().split())
        ccd[0].vol[1-1], ccd[0].pres = map(float, f.readline().split())

    for p in ccd:
        p.volLuminit = ccd[0].vol[1-1]    
        
        p.ep[6-1] = ccd[0].ep[6-1]
       
    for jz in range(0, NZ + 1):
        pos[jz] = 1.0 * jz / NZ  
        
    from set_intconc import set_intconc
    set_intconc(ccd, NZ, 1, pos)

# reference impermeant concentrations
    for p in ccd:
        p.cPimpref = 50.0
        p.cAimpref = 18.0
        p.cBimpref = 18.0

# total buffer concentrations
        p.cPbuftot = 32.0
        p.cAbuftot = 40.0
        p.cBbuftot = 40.0

# coalescence parameter
        p.coalesce = 0.2

#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------72

    for p in ccd:
        p.TQ = 15.0 if not bdiabetes else 12.0 
        # !TNa-QO2 ratio in normal CCD, else TNa-QO2 ratio in diabetic CCD
        
#--------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------72
       
    elecM = 0.0
    elecS = 0.0
    elecS_out = 0.0
    
    for I in range(1, NS + 1):
        elecM += zval[I-1] * ccd[0].conc[I-1,1-1]
        elecS += zval[I-1] * ccd[0].conc[I-1,6-1]
        elecS_out += zval[I-1] * ( ccd[NZ].conc[I-1,6-1] )

    return
