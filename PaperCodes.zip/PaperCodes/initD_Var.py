# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine for DCT.
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 

def initD_Var(dct):
    
# local variables
    Pf = np.zeros((NC,NC))
    dLA = np.zeros((NS,NS,NC,NC))

    pos = np.zeros(NZ+1)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Calculate initial surfaces and volumes
# Volumes, surfaces, and angles implicitly include the number of
# each type of cell (but the PtoIratio doesn't).
#---------------------------------------------------------------------72
# Data for rat (AMW model, AJP Renal 2005)
#---------------------------------------------------------------------

    SlumPinitdct = 4.7
    SbasPinitdct = 4.7
    SlatPinitdct = 64.3

    SlumEinitdct = 0.001

    for p in dct:        
        p.sbasEinit = 0.020
    
    VolPinitdct = 7.5
    VolEinitdct = 0.80
    
    for p in dct:
        p.volPinit = 7.5
        p.volEinit = 0.80

        p.volAinit = 7.5
        p.volBinit = 7.5

    SlumAinitdct = 1.0
    SbasAinitdct = 1.0
    SlatAinitdct = 1.0
    SlumBinitdct = 1.0
    SbasBinitdct = 1.0
    SlatBinitdct = 1.0
    VolAinitdct = 1.0
    VolBinitdct = 1.0
#---------------------------------------------------------------------72
# Assign membrane surface area except for basal membrane of E
#---------------------------------------------------------------------72        
        
    for p in dct:
        p.area[1-1, 2-1] = SlumPinitdct
        p.area[1-1, 3-1] = SlumAinitdct
        p.area[1-1, 4-1] = SlumBinitdct
        p.area[1-1, 5-1] = SlumEinitdct
        
        p.area[2-1, 5-1] = SlatPinitdct
        p.area[3-1, 5-1] = SlatAinitdct
        p.area[4-1, 5-1] = SlatBinitdct
        
        p.area[2-1, 6-1] = SbasPinitdct
        p.area[3-1, 6-1] = SbasAinitdct
        p.area[4-1, 6-1] = SbasBinitdct

    for K in range(1, NC -1 +1):
        for L in range(K + 1, NC + 1):
            for p in dct:
                p.area[L-1, K-1] = p.area[K-1, L-1]
                 
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Water permeabilities
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    PfMP = 2.4 * 0.00117
    PfMA = 0.0
    PfMB = 0.0
    PfME = 2.0
    PfPE = 2.4 * 0.00835
    PfAE = 0.0
    PfBE = 0.0
    PfPS = 2.4 * 0.00835
    PfAS = 0.0
    PfBS = 0.0
    PfES = 35.5
    
    Pf = np.zeros((NC, NC))

    Pf[1-1,2-1] = PfMP
    Pf[1-1,3-1] = PfMA
    Pf[1-1,4-1] = PfMB
    Pf[1-1,5-1] = PfME
    Pf[2-1,5-1] = PfPE
    Pf[3-1,5-1] = PfAE
    Pf[4-1,5-1] = PfBE
    Pf[2-1,6-1] = PfPS
    Pf[3-1,6-1] = PfAS
    Pf[4-1,6-1] = PfBS
    Pf[5-1,6-1] = PfES
    
# Units of dimensional water flux: cm3/s/cm2 epith
# Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
# Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
# dLPV = Pf/Pfref

    for K in range(1, NC + 1):
        for L in range(1, NC + 1):
            for p in dct:
                p.dLPV[K-1, L-1] = Pf[K-1, L-1] / Pfref

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# sig(I,K,L) = reflection coefficient of Ith solute between K and L
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(1, NC + 1):
                for p in dct:
                    p.sig[i-1, k-1, l-1] = 1.0
            
# Values at the basement membrane (ES)
    for i in range(1, NS + 1):
        for p in dct:
            p.sig[i-1, 5-1, 6-1] = 0.0
            p.sig[i-1, 6-1, 5-1] = 0.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional Solute permeabilities
# h(I,K,L) = permeability of ith solute at the K-L interface
# h(I,K,L) in 10-5 cm/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in dct:
                    p.h[i-1, k-1, l-1] = 0.0

# Values at the MP interface (1-2)
    for p in dct:
        p.hNaMP = 14.00*0.25  # maximum ENaC perm, factor of 1/4 for surface area
        
        p.h[1-1, 1-1, 2-1] = 0.072
        p.h[2-1, 1-1, 2-1] = 0.60
        p.h[3-1, 1-1, 2-1] = 0.0
        p.h[4-1, 1-1, 2-1] = 0.0
        p.h[5-1, 1-1, 2-1] = 130
        p.h[6-1, 1-1, 2-1] = 1.50e4
        p.h[7-1, 1-1, 2-1] = 0.0
        p.h[8-1, 1-1, 2-1] = 0.0
        p.h[9-1, 1-1, 2-1] = 0.20
        p.h[10-1, 1-1, 2-1] = 200
        p.h[11-1, 1-1, 2-1] = 0.12
        p.h[12-1, 1-1, 2-1] = 0.20
        p.h[13-1, 1-1, 2-1] = 0
        p.h[14-1, 1-1, 2-1] = 0
        p.h[15-1, 1-1, 2-1] = 0.0
        p.h[16-1, 1-1, 2-1] = 0.0
        
# Values at the PE interface (2-5)
        p.h[1-1, 2-1, 5-1] = 0.000
        p.h[2-1, 2-1, 5-1] = 0.12
        p.h[3-1, 2-1, 5-1] = 0.04
        p.h[4-1, 2-1, 5-1] = 0.02
        p.h[5-1, 2-1, 5-1] = 130
        p.h[6-1, 2-1, 5-1] = 1.50e4
        p.h[7-1, 2-1, 5-1] = 0.002
        p.h[8-1, 2-1, 5-1] = 0.002
        p.h[9-1, 2-1, 5-1] = 0.2
        p.h[10-1, 2-1, 5-1] = 200
        p.h[11-1, 2-1, 5-1] = 0.0234
        p.h[12-1, 2-1, 5-1] = 0.20
        p.h[13-1, 2-1, 5-1] = 1.0e-4
        p.h[14-1, 2-1, 5-1] = 1.0e-4
        p.h[15-1, 2-1, 5-1] = 1.0e-4
        p.h[16-1, 2-1, 5-1] = 0.0
                
# Values at the PS interface (2-6)
    for i in range(1, NS + 1):
        for p in dct:
            p.h[i-1, 2-1, 6-1] = p.h[i-1, 2-1, 5-1]
            
# Values at the MA interface (1-3)
# Values at the AE interface (3-5)
# Values at the AS interface (3-6)
# Values at the MB interface (1-4)
# Values at the BE interface (4-5)
# Values at the BS interface (4-6)

    for I in range(1, NS + 1):
        for p in dct:
            p.h[I-1, 1-1, 3-1] = 0
            p.h[I-1, 3-1, 5-1] = 0
            p.h[I-1, 3-1, 6-1] = 0
            p.h[I-1, 1-1, 4-1] = 0
            p.h[I-1, 4-1, 5-1] = 0
            p.h[I-1, 4-1, 6-1] = 0
            
# Values at the ME interface (1-5)
    ClTJperm = 1000.0  # Factor for area = 1/0.001
    
    for p in dct:
        p.h[1-1, 1-1, 5-1] = 0.80*ClTJperm
        p.h[2-1, 1-1, 5-1] = 0.80*ClTJperm
        
        p.h[3-1, 1-1, 5-1] = 1.3 * 0.50*ClTJperm  
          
        p.h[4-1, 1-1, 5-1] = 0.50*ClTJperm
        p.h[5-1, 1-1, 5-1] = 0.50*ClTJperm
        p.h[6-1, 1-1, 5-1] = 0.50*ClTJperm
        p.h[7-1, 1-1, 5-1] = 0.10*ClTJperm
        p.h[8-1, 1-1, 5-1] = 0.10*ClTJperm
        p.h[9-1, 1-1, 5-1] = 0.20*ClTJperm
        p.h[10-1, 1-1, 5-1] = 0.80*ClTJperm
        p.h[11-1, 1-1, 5-1] = 0.80*ClTJperm
        p.h[12-1, 1-1, 5-1] = 0.80*ClTJperm
        p.h[13-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[14-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[15-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[16-1, 1-1, 5-1] = 0.0001*ClTJperm   # TO BE ADJUSTED   
            
# Values at the ES interface (5-6)
    areafactor = 1 / 0.02
    
    for p in dct:
        p.h[1-1, 5-1, 6-1] = 63.0*areafactor
        p.h[2-1, 5-1, 6-1] = 84.0*areafactor
        p.h[3-1, 5-1, 6-1] = 84.0*areafactor
        p.h[4-1, 5-1, 6-1] = 42.0*areafactor
        p.h[5-1, 5-1, 6-1] = 63.0*areafactor
        p.h[6-1, 5-1, 6-1] = 63.0*areafactor
        p.h[7-1, 5-1, 6-1] = 42.0*areafactor
        p.h[8-1, 5-1, 6-1] = 42.0*areafactor
        p.h[9-1, 5-1, 6-1] = 42.0*areafactor
        p.h[10-1, 5-1, 6-1] = 52.0*areafactor
        p.h[11-1, 5-1, 6-1] = 84.0*areafactor
        p.h[12-1, 5-1, 6-1] = 419.0*areafactor
        p.h[13-1, 5-1, 6-1] = 1.0*areafactor
        p.h[14-1, 5-1, 6-1] = 1.0*areafactor
        p.h[15-1, 5-1, 6-1] = 1.0*areafactor
        p.h[16-1, 5-1, 6-1] = ( p.h[1-1,5-1,6-1] ) * (7.93/13.3)            

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional Solute permeabilities
# Divide h(I,K,L) by (href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            for L in range(K, NC + 1):
                for p in dct:
                    p.h[I-1, K-1, L-1] *= 1.0e-5 / href
                    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional NET coefficients
# dLA(I,J,K,L) = coefficient of ith and jth solute at the K-L interface
# dLA(I,J,K,L) in mmol2/J/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    dLA[I-1, J-1, K-1, L-1] = 0.0
                    
# Apical NHE2/3 in PC
    xNHE3 = 200.0e-9

# Apical NCC in PC
    xNCC = 1.8 * 15.0e-9
                
# Apical and basolateral K-Cl in PC
    dLA[2-1, 3-1, 1-1, 2-1] = 4.0e-9
    dLA[2-1, 3-1, 2-1, 5-1] = 20.0e-9
    dLA[2-1, 3-1, 2-1, 6-1] = 20.0e-9

# Basolateral Na/H exchanger
    dLA[1-1, 12-1, 2-1, 5-1] = 4.0e-9
    dLA[1-1, 12-1, 2-1, 6-1] = 4.0e-9
    
    xNHE1 = 6.95e-10

# Basolateral Cl/HCO3 exchanger
    dLA[3-1, 4-1, 2-1, 5-1] = 15.0e-9
    dLA[3-1, 4-1, 2-1, 6-1] = 15.0e-9

# Basolateral Na/HPO4 co-transporter
    dLA[1-1, 7-1, 2-1, 5-1] = 0.2e-9
    dLA[1-1, 7-1, 2-1, 6-1] = 0.2e-9

# Na-K-ATPase (basolateral in PC and IC)
    ATPNaKPES = 1.8 * 400.0e-9

#---------------------------------------------------------------------72
# Specific calcium transporters
#---------------------------------------------------------------------72
# Basolateral NCX exchanger
    xNCX = 50.0e-9 * 1.40

# Basolateral PMCA pump
    PMCA = 0.70e-9 * 0.60

# Apical TRPV5
    xTRPV5 = 13.5e6

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional coefficients
# Divide dLA(I,J,K,L) by (href)*Cref for consistency with other
# solute flux terms
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72    
    
    for I in range(1, NS - 1 + 1):
        for J in range(I+1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(1, NC + 1):
                        dLA[J-1, I-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1]

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    for p in dct:
                        p.dLA[I-1, J-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1] / (href * Cref)

    for p in dct:
        p.xNCC = xNCC/(href*Cref)
        p.xNHE3 = xNHE3/(href*Cref)
        
        p.xNCX = xNCX/(href*Cref)
        p.PMCA= PMCA/(href*Cref)
        xTRPV5_dct = xTRPV5/(href*Cref)
        
        p.ATPNaK[2-1,5-1] = ATPNaKPES/(href*Cref)
        p.ATPNaK[2-1,6-1] = ATPNaKPES/(href*Cref)
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Other kinetic parameters
# Units of kinetic constants are s-1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    dkhuncat = 0.145
    dkduncat = 49.6
    dkhP = 145
    dkdP = 49600
    dkhE = 145
    dkdE = 49600
    
    for p in dct:
        p.dkd[1-1] = dkduncat * 10.0
        p.dkh[1-1] = dkhuncat * 10.0
        p.dkd[2-1] = dkdP
        p.dkh[2-1] = dkhP
        p.dkd[5-1] = dkdE
        p.dkh[5-1] = dkhE
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# READ ENTERING AND PERITUBULAR CONDITIONS FROM TAL OUTLET FILE
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    with open('cTALoutlet', 'r') as f:
        for I in range(1, 5):
            dct[0].conc[I-1,1-1], dct[0].conc[I-1,6-1] = map(float, f.readline().split())
        for I in range(5, NS + 1):
            dct[0].conc[I-1,1-1], dct[0].conc[I-1,6-1] = map(float, f.readline().split())
        dct[0].ph[1-1], dct[0].ph[6-1] = map(float, f.readline().split())
        dct[0].ep[1-1], dct[0].ep[6-1] = map(float, f.readline().split())
        dct[0].vol[1-1], dct[0].pres = map(float, f.readline().split())

    for p in dct:
        p.volLuminit = dct[0].vol[1-1]    
        p.ep[6-1] = dct[0].ep[6-1]
        
    for jz in range(0, NZ + 1):
        pos[jz] = 0  # twirls around the cortical surface

    from set_intconc import set_intconc
    set_intconc(dct, NZ, 1, pos)

#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------72

    for p in dct:
        p.TQ = 15.0 if not bdiabetes else 12.0 
        # !TNa-QO2 ratio in normal DCT, else TNa-QO2 ratio in diabetic DCT
        
#--------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------72
       
    elecM = 0.0
    elecS = 0.0
    elecS_out = 0.0
    
    for I in range(1, NS + 1):
        elecM += zval[I-1] * dct[0].conc[I-1,1-1]
        elecS += zval[I-1] * dct[0].conc[I-1,6-1]
        elecS_out += zval[I-1] * ( dct[NZ].conc[I-1,6-1] )

    return xTRPV5_dct
