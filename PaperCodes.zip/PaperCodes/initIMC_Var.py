# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine.
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 

def initIMC_Var (imcd):
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
    Pf = np.zeros((NC,NC))
    dLA = np.zeros((NS,NS,NC,NC))

    pos = np.zeros(NZ+1)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Solute Indices: 1 = Na+, 2 = K+, 3 = Cl-, 4 = HCO3-, 5 = H2CO3, 6 = CO2
# 7 = HPO4(2-), 8 = H2PO4-, 9 = urea, 10 = NH3, 11 = NH4+, 12 = H+
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Calculate initial surfaces and volumes
# Volumes, surfaces, and angles implicitly include the number of
# each type of cell (but the PtoIratio doesn't).
# Data for rat (AMW model, AJP Renal 2001)
#---------------------------------------------------------------------72

    SlumPinitimc = 0.6
    SbasPinitimc = 0.6
    SlatPinitimc = 5.4  
    
    SlumEinitimc = 0.001
    
    for p in imcd:
        p.sbasEinit = 0.020
        
        p.volPinit = 8.0
        p.volEinit = 0.80
        
        p.volAinit = 8.0
        p.volBinit = 8.0
        
# Assign areas and volume to non-existent A and B cells
    SlumAinitimc = SlumPinitimc
    SbasAinitimc = SbasPinitimc
    SlatAinitimc = SlatPinitimc
    SlumBinitimc = SlumPinitimc
    SbasBinitimc = SbasPinitimc
    SlatBinitimc = SlatPinitimc
       
#---------------------------------------------------------------------72
# Assign membrane surface area except for basal membrane of E
#---------------------------------------------------------------------72        
        
    for p in imcd:
        p.area[1-1, 2-1] = SlumPinitimc
        p.area[1-1, 3-1] = SlumAinitimc
        p.area[1-1, 4-1] = SlumBinitimc
        p.area[1-1, 5-1] = SlumEinitimc
        
        p.area[2-1, 5-1] = SlatPinitimc
        p.area[3-1, 5-1] = SlatAinitimc
        p.area[4-1, 5-1] = SlatBinitimc
        
        p.area[2-1, 6-1] = SbasPinitimc
        p.area[3-1, 6-1] = SbasAinitimc
        p.area[4-1, 6-1] = SbasBinitimc

    for K in range(1, NC -1 +1):
        for L in range(K + 1, NC + 1):
            for p in imcd:
                p.area[L-1, K-1] = p.area[K-1, L-1]
                 
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Water permeabilities
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    PfMP = 0.750e-3/Vwbar
    PfPE = 0.150e-3/Vwbar
    PfPS = 0.150e-3/Vwbar
    
    PfME = 36.0e-3/Vwbar
    PfES = 600e-3/Vwbar
    
    Pf = np.zeros((NC, NC))

    Pf[1-1,2-1] = PfMP
    Pf[1-1,3-1] = 0
    Pf[1-1,4-1] = 0
    Pf[1-1,5-1] = PfME
    Pf[2-1,5-1] = PfPE
    Pf[3-1,5-1] = 0
    Pf[4-1,5-1] = 0
    Pf[2-1,6-1] = PfPS
    Pf[3-1,6-1] = 0
    Pf[4-1,6-1] = 0
    Pf[5-1,6-1] = PfES
    
# Units of dimensional water flux: cm3/s/cm2 epith
# Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
# Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
# dLPV = Pf/Pfref

    for K in range(1, NC + 1):
        for L in range(1, NC + 1):
            for p in imcd:
                p.dLPV[K-1, L-1] = Pf[K-1, L-1] / Pfref

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# sig(I,K,L) = reflection coefficient of Ith solute between K and L
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(1, NC + 1):
                for p in imcd:
                    p.sig[i-1, k-1, l-1] = 1.0
            
# Values at the basement membrane (ES)
    for i in range(1, NS + 1):
        for p in imcd:
            p.sig[i-1, 5-1, 6-1] = 0.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional Solute permeabilities
# h(I,K,L) = permeability of ith solute at the K-L interface
# h(I,K,L) in 10-5 cm/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in imcd:
                    p.h[i-1, k-1, l-1] = 0.0

# Values at the MP interface (1-2)

# ENaC activity modified by local factors, including pH. Use hENaC_IMC as basal
# value of expression
# imcd(:)%hNaMP = 1.0*fscaleENaC ! Not used, replaced with hENaC

    fscaleENaC = 2.50
    fscaleNaK = 1.25
    fscaleNaK_PC = 1.25

# Female-to-male ENaC expression ratio in cortex (CNT and CCD)
    FM_mENaC = 1.20 * 0.85

    hENaC_IMC = FM_mENaC * 2.50
    
# ROMK activity modified by local factors, including pH. Use hROMK_IMC as basal
# value of expression
# imcd(:)%h(2,1,2) = 1.00 - Not used, replaced with hROMK
    hROMK_IMC = 1.0

    for p in imcd:
        p.h[2-1,1-1,2-1] = 1.0
        p.h[3-1,1-1,2-1] = 2.0e-4
        p.h[4-1,1-1,2-1] = 2.0e-4
        p.h[5-1,1-1,2-1] = 130
        p.h[6-1,1-1,2-1] = 15.0e3/6.5  # See DN model (AJP 2008)
        p.h[7-1,1-1,2-1] = 0.20e-3
        p.h[8-1,1-1,2-1] = 0.20e-3
        p.h[9-1,1-1,2-1] = 300
        p.h[10-1,1-1,2-1] = 400
        p.h[11-1,1-1,2-1] = 0.20
        p.h[12-1,1-1,2-1] = 2.0e-4
        p.h[13-1,1-1,2-1] = 0.0
        p.h[14-1,1-1,2-1] = 0.0
        p.h[15-1,1-1,2-1] = 0.0
        p.h[16-1,1-1,2-1] = 0.00010
        
# Values at the PE interface (2-5)
        p.h[1-1, 2-1, 5-1] = 2.0e-4
        p.h[2-1, 2-1, 5-1] = 1.50
        p.h[3-1, 2-1, 5-1] = 0.050
        p.h[4-1, 2-1, 5-1] = 0.025
        p.h[5-1, 2-1, 5-1] = 130.0
        p.h[6-1, 2-1, 5-1] = 15.0e3/6.5  # See DN model (AJP 2008)
        p.h[7-1, 2-1, 5-1] = 8.0e-3  # as in CNT - Different in AMW model
        p.h[8-1, 2-1, 5-1] = 8.0e-3  # as in CNT - Different in AMW model
        p.h[9-1, 2-1, 5-1] = 15.0
        p.h[10-1, 2-1, 5-1] = 400
        p.h[11-1, 2-1, 5-1] = 0.30
        p.h[12-1, 2-1, 5-1] = 2.0e-4
        p.h[13-1, 2-1, 5-1] = 1.0e-4
        p.h[14-1, 2-1, 5-1] = 1.0e-4
        p.h[15-1, 2-1, 5-1] = 1.0e-4
        p.h[16-1, 2-1, 5-1] = 0.00010
        
# Values at other cellular interfaces (2-6)
# Dummy values for non-existent intercalated cells
# (3-1),(3-5),(3-6),(4-1),(4-5),(4-6)

    for I in range(1, NS + 1):
        for p in imcd:
            p.h[I-1, 2-1, 6-1] = p.h[I-1, 2-1, 5-1]
            p.h[I-1, 1-1, 3-1] = 0.0
            p.h[I-1, 3-1, 5-1] = 0.0
            p.h[I-1, 3-1, 6-1] = 0.0
            p.h[I-1, 1-1, 4-1] = 0.0
            p.h[I-1, 4-1, 5-1] = 0.0
            p.h[I-1, 4-1, 6-1] = 0.0   
            
# Values at the ME interface (1-5)

    ClTJperm = 1000.0  # Assume TJ resistivity of 5 mS/cm2

    for p in imcd:
        p.h[1-1, 1-1, 5-1] = (1.00 / FM_mENaC) * 0.90*ClTJperm
        p.h[2-1, 1-1, 5-1] = (1.00 / FM_mENaC) * 0.70*ClTJperm
    
# Cl permeability modified by local factors, including pH. Use hCltj_CNT as basal
# value of expression
# imcd(:)%h(3,1,5) = ClTJperm*1.60d0 - Not used, replaced with hCltj

        hCltj_IMC = 1.3 * ClTJperm * 1.60
        p.h[4-1, 1-1, 5-1] = 0.4*ClTJperm  # Changed from 0.15 on 04/30/19
        p.h[5-1, 1-1, 5-1] = 1.2*ClTJperm
        p.h[6-1, 1-1, 5-1] = 1.2*ClTJperm
        p.h[7-1, 1-1, 5-1] = 0.2*ClTJperm
        p.h[8-1, 1-1, 5-1] = 0.2*ClTJperm
        p.h[9-1, 1-1, 5-1] = 0.80*ClTJperm
        p.h[10-1, 1-1, 5-1] = 1.0*ClTJperm
        p.h[11-1, 1-1, 5-1] = 0.7*ClTJperm
        p.h[12-1, 1-1, 5-1] = 6.0*ClTJperm
        p.h[13-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[14-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[15-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[16-1, 1-1, 5-1] = 0.0140 * ClTJperm  # See my 2015 AJP and Carney 1988   
            
# Values at the ES interface (5-6)
# All values are from AWM model

    areafactor = 50
    
    for p in imcd:
        p.h[1-1, 5-1, 6-1] = 60*areafactor
        p.h[2-1, 5-1, 6-1] = 80.0*areafactor
        p.h[3-1, 5-1, 6-1] = 80.0*areafactor
        p.h[4-1, 5-1, 6-1] = 40.0*areafactor
        p.h[5-1, 5-1, 6-1] = 60.0*areafactor
        p.h[6-1, 5-1, 6-1] = 60.0*areafactor
        p.h[7-1, 5-1, 6-1] = 40.0*areafactor
        p.h[8-1, 5-1, 6-1] = 40.0*areafactor
        p.h[9-1, 5-1, 6-1] = 40.0*areafactor
        p.h[10-1, 5-1, 6-1] = 50.0*areafactor
        p.h[11-1, 5-1, 6-1] = 80.0*areafactor
        p.h[12-1, 5-1, 6-1] = 400.0*areafactor
        p.h[13-1, 5-1, 6-1] = 1.0*areafactor  
        p.h[14-1, 5-1, 6-1] = 1.0*areafactor  
        p.h[15-1, 5-1, 6-1] = 1.0*areafactor  
        p.h[16-1, 5-1, 6-1] = ( p.h[1-1,5-1,6-1] ) * (7.93/13.3)            

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional Solute permeabilities
# Divide h(I,K,L) by (href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            for L in range(K, NC + 1):
                for p in imcd:
                    p.h[I-1, K-1, L-1] *= 1.0e-5 / href
                    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional NET coefficients
# dLA(I,J,K,L) = coefficient of ith and jth solute at the K-L interface
# dLA(I,J,K,L) in mmol2/J/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    dLA[I-1, J-1, K-1, L-1] = 0.0
                   
# Na/H exchangers on basolateral membrane
    dLA[1-1,12-1,2-1,5-1] = 6.0e-9
    dLA[1-1,12-1,2-1,6-1] = 6.0e-9
    
# Na2/HPO4 co-transporters on basolateral membrane
    dLA[1-1,7-1,2-1,5-1] = 2.0e-9
    dLA[1-1,7-1,2-1,6-1] = 2.0e-9
    
# NaKCl2 cotransporter on basolateral membrane
    dLA[1-1,2-1,2-1,5-1] = 4.0e-9
    dLA[1-1,2-1,2-1,6-1] = 4.0e-9
    
# KCl cotransporter on basolateral membrane
    dLA[2-1,3-1,2-1,5-1] = 250.0e-9
    dLA[2-1,3-1,2-1,6-1] = 250.0e-9
    
# Cl/HCO3 exchanger on basolateral membrane
    dLA[3-1,4-1,2-1,5-1] = 20.0e-9
    dLA[3-1,4-1,2-1,6-1] = 20.0e-9
    
# Na/Cl exchanger on apical membrane
    dLA[1-1,3-1,1-1,2-1] = 1200.0e-9

#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS - 1 + 1):
        for J in range(I+1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(1, NC + 1):
                        dLA[J-1, I-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional ATPase coefficients
# ATPcoeff in mmol/s or mmol
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Na-K-ATPase (basolateral)
    ATPNaKPES = FM_mENaC * 2000e-9 * 1.25
    
# H-ATPase (apical)
    ATPHKMP = 2000e-9*0.10*0.50
# adjusted parameter

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional coefficients
# Divide dLA(I,J,K,L) by (href)*Cref for consistency with other
# solute flux terms
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    for p in imcd:
                        p.dLA[I-1, J-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1] / (href * Cref)
     
    for p in imcd:
        p.ATPNaK[2-1,5-1] = ATPNaKPES / (href*Cref)
        p.ATPNaK[2-1,6-1] = ATPNaKPES / (href*Cref)
        p.ATPHK[1-1,2-1] = ATPHKMP / (href*Cref)
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Other kinetic parameters
# Units of kinetic constants are s-1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# KINETIC PARAMETERS

    dkhuncat = 0.145
    dkduncat = 49.6
    dkhP = dkhuncat * 100
    dkdP = dkduncat*100
    dkhE = dkhuncat
    dkdE = dkduncat

    for p in imcd:
        p.dkd[1-1] = dkduncat
        p.dkh[1-1] = dkhuncat
        p.dkd[2-1] = dkdP
        p.dkh[2-1] = dkhP
        p.dkd[3-1] = dkdP
        p.dkh[3-1] = dkhP
        p.dkd[4-1] = dkdP
        p.dkh[4-1] = dkhP
        p.dkd[5-1] = dkdE
        p.dkh[5-1] = dkhE
        
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  BOUNDARY CONDITIONS IN PERITUBULAR SOLUTION
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

    imcd[0].ep[6-1] = -0.001e-3/EPref
    
    for jz in range(0, NZIMC + 1):
        imcd[jz].ep[6-1] = imcd[0].ep[6-1]
        
        imcd[jz].coalesce = 0.20 *( 2.00 ** (-6.00*jz/NZIMC) )
# The last expression is consistent with 64 OMCDs converging to a single duct
# As assumed by Hervy and Thomas (2003)

        pos[jz] = 1.0 * jz / NZIMC
    
    from set_intconc import set_intconc    
    set_intconc ( imcd, NZIMC, 3, pos )

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# READ ENTERING CONDITIONS FROM OMCD OUTLET FILE
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    with open('OMCoutlet', 'r') as f:
        for I in range(1, 5):
            imcd[0].conc[I-1,1-1], imcd[0].conc[I-1,6-1] = map(float, f.readline().split())
        for I in range(5, NS + 1):
            imcd[0].conc[I-1,1-1], imcd[0].conc[I-1,6-1] = map(float, f.readline().split())
        imcd[0].ph[1-1], imcd[0].ph[6-1] = map(float, f.readline().split())
        imcd[0].ep[1-1], imcd[0].ep[6-1] = map(float, f.readline().split())
        imcd[0].vol[1-1], imcd[0].pres = map(float, f.readline().split())

    for p in imcd:
        p.volLuminit = imcd[0].vol[1-1]    
        
#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------72

    for p in imcd:
        p.TQ = 15.0 if not bdiabetes else 12.0 
        # !TNa-QO2 ratio in normal OMCD, else TNa-QO2 ratio in diabetic OMCD
        
#--------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------72
       
    elecM = 0.0
    elecS = 0.0
    elecS_out = 0.0
    
    for I in range(1, NS + 1):
        elecM += zval[I-1] * imcd[0].conc[I-1,1-1]
        elecS += zval[I-1] * imcd[0].conc[I-1,6-1]
        elecS_out += zval[I-1] * ( imcd[NZIMC].conc[I-1,6-1] )

    return hENaC_IMC, hROMK_IMC, hCltj_IMC
