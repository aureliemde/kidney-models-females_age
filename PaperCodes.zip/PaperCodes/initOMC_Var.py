# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine.
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 

def initOMC_Var (omcd):
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
    Pf = np.zeros((NC,NC))
    dLA = np.zeros((NS,NS,NC,NC))

    pos = np.zeros(NZ+1)

#---------------------------------------------------------------------72
# Data for rat (AMW model, AJP Renal 2001)
#---------------------------------------------------------------------

    SlumPinitomc = 1.2
    SbasPinitomc = 1.2
    SlatPinitomc = 6.9
    
    SlumAinitomc = 2.0
    SbasAinitomc = 2.0
    SlatAinitomc = 6.0
    
    SlumEinitomc = 0.001
    
    for p in omcd:
        p.sbasEinit = 0.020
        
        p.volPinit = 4.0
        p.volAinit = 3.0
        p.volEinit = 0.80
                
# Assign areas and volume to non-existent B cells

    SlumBinitomc = SlumAinitomc
    SbasBinitomc = SbasAinitomc
    SlatBinitomc = SlatAinitomc

    for p in omcd:
        p.volBinit = omcd[0].volAinit
       
#---------------------------------------------------------------------72
# Assign membrane surface area except for basal membrane of E
#---------------------------------------------------------------------72        
        
    for p in omcd:
        p.area[1-1, 2-1] = SlumPinitomc
        p.area[1-1, 3-1] = SlumAinitomc
        p.area[1-1, 4-1] = SlumBinitomc
        p.area[1-1, 5-1] = SlumEinitomc
        
        p.area[2-1, 5-1] = SlatPinitomc
        p.area[3-1, 5-1] = SlatAinitomc
        p.area[4-1, 5-1] = SlatBinitomc
        
        p.area[2-1, 6-1] = SbasPinitomc
        p.area[3-1, 6-1] = SbasAinitomc
        p.area[4-1, 6-1] = SbasBinitomc

    for K in range(1, NC -1 +1):
        for L in range(K + 1, NC + 1):
            for p in omcd:
                p.area[L-1, K-1] = p.area[K-1, L-1]
            
    for p in omcd:
        p.zPimp = -1.0
        p.zAimp = -1.0
        p.zBimp = -1.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Water permeabilities
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    PfMP = 0.20/1.2  
    PfPE = 0.11*2  
    PfPS = 0.11*2  
    
    PfMA = 0.22e-3
    PfAE = 5.50e-3
    PfAS = 5.50e-3
    
    PfMB = 0.22e-3
    PfBE = 5.50e-3
    PfBS = 5.50e-3
    
    PfME = 28  # Per AMW email on 03/08/13
    PfES = 41  # check value; 41.d0 in OMCD
    
    Pf = np.zeros((NC, NC))

    Pf[1-1,2-1] = PfMP
    Pf[1-1,3-1] = PfMA
    Pf[1-1,4-1] = PfMB
    Pf[1-1,5-1] = PfME
    Pf[2-1,5-1] = PfPE
    Pf[3-1,5-1] = PfAE
    Pf[4-1,5-1] = PfBE
    Pf[2-1,6-1] = PfPS
    Pf[3-1,6-1] = PfAS
    Pf[4-1,6-1] = PfBS
    Pf[5-1,6-1] = PfES
    
# Units of dimensional water flux: cm3/s/cm2 epith
# Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
# Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
# dLPV = Pf/Pfref

    for K in range(1, NC + 1):
        for L in range(1, NC + 1):
            for p in omcd:
                p.dLPV[K-1, L-1] = Pf[K-1, L-1] / Pfref

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# sig(I,K,L) = reflection coefficient of Ith solute between K and L
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(1, NC + 1):
                for p in omcd:
                    p.sig[i-1, k-1, l-1] = 1.0
            
# Values at the basement membrane (ES)
    for i in range(1, NS + 1):
        for p in omcd:
            p.sig[i-1, 5-1, 6-1] = 0.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional Solute permeabilities
# h(I,K,L) = permeability of ith solute at the K-L interface
# h(I,K,L) in 10-5 cm/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    PICAchlo = 1.2
    PPCh2co3 = 130
    PICh2co3 = 10
    PPCco2 = 2.0e3  # Per AMW email on 03/08/13
    PICco2 = 900
    PPChpo4 = 8.0e-3
    PPCprot = 2000
    PICAprot = 1.5
    PPCamon = 2000
    PICamon = 900
    PPCurea = 0.10
    PICurea = 1.0

# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in omcd:
                    p.h[i-1, k-1, l-1] = 0.0
                    
    fac4 = 1.0/4.0

# Values at the MP interface (1-2)

# ENaC activity modified by local factors, including pH. Use hENaC_OMC as basal
# value of expression
# omcd(:)%hNaMP = 14.00*fac4*fscaleENaC !- Not used, replaced with hENaC

    fscaleENaC = 2.50
    fscaleNaK = 1.25
    fscaleNaK_PC = 1.25
    
# Female-to-male ENaC expression ratio in cortex (CNT and CCD)
    FM_mENaC = 1.20 * 0.85
    
    hENaC_OMC = FM_mENaC * 35.00 * fac4
    
# ROMK activity modified by local factors, including pH. Use hROMK_OMC as basal
# value of expression
# omcd(:)%h(2,1,2) = 8.0d0*fac4 - Not used, replaced with hROMK
    hROMK_OMC = 8.0 * fac4

    for p in omcd:
        p.h[3-1,1-1,2-1] = 0.80 * fac4  # No apical Cl conductance (Jacques)
        p.h[4-1,1-1,2-1] = 0.16 * fac4  # No apical conductance (Jacques)
        p.h[5-1,1-1,2-1] = PPCh2co3
        p.h[6-1,1-1,2-1] = PPCco2
        p.h[7-1,1-1,2-1] = 1.0e-3/1.20   # as in CNT
        p.h[8-1,1-1,2-1] = 1.0e-3/1.20  # as in CNT
        p.h[9-1,1-1,2-1] = PPCurea
        p.h[10-1,1-1,2-1] = PPCamon
        p.h[11-1,1-1,2-1] = p.h[2-1, 1-1, 2-1] * 0.20  # AMW rule of thumb
        p.h[12-1,1-1,2-1] = PPCprot * fac4
        p.h[13-1,1-1,2-1] = 0.0
        p.h[14-1,1-1,2-1] = 0.0
        p.h[15-1,1-1,2-1] = 1.0e-10  # No convergence if set to 0 !!!!!
        p.h[16-1,1-1,2-1] = 0.00010
                
# Values at the PE interface (2-5)
        p.h[1-1, 2-1, 5-1] = 0.000
        p.h[2-1, 2-1, 5-1] = 4.0 * fac4
        p.h[3-1, 2-1, 5-1] = 0.20 * fac4
        p.h[4-1, 2-1, 5-1] = p.h[3-1, 2-1, 5-1] * 0.20  # AMW rule of thumb
        p.h[5-1, 2-1, 5-1] = PPCh2co3
        p.h[6-1, 2-1, 5-1] = PPCco2
        p.h[7-1, 2-1, 5-1] = 8.0e-3  # as in CNT 
        p.h[8-1, 2-1, 5-1] = 8.0e-3  # as in CNT
        p.h[9-1, 2-1, 5-1] = PPCurea
        p.h[10-1, 2-1, 5-1] = PPCamon
        p.h[11-1, 2-1, 5-1] = p.h[2-1, 2-1, 5-1] * 0.20  # AMW rule of thumb
        p.h[12-1, 2-1, 5-1] = PPCprot * fac4
        p.h[13-1, 2-1, 5-1] = 1.0e-4
        p.h[14-1, 2-1, 5-1] = 1.0e-4
        p.h[15-1, 2-1, 5-1] = 1.0e-4
        p.h[16-1, 2-1, 5-1] = 0.00010
        
# Values at the MA interface (1-3)

        p.h[1-1,1-1,3-1] = 0.0
        p.h[2-1,1-1,3-1] = 0.00  
        p.h[3-1,1-1,3-1] = 0.0
        p.h[4-1,1-1,3-1] = 0.0
        p.h[5-1,1-1,3-1] = PICh2co3
        p.h[6-1,1-1,3-1] = PICco2
        p.h[7-1,1-1,3-1] = 0.0
        p.h[8-1,1-1,3-1] = 0.0
        p.h[9-1,1-1,3-1] = PICurea
        p.h[10-1,1-1,3-1] = PICamon
        p.h[11-1,1-1,3-1] = 0.10e-4
        p.h[12-1,1-1,3-1] = 0.0
        p.h[13-1,1-1,3-1] = 0.0
        p.h[14-1,1-1,3-1] = 0.0
        p.h[15-1,1-1,3-1] = 0.0
        p.h[16-1,1-1,3-1] = 0.00010
        
# Values at the AE interface (3-5)

        p.hCLCA = PICAchlo  
    
        p.h[1-1,3-1,5-1] = 0.0
        p.h[2-1,3-1,5-1] = 0.12
        p.h[3-1,3-1,5-1] = PICAchlo
        p.h[4-1,3-1,5-1] = 0.15
        p.h[5-1,3-1,5-1] = PICh2co3
        p.h[6-1,3-1,5-1] = PICco2
        p.h[7-1,3-1,5-1] = 1.20e-3
        p.h[8-1,3-1,5-1] = 1.20e-3
        p.h[9-1,3-1,5-1] = PICurea
        p.h[10-1,3-1,5-1] = PICamon
        p.h[11-1,3-1,5-1] = 0.030
        p.h[12-1,3-1,5-1] = 1.50
        p.h[13-1,3-1,5-1] = 1.0e-4
        p.h[14-1,3-1,5-1] = 1.0e-4
        p.h[15-1,3-1,5-1] = 1.0e-4
        p.h[16-1,3-1,5-1] = 0.00010  

# Values at other cellular interfaces (2-6), (3-6), (4-1), (4-5) and (4-6)

    for I in range(1, NS + 1):
        for p in omcd:
            p.h[I-1, 2-1, 6-1] = p.h[I-1, 2-1, 5-1]
            p.h[I-1, 3-1, 6-1] = p.h[I-1, 3-1, 5-1]
            p.h[I-1, 1-1, 4-1] = 0.0
            p.h[I-1, 4-1, 5-1] = 0.0
            p.h[I-1, 4-1, 6-1] = 0.0
    
# Values at the ME interface (1-5)
    ClTJperm = 1000.0  # Assume TJ resistivity of 5 mS/cm2

    for p in omcd:
        p.h[1-1, 1-1, 5-1] = (1.00 / FM_mENaC) * 0.80*ClTJperm
        p.h[2-1, 1-1, 5-1] = (1.00 / FM_mENaC) * 1.20*ClTJperm
        
# Cl permeability modified by local factors, including pH. Use hCltj_OMC as basal
# value of expression
# omcd(:)%h(3,1,5) = ClTJperm*1.00d0 - Not used, replaced with hCltj

        hCltj_OMC = 1.3 * ClTJperm * 1.00
        p.h[4-1, 1-1, 5-1] = 0.30*ClTJperm  # Changed from 0.15 on 04/30/19
        p.h[5-1, 1-1, 5-1] = 1.2*ClTJperm
        p.h[6-1, 1-1, 5-1] = 1.2*ClTJperm
        p.h[7-1, 1-1, 5-1] = 0.10*ClTJperm  
        p.h[8-1, 1-1, 5-1] = 0.10*ClTJperm  
        p.h[9-1, 1-1, 5-1] = 2.0*ClTJperm  # Per AMW email on 03/08/13
        p.h[10-1, 1-1, 5-1] = 1.0*ClTJperm
        p.h[11-1, 1-1, 5-1] = 1.5*ClTJperm
        p.h[12-1, 1-1, 5-1] = 6.0*ClTJperm
        p.h[13-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[14-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[15-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[16-1, 1-1, 5-1] = 0.0140 * ClTJperm  # See my 2015 AJP and Carney 1988   
            
# Values at the ES interface (5-6)
# All values are from AWM model

    areafactor = 50
    
    for p in omcd:
        p.h[1-1, 5-1, 6-1] = 89*areafactor
        p.h[2-1, 5-1, 6-1] = 118*areafactor
        p.h[3-1, 5-1, 6-1] = 118*areafactor
        p.h[4-1, 5-1, 6-1] = 59*areafactor
        p.h[5-1, 5-1, 6-1] = 89*areafactor
        p.h[6-1, 5-1, 6-1] = 89*areafactor
        p.h[7-1, 5-1, 6-1] = 59*areafactor
        p.h[8-1, 5-1, 6-1] = 59*areafactor
        p.h[9-1, 5-1, 6-1] = 59*areafactor
        p.h[10-1, 5-1, 6-1] = 59*areafactor
        p.h[11-1, 5-1, 6-1] = 118*areafactor
        p.h[12-1, 5-1, 6-1] = 590.0*areafactor
        p.h[13-1, 5-1, 6-1] = 1.0*areafactor  
        p.h[14-1, 5-1, 6-1] = 1.0*areafactor  
        p.h[15-1, 5-1, 6-1] = 1.0*areafactor
        p.h[16-1, 5-1, 6-1] = ( p.h[1-1,5-1,6-1] ) * (7.93/13.3)            

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional Solute permeabilities
# Divide h(I,K,L) by (href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            for L in range(K, NC + 1):
                for p in omcd:
                    p.h[I-1, K-1, L-1] *= 1.0e-5 / href
                    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional NET coefficients
# dLA(I,J,K,L) = coefficient of ith and jth solute at the K-L interface
# dLA(I,J,K,L) in mmol2/J/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    dLA[I-1, J-1, K-1, L-1] = 0.0
                   
# Na/H exchangers on all basolateral membranes
    dLA[1-1,12-1,2-1,5-1] = 2.50e-9
    dLA[1-1,12-1,2-1,6-1] = 2.50e-9
    dLA[1-1,12-1,3-1,5-1] = 6.0e-9
    dLA[1-1,12-1,3-1,6-1] = 6.0e-9
    
    xNHE1P = 6.95e-10 * 680 / 695 * fac4
    
# Na2/HPO4 co-transporters on all basolateral membranes
    dLA[1-1,7-1,2-1,5-1] = 2.0e-9
    dLA[1-1,7-1,2-1,6-1] = 2.0e-9
    dLA[1-1,7-1,3-1,5-1] = 0.20e-9
    dLA[1-1,7-1,3-1,6-1] = 0.20e-9
        
# Basolateral Cl/HCO3 exchanger in PC
    dLA[3-1,4-1,2-1,5-1] = 2.0e-9 * fac4 
    dLA[3-1,4-1,2-1,6-1] = 2.0e-9 * fac4
    
# AE1 in IC-A only
    xAE1 = 12.0e-9

#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS - 1 + 1):
        for J in range(I+1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(1, NC + 1):
                        dLA[J-1, I-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional ATPase coefficients
# ATPcoeff in mmol/s or mmol
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Na-K-ATPase (basolateral in PC and IC)
    ATPNaKPES = FM_mENaC * 3410e-9 * 1.25 * fac4
    ATPNaKAES = 75e-9
    
# H-ATPase (apical in IC-A, basolateral in IC-B)
    ATPHMA = 750.0e-9
    
# H-K-ATPase (apical in PC and IC)
    ATPHKMP = 0
    ATPHKMA = 150e-9

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional coefficients
# Divide dLA(I,J,K,L) by (href)*Cref for consistency with other
# solute flux terms
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    for p in omcd:
                        p.dLA[I-1, J-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1] / (href * Cref)
     
    for p in omcd:
        p.xNHE1[2-1] = xNHE1P/(href*Cref)
        p.xAE1 = xAE1/(href*Cref)
        
        p.ATPNaK[2-1, 5-1] = ATPNaKPES/(href*Cref)
        p.ATPNaK[2-1, 6-1] = ATPNaKPES/(href*Cref)
        p.ATPNaK[3-1, 5-1] = ATPNaKAES/(href*Cref)
        p.ATPNaK[3-1, 6-1] = ATPNaKAES/(href*Cref)
        
        p.ATPH[1-1, 3-1] = ATPHMA/(href*Cref)
        
        p.ATPHK[1-1, 2-1] = ATPHKMP/(href*Cref)
        p.ATPHK[1-1, 3-1] = ATPHKMA/(href*Cref)
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Other kinetic parameters
# Units of kinetic constants are s-1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# KINETIC PARAMETERS

    dkhuncat = 0.145
    dkduncat = 49.6
    dkhP = 1.45
    dkdP = 496.0
    dkhA = 1.45e3
    dkdA = 496.0e3
    dkhB = 1.45e3
    dkdB = 496.0e3
    dkhE = 0.145
    dkdE = 49.6

    for p in omcd:
        p.dkd[1-1] = dkduncat
        p.dkh[1-1] = dkhuncat
        p.dkd[2-1] = dkdP
        p.dkh[2-1] = dkhP
        p.dkd[3-1] = dkdA
        p.dkh[3-1] = dkhA
        p.dkd[4-1] = dkdB
        p.dkh[4-1] = dkhB
        p.dkd[5-1] = dkdE
        p.dkh[5-1] = dkhE
        
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  BOUNDARY CONDITIONS IN PERITUBULAR SOLUTION
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

    omcd[0].ep[6-1] = -0.001e-3/EPref
    
    for jz in range(0, NZ + 1):
        omcd[jz].ep[6-1] = omcd[0].ep[6-1]

        pos[jz] = 1.0 * jz / NZ

    from set_intconc import set_intconc    
    set_intconc ( omcd, NZ, 2, pos )
    
# coalesence parameter
    for p in omcd:
        p.coalesce = 0.2

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# READ ENTERING CONDITIONS FROM CCD OUTLET FILE
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    with open('CCDoutlet', 'r') as f:
        for I in range(1, 5):
            omcd[0].conc[I-1,1-1], omcd[0].conc[I-1,6-1] = map(float, f.readline().split())
        for I in range(5, NS + 1):
            omcd[0].conc[I-1,1-1], omcd[0].conc[I-1,6-1] = map(float, f.readline().split())
        omcd[0].ph[1-1], omcd[0].ph[6-1] = map(float, f.readline().split())
        omcd[0].ep[1-1], omcd[0].ep[6-1] = map(float, f.readline().split())
        omcd[0].vol[1-1], omcd[0].pres = map(float, f.readline().split())

    for p in omcd:
        p.volLuminit = omcd[0].vol[1-1]    
        
#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------72

    for p in omcd:
        p.TQ = 15.0 if not bdiabetes else 12.0 
        # !TNa-QO2 ratio in normal OMCD, else TNa-QO2 ratio in diabetic OMCD
        
#--------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------72
       
    elecM = 0.0
    elecS = 0.0
    elecS_out = 0.0
    
    for I in range(1, NS + 1):
        elecM += zval[I-1] * omcd[0].conc[I-1,1-1]
        elecS += zval[I-1] * omcd[0].conc[I-1,6-1]
        elecS_out += zval[I-1] * ( omcd[NZ].conc[I-1,6-1] )

    return hENaC_OMC, hROMK_OMC, hCltj_OMC
