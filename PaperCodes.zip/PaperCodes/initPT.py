# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine for the PT
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 

def initPT(pt):
    
    # Local variables
    Pf = np.zeros((NC, NC))  # NC x NC array initialized with zeros
    pos = np.zeros(NZ + 1)  # Array with indices from 0 to NZ initialized with zeros
    ind = 0  # Initialize ind as 0
            
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  Solute Indices: 1 = Na+, 2 = K+, 3 = Cl-, 4 = HCO3-, 5 = H2CO3, 6 = CO2
#  7 = HPO4(2-), 8 = H2PO4-, 9 = urea, 10 = NH3, 11 = NH4+, 12 = H+
#  13 = HCO2-, 14 = H2CO2, 15 = glucose
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  Calculate initial surfaces and volumes
#  Volumes, surfaces, and angles implicitly include the number of
#  each type of cell (but the PtoIratio doesn't).
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  Data for rat (AMW model, AJP Renal 2007)
# ---------------------------------------------------------------------72
    
    SlumPinitpt = 36.0
    SbasPinitpt = 1.0
    SlatPinitpt = 36.0

    SlumEinitpt = 0.001

    for p in pt:
        p.sbasEinit = 0.020
        
        p.volPinit = 10.0
        p.volEinit = 0.7
        
        p.volAinit = 10.0  # Needed for water flux subroutine (AURELIE)
        p.volBinit = 10.0  # Needed for water flux subroutine (AURELIE)
        
# ---------------------------------------------------------------------72
#  Assign membrane surface area except for basal membrane of E
# ---------------------------------------------------------------------72

        p.diam = DiamPT
        # normal kidney; else diabetic kidney, hypertrophied PT

        p.area[0, 1] = SlumPinitpt
        p.area[0, 2] = SlumPinitpt
        p.area[0, 3] = SlumPinitpt
        p.area[0, 4] = SlumEinitpt

        p.area[1, 4] = SlatPinitpt
        p.area[2, 4] = SlatPinitpt
        p.area[3, 4] = SlatPinitpt

        p.area[1, 5] = SbasPinitpt
        p.area[2, 5] = SbasPinitpt
        p.area[3, 5] = SbasPinitpt

    for J in range(NZ + 1):
        if J >= ( xS3 * NZ ):
            pt[J].area[0, 1] *= 0.5
            pt[J].area[1, 4] *= 0.5
            pt[J].area[1, 5] *= 0.5

    for K in range(1, NC):
        for L in range(K + 1, NC + 1):
            for p in pt:
                p.area[L-1, K-1] = p.area[K-1, L-1]
                
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  Water permeabilities
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  The permeabilities have already been multiplied by the area (cm2/cm2 epith)
#  dLPV(K,L) = hydraulic permeability at the K-L interface, in cm/s/mmHg
#  Pf(K,L) = osmotic permeability at the K-L interface, in cm/s
#  Relationship between the two: LPV=Pf*(Vwbar/RT)

#  WATER PERMEABILITIES

    PfMP = 0.64 * 0.40 / 36.0
    PfMA = 0.0
    PfMB = 0.0
    PfME = 0.22 / 0.001
    PfPE = 0.64 * 0.40 / 36.0
    PfAE = 0.0
    PfBE = 0.0
    PfPS = PfPE  
    PfAS = 0.0
    PfBS = 0.0
    PfES = 6.60 / 0.020

    Pf = np.zeros((NC, NC))

    Pf[0, 1] = PfMP
    Pf[0, 2] = PfMA
    Pf[0, 3] = PfMB
    Pf[0, 4] = PfME
    Pf[1, 4] = PfPE
    Pf[2, 4] = PfAE
    Pf[3, 4] = PfBE
    Pf[1, 5] = PfPS
    Pf[2, 5] = PfAS
    Pf[3, 5] = PfBS
    Pf[4, 5] = PfES
    
#  Units of dimensional water flux: cm3/s/cm2 epith
#  Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
#  Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
#  dLPV = Pf/Pfref

    for K in range(1, NC + 1):
        for L in range(1, NC + 1):
            for p in pt:
                p.dLPV[K-1, L-1] = Pf[K-1, L-1] / Pfref

# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  sig(I,K,L) = reflection coefficient of Ith solute between K and L
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

    #  Initialize
    for i in range(1, NSPT + 1):
        for k in range(1, NC + 1):
            for l in range(1, NC + 1):
                for p in pt:
                    p.sig[i-1, k-1, l-1] = 1.0
                
    # Reflection coefficient = 0 at the basement membrane (ES)
    for i in range(1, NSPT + 1):
        for p in pt:
            p.sig[i-1, 5-1, 6-1] = 0.0

    # Reflection coefficient varies at the tight junction (ME)
    for p in pt:
        p.sig[1-1,1-1,5-1] = 0.750
        p.sig[2-1,1-1,5-1] = 0.600
        p.sig[3-1,1-1,5-1] = 0.300
        p.sig[4-1,1-1,5-1] = 0.900
        p.sig[5-1,1-1,5-1] = 0.900
        p.sig[6-1,1-1,5-1] = 0.900
        p.sig[7-1,1-1,5-1] = 0.900
        p.sig[8-1,1-1,5-1] = 0.900
        p.sig[9-1,1-1,5-1] = 0.700
        p.sig[10-1,1-1,5-1] = 0.300
        p.sig[11-1,1-1,5-1] = 0.600
        p.sig[12-1,1-1,5-1] = 0.200
        p.sig[13-1,1-1,5-1] = 0.300
        p.sig[14-1,1-1,5-1] = 0.700
        p.sig[15-1,1-1,5-1] = 1.000
        p.sig[16-1,1-1,5-1] = 0.890 # See Ca PT model
    
    for i in range(1, NSPT + 1):
        for p in pt:
            p.sig[i-1, 5-1, 1-1] = p.sig[i-1, 1-1, 5-1]
            p.sig[i-1, 6-1, 5-1] = p.sig[i-1, 5-1, 6-1]
        
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  Dimensional Solute permeabilities
#  Alan's permeability values are multiplied by the area (cm2/cm2 epith)
#  h(I,K,L) = permeability of ith solute at the K-L interface
#  h(I,K,L) in 10-5 cm/s initially
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

    #  Initialize
    for i in range(1, NSPT + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in pt:
                    p.h[i-1, k-1, l-1] = 0.0

    # Values at the lumen-cell interface (MP, 1-2)
    for p in pt:
        p.h[1-1,1-1,2-1] = 0.0
        p.h[2-1,1-1,2-1] = 0.90/36.0
        p.h[3-1,1-1,2-1] = 0.0
        p.h[4-1,1-1,2-1] = 0.036/36.0
        p.h[5-1,1-1,2-1] = 2.34e3/36.0
        p.h[6-1,1-1,2-1] = 4.32e4/36.0  # 1.20d3 - Difference with AMW 2015 = 7500
        p.h[7-1,1-1,2-1] = 0.000/36.0  # Eliminate apical entry other than NaPO4
        p.h[8-1,1-1,2-1] = 0.000/36.0
        p.h[9-1,1-1,2-1] = 3.78/36.0
        p.h[10-1,1-1,2-1] = 3.06e3/36.0
        p.h[11-1,1-1,2-1] = 0.774/36.0
        p.h[12-1,1-1,2-1] = 3.06e4/36.0
        p.h[13-1,1-1,2-1] = 0.0
        p.h[14-1,1-1,2-1] = 1.80e5/36.0
        p.h[15-1,1-1,2-1] = 0.0
        p.h[16-1,1-1,2-1] = 0.005
    
    # Values at the cell-LIS interface (PE, 2-5)
        p.h[1-1,2-1,5-1] = 0.0  # Difference with AMW 2015
        p.h[2-1,2-1,5-1] = 0.20
        p.h[3-1,2-1,5-1] = 0.01  # Difference with AMW 2015
        p.h[4-1,2-1,5-1] = 0.0
        p.h[5-1,2-1,5-1] = 65.0
        p.h[6-1,2-1,5-1] = 1.20e3  # Difference with AMW 2015 = 7500
        p.h[7-1,2-1,5-1] = 0.00225
        p.h[8-1,2-1,5-1] = 0.0330
        p.h[9-1,2-1,5-1] = 0.100
        p.h[10-1,2-1,5-1] = 100.0
        p.h[11-1,2-1,5-1] = 0.060
        p.h[12-1,2-1,5-1] = 850.0
        p.h[13-1,2-1,5-1] = 0.0190
        p.h[14-1,2-1,5-1] = 6.0e3
        p.h[15-1,2-1,5-1] = 0.750*0.0  # REPLACED WITH GLUT TRANSPORTERS
        p.h[16-1,2-1,5-1] = 0.0
    
    # Values at the cell-interstitium interface (PS, 2-6)
    for i in range(1, NSPT + 1):
        for p in pt:
            p.h[i-1, 2-1, 6-1] = p.h[i-1, 2-1, 5-1]
        
# Values at the MA interface (1-3)
# Values at the AE interface (3-5)
# Values at the AS interface (3-6)
# Values at the MB interface (1-4)
# Values at the BE interface (4-5)
# Values at the BS interface (4-6)

    for i in range(1, NSPT + 1):
        for p in pt:
            p.h[i-1,1-1,3-1] = 0
            p.h[i-1,3-1,5-1] = 0
            p.h[i-1,3-1,6-1] = 0
            p.h[i-1,1-1,4-1] = 0
            p.h[i-1,4-1,5-1] = 0
            p.h[i-1,4-1,6-1] = 0

# Values at the lumen-LIS interface (ME, 1-5)
    
    ClTJperm = 1.0 / 0.0010  # Factor for area = 1/0.001

    for p in pt:
        p.h[1-1,1-1,5-1] = 0.38 * 26.0*ClTJperm
        p.h[2-1,1-1,5-1] = 0.38 * 29.0*ClTJperm
        p.h[3-1,1-1,5-1] = 20.0*ClTJperm
        p.h[4-1,1-1,5-1] = 8.0*ClTJperm
        p.h[5-1,1-1,5-1] = 8.0*ClTJperm
        p.h[6-1,1-1,5-1] = 8.0*ClTJperm
        p.h[7-1,1-1,5-1] = 4.0*ClTJperm
        p.h[8-1,1-1,5-1] = 4.0*ClTJperm
        p.h[9-1,1-1,5-1] = 8.0*ClTJperm
        p.h[10-1,1-1,5-1] = 50.0*ClTJperm
        p.h[11-1,1-1,5-1] = 50.0*ClTJperm
        p.h[12-1,1-1,5-1] = 600.0*ClTJperm
        p.h[13-1,1-1,5-1] = 14.0*ClTJperm
        p.h[14-1,1-1,5-1] = 28.0*ClTJperm
        p.h[15-1,1-1,5-1] = 0.31*ClTJperm  # value from Garvin (AJP Renal 1990)
        p.h[16-1,1-1,5-1] = 20.0*ClTJperm
    
# Values at the LIS-interstitium interface (ES, 5-6)
    
    areafactor = 1.0 / 0.020

    for p in pt:
        p.h[1-1,5-1,6-1] = 100.0*areafactor
        p.h[2-1,5-1,6-1] = 140.0*areafactor
        p.h[3-1,5-1,6-1] = 120.0*areafactor
        p.h[4-1,5-1,6-1] = 100.0*areafactor
        p.h[5-1,5-1,6-1] = 100.0*areafactor
        p.h[6-1,5-1,6-1] = 100.0*areafactor
        p.h[7-1,5-1,6-1] = 80.0*areafactor
        p.h[8-1,5-1,6-1] = 80.0*areafactor
        p.h[9-1,5-1,6-1] = 160.0*areafactor
        p.h[10-1,5-1,6-1] = 400.0*areafactor
        p.h[11-1,5-1,6-1] = 400.0*areafactor
        p.h[12-1,5-1,6-1] = 6.0e4*areafactor
        p.h[13-1,5-1,6-1] = 100.0*areafactor
        p.h[14-1,5-1,6-1] = 180.0*areafactor
        p.h[15-1,5-1,6-1] = 60.0*areafactor
        p.h[16-1,5-1,6-1] = ( p.h[1-1,5-1,6-1] ) *(7.93/13.3)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional Solute permeabilities
# Divide h(I,K,L) by (href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for i in range(1, NSPT + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in pt:
                    p.h[i-1, k-1, l-1] *= ( 1.0e-5 / href )

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional NET coefficients
# dLA(I,J,K,L) = coefficient of ith and jth solute at the K-L interface
# dLA(I,J,K,L) in mmol2/J/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    # Initialize
    for i in range(1, NSPT + 1):
        for j in range(1, NSPT + 1):
            for k in range(1, NC + 1):
                for l in range(k, NC + 1):
                    for p in pt:
                        p.dLA[i-1, j-1, k-1, l-1] = 0.0

# SGLT1 and SGLT2 on apical membrane
    if not bdiabetes:  # normal kidney
        CTsglt1 = 0.30e-5 / 36.0  # SGLT1
        for p in pt:
            p.dLA[1-1, 15-1, 1-1, 2-1] = 1.16 * 1.300e-9  # SGLT2 (original AMW value=270/36=7.50)
    else:  # diabetes simulations
        CTsglt1 = 0.30e-5 / 36.0 * (1 - 0.33)  # SGLT1 reduced by 33%
        for p in pt:
            p.dLA[1-1, 15-1, 1-1, 2-1] = 1.16 * 1.300e-9 * 1.38  # SGLT2 increased by 35%

# glucose transporter on basolateral membrane
    CTglut1 = 1.2 * 0.2500e-5
    CTglut2 = 1.3 * 0.1250e-5    
 
# Na-H2PO4 co-transporter on apical membrane
    CTnapiIIa = 0.75 * 0.30e-9
    CTnapiIIb = 0.75 * 0.0
    CTnapiIIc = 0.75 * 0.250e-9
    CTpit2 = 0.10e-9
    
# Na-H2PO4 co-transporter on apical membrane
    for p in pt:
        p.dLA[1-1, 8-1, 1-1, 2-1] = 1.25e-9
    
# Cl/HCO3 exchanger on apical membrane
    for p in pt:
        p.dLA[3-1, 4-1, 1-1, 2-1] = 2.0e-9 * 0.0  #(72/36=2) # DIFFERENCE WITH AMW MODEL
    
# Cl/HCO2 exchanger on apical membrane
        p.dLA[3-1, 13-1, 1-1, 2-1] = 5.0e-9 * 2.0  #(180/36=5) # DIFFERENCE WITH AMW MODEL

# K-Cl co-transporter on basolateral membrane
        p.dLA[2-1, 3-1, 2-1, 5-1] = 5.0e-9  
        p.dLA[2-1, 3-1, 2-1, 6-1] = p.dLA[1-1, 12-1, 2-1, 5-1]

# Na/3HCO3 exchanger on basolateral membrane
        p.dLA[1-1, 4-1, 2-1, 5-1] = 5.0e-9
        p.dLA[1-1, 4-1, 2-1, 6-1] = p.dLA[1-1, 4-1, 2-1, 5-1]

# NDCBE (Na-2HCO3/Cl cotransporter) on basolateral membrane
        p.dLA[1-1, 3-1, 2-1, 5-1] = 35.0e-9  
        p.dLA[1-1, 3-1, 2-1, 6-1] = p.dLA[1-1, 3-1, 2-1, 5-1]

# Note that 3 solutes are transported, even though there are only 2 solute indices

# Apical NHE3 
    xNHE3 = 0.78 * 1000.0e-9 / 36.0

# Basolateral Na,K-APTase    
    ATPNaKPES = 0.78 * 300.0e-9
    
# Apical H-ATPase    
    ATPHMP = 50.0e-9
    
# Basolateral PMCA    
    PMCA = 0.50e-9
    
# Rate of ammoniagenesis    
    QNH4 = 0.250e-6  

# Apical H+/HCO2- cotransporter - ADDITION TO AMW MODEL - REMOVED
    for p in pt:    
        p.dLA[12-1, 13-1, 1-1, 2-1] = 0.0e-9

# Apical SGLT2/SGLT1 and GLUT2/GLUT1 expression levels vary in S1-S2 vs S3
    for J in range(NZ + 1):
        if J < ( xS3 * NZ ):
            pt[J].xSGLT2 = 1.0
            pt[J].xSGLT1 = 0.0
            pt[J].xGLUT2 = 1.0
            pt[J].xGLUT1 = 0.0
        else:
            pt[J].xSGLT2 = 0.0
            pt[J].xSGLT1 = 1.0
            pt[J].xGLUT2 = 0.0
            pt[J].xGLUT1 = 1.0

#---------------------------------------------------------------------72
# set up parameter to scale torque effect

    for J in range(NZ + 1):
        if J < ( xS3 * NZ ):
            pt[J].scaleT = 1.0
        else:
            pt[J].scaleT = 0.5

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional coefficients
# Divide dLA(I,J,K,L) by (href)*Cref for consistency with other
# solute flux terms
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for I in range(1, NSPT + 1):
        for J in range(1, NSPT + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    for p in pt:
                        p.dLA[I-1, J-1, K-1, L-1] = p.dLA[I-1, J-1, K-1, L-1] / (href * Cref)

    for p in pt:
        p.xNHE3 = xNHE3 / (href * Cref)
        
        p.ATPNaK[2-1, 5-1] = ATPNaKPES / (href * Cref)
        p.ATPNaK[2-1, 6-1] = ATPNaKPES / (href * Cref)
        
        p.ATPH[1-1, 2-1] = ATPHMP / (href * Cref)
        
        p.qnh4 = QNH4 / (href * Cref)
        
        p.CTsglt1 = CTsglt1 / (href * Cref)
        
        p.CTglut1 = CTglut1 / (href * Cref)
        p.CTglut2 = CTglut2 / (href * Cref)
        
        p.PMCA = PMCA / (href * Cref)

    xNaPiIIaPT = CTnapiIIa / (href * Cref)
    xNaPiIIbPT = CTnapiIIb / (href * Cref)
    xNaPiIIcPT = CTnapiIIc / (href * Cref)
    xPit2PT = CTpit2 / (href * Cref)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Other kinetic parameters
# Units of kinetic constants are s-1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    dkhcat = 1.450e3
    dkdcat = 496.0e3

    for J in range(NZ + 1):
        for K in range(NC):
            if J < ( xS3 * NZ ):
                pt[J].dkd[K] = dkdcat
                pt[J].dkh[K] = dkhcat
            else:  # reduced reaction rates along the S3
                pt[J].dkd[K] = dkdcat / 100.0
                pt[J].dkh[K] = dkhcat / 100.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# BOUNDARY CONDITIONS IN PERITUBULAR SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Solute concentration in compartment S (mmole/liter)
# Since reference concentration is 1 mmole/liter = 1d-3 mmol/cm3,
# there is no need to convert to non-dimensional values
    
    for p in pt:
        p.ep[6-1] = -0.000 / EPref  # qnewton2PT assumes this is 0

#---------------------------------------------------------------------72
# Account for gradients in peritubular space
#---------------------------------------------------------------------72
# pos is a vector with the the non-dimensional distance from the upper boundary

    ind = int(xS3 * NZ) + 1
    indrev = int(NZ - (xS3 * NZ) ) 

    for jz in range( NZ + 1 ):
        if jz < ind:
            pos[jz] = jz / (xS3 * NZ)
            
            from set_intconc import set_intconc
            set_intconc(pt[0:ind], int(xS3 * NZ), 1, pos[0:ind])
       
        else: 
            pos[jz] = xIS * (jz - (xS3 * NZ)) / ((1 - xS3) * NZ)
            
            from set_intconc import set_intconc
            set_intconc( pt[ind:NZ+1], indrev - 1, 2, pos[ind:NZ+1] )

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIAL CONDITIONS AT LUMEN ENTRANCE
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    pt[0].vol[1-1] = sngfr / Vref  # Normalize flows and volumes by Vref
    
    for p in pt:
        p.volLuminit = pt[0].vol[1-1]
        
    pt[0].pres = PMinitPT  # initialize inflow pressure
            
    for I in range(1, NSPT + 1):
        pt[0].conc[I-1,1-1] = pt[0].conc[I-1,6-1]
        
    pt[0].ph[1-1] = pt[0].ph[6-1]
    pt[0].ep[1-1] = -0.16e-3/EPref  # Initial guess for lumen potential
    
#---------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------72

    elecM = 0.0
    elecS = 0.0
    elecS_out = 0.0
    
    for I in range(1, NSPT + 1):
        elecM += zval[I-1] * pt[0].conc[I-1,1-1]
        elecS += zval[I-1] * pt[0].conc[I-1,6-1]
        elecS_out += zval[I-1] * ( pt[NZ].conc[I-1,6-1] )

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#
# FOR TORQUE-MODULATED EFFECTS ON TRANSCELLULAR TRANSPORTER DENSITY
#
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Baseline Torque (Eq. 37 in 2007 PT model)
# Radref = DiamPT/2.0d0

    R_TMO = 0.002250/2.0  # It was Radref and for female case, previously discussed as 0.0020 / 2.0
    flowref = 24.0e-6 / 60.0 
    factor1 = 8.0 * visc * flowref * torqL / (R_TMO ** 2)
    factor2 = 1.0 + (torqL + torqd) / R_TMO + 0.50 * ((torqL / R_TMO) ** 2)
    
    for p in pt:
        p.TM0 = factor1 * factor2
    
# Note: the parameter torqR depends on the initial PM to Pblood difference
# The reference radius and torqR are related by:
# Radref = torqR*(1.0d0+torqvm*(PMinitPT - PbloodPT))
# 125.0 = 113.74*(1.0d0+0.03d0*(12.3d0 - 9.00d0))
#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------72
    for p in pt:
        p.TQ = 15.0 if not bdiabetes else 12.0
    # TNa-QO2 ratio in normal PT, else TNa-QO2 ratio in diabetic PT

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIAL GUESSES FOR CONCENTRATIONS, VOLUMES, AND POTENTIALS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    nrestart = 1  # If set to 1, then read initial values from a restart file
    
    if nrestart == 1:
    
        with open('PTresults', 'r') as f:
            for I in range(1, 5):
                pt[0].conc[I-1,1-1], pt[0].conc[I-1,2-1], pt[0].conc[I-1,5-1] = map(float, f.readline().split())
            for I in range(5, NSPT + 1):
                pt[0].conc[I-1,1-1], pt[0].conc[I-1,2-1], pt[0].conc[I-1,5-1] = map(float, f.readline().split())
            pt[0].ph[1-1], pt[0].ph[2-1], pt[0].ph[5-1] = map(float, f.readline().split())
            pt[0].vol[1-1], pt[0].vol[2-1], pt[0].vol[5-1] = map(float, f.readline().split())
            pt[0].ep[1-1], pt[0].ep[2-1], pt[0].ep[5-1] = map(float, f.readline().split())
    
    else:  # ! specify concentrations
        pt[0].ph[2-1] = 7.329
        pt[0].ph[5-1] = 7.339
        
        pt[0].conc[1-1,2-1] = 19.6
        pt[0].conc[1-1,5-1] = 140.3
        
        pt[0].conc[2-1,2-1] = 138.1
        pt[0].conc[2-1,5-1] = 4.66
        
        pt[0].conc[3-1,2-1] = 16.3
        pt[0].conc[3-1,5-1] = 112.0
        
        pt[0].conc[4-1,2-1] = 25.0
        pt[0].conc[4-1,5-1] = 25.6
        
        pt[0].conc[6-1,2-1] = 1.49
        pt[0].conc[6-1,5-1] = 1.49
        
        pt[0].conc[5-1,2-1] = 4.36e-3
        pt[0].conc[5-1,5-1] = 4.36e-3
        
        pt[0].conc[7-1,2-1] = 8.50
        pt[0].conc[7-1,5-1] = 2.98
        
        pt[0].conc[8-1,2-1] = 2.52
        pt[0].conc[8-1,5-1] = 0.86
        
        pt[0].conc[9-1,2-1] = 4.96
        pt[0].conc[9-1,5-1] = 4.91
        
        pt[0].conc[10-1,2-1] = 3.48e-3
        pt[0].conc[10-1,5-1] = 2.70e-3
        
        pt[0].conc[11-1,2-1] = 0.23
        pt[0].conc[11-1,5-1] = 0.18

        pt[0].conc[12-1,2-1] = np.exp(-np.log(10.0) * pt[0].ph[2-1]) * 1e3  # Convert to mM
        pt[0].conc[12-1,5-1] = np.exp(-np.log(10.0) * pt[0].ph[5-1]) * 1e3  # Convert to mM
        
        pt[0].conc[13-1,2-1] = 0.52
        pt[0].conc[13-1,5-1] = 0.77
        
        pt[0].conc[14-1,2-1] = 0.91e-4
        pt[0].conc[14-1,5-1] = 2.04e-4
        
        pt[0].conc[15-1,2-1] = 15.1
        pt[0].conc[15-1,5-1] = 7.79
        
        pt[0].vol[2-1] = 8.72
        pt[0].vol[5-1] = -1.967
        
        pt[0].ep[2-1] = -55.6e-3/EPref
        pt[0].ep[5-1] = -0.01e-3/EPref
        
#---------------------------------------------------------------------72
# Assign arbitrary values to compartments A (3) and B (4)
#---------------------------------------------------------------------72
        
    for I in range(1, NSPT + 1):
        pt[0].conc[I-1, 3-1] = pt[0].conc[I-1, 2-1]
        pt[0].conc[I-1, 4-1] = pt[0].conc[I-1, 2-1]

    pt[0].ph[3-1] = pt[0].ph[2-1]
    pt[0].ph[4-1] = pt[0].ph[2-1]

    pt[0].vol[3-1] = 0  # VolAinitial
    pt[0].vol[4-1] = 0  # VolBinitial

    pt[0].ep[3-1] = pt[0].ep[2-1]
    pt[0].ep[4-1] = pt[0].ep[2-1]
    
#---------------------------------------------------------------------72
# Define initial PT volume to determine ONC(1) in water flux calculations
#---------------------------------------------------------------------72    

    PTinitVol = pt[0].vol[1-1]

    return PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT
