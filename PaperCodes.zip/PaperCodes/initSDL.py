# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine for the mTAL
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 

def initSDL(sdl):

    # Local variables
    Pf = np.zeros((NC, NC))  # NC x NC array initialized with zeros
    pos = np.zeros(NZ + 1)  # Array with indices from 0 to NZ initialized with zeros
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Solute Indices: 1 = Na+, 2 = K+, 3 = Cl-, 4 = HCO3-, 5 = H2CO3, 6 = CO2
# 7 = HPO4(2-), 8 = H2PO4-, 9 = urea, 10 = NH3, 11 = NH4+, 12 = H+
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Calculate initial surfaces and volumes
# Volumes, surfaces, and angles implicitly include the number of
# each type of cell (but the PtoIratio doesn't).
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Data for rat (AMW model, AJP Renal 2005)
#---------------------------------------------------------------------72
    
    SlumPinitsdl = 2.0
    SbasPinitsdl = 2.0
    SlatPinitsdl = 10.0

    SlumEinitsdl = 0.001
    SbasEinitsdl = 0.020
    
#---------------------------------------------------------------------72
# Assign membrane surface area except for basal membrane of E
#---------------------------------------------------------------------
 
    for jz in range(NZ + 1):
        sdl[jz].area[0, 1] = SlumPinitsdl
        sdl[jz].area[0, 2] = SlumPinitsdl  # Replaced (SlumAinitsld not defined)
        sdl[jz].area[0, 3] = SlumPinitsdl  # Replaced (SlumBinitsld not defined)
        sdl[jz].area[0, 4] = SlumEinitsdl
        
        sdl[jz].area[1,4] = SlatPinitsdl
        sdl[jz].area[2,4] = SlatPinitsdl  # (idem)
        sdl[jz].area[3,4] = SlatPinitsdl  # (idem)
        
        sdl[jz].area[1,5] = SbasPinitsdl
        sdl[jz].area[2,5] = SbasPinitsdl  # (idem)
        sdl[jz].area[3,5] = SbasPinitsdl  # (idem)
        
        for k in range(1, NC-1+1):
            for l in range(k+1, NC+1):
                sdl[jz].area[l-1, k-1] = sdl[jz].area[k-1, l-1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Water permeabilities
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# The permeabilities have already been multiplied by the area (cm2/cm2 epith)
# dLPV(K,L) = hydraulic permeability at the K-L interface, in cm/s/mmHg
# Pf(K,L) = osmotic permeability at the K-L interface, in cm/s
# Relationship between the two: LPV=Pf*(Vwbar/RT)
               
    PfMP = 33.0e-4/2.0
    PfMA = 0.0
    PfMB = 0.0
    PfME = 0.70e-4/0.0010
    PfPE = 170.0e-4/10.0
    PfAE = 0.0
    PfBE = 0.0
    PfPS = 0.1 * 33.0e-4/2.0
    PfAS = 0.0
    PfBS = 0.0
    PfES = 8000.0e-4/0.020
    
    PfMP = 0.40/36.0
    PfMA = 0.0
    PfMB = 0.0
    PfME = 0.22/0.0010
    PfPE = 0.40/36.0
    PfAE = 0.0
    PfBE = 0.0
    PfPS = PfPE  
    PfAS = 0.0
    PfBS = 0.0
    PfES = 6.60/0.020
    
    Pf = np.zeros((NC, NC))

    Pf[1-1,2-1] = PfMP
    Pf[1-1,3-1] = PfMA
    Pf[1-1,4-1] = PfMB
    Pf[1-1,5-1] = PfME
    Pf[2-1,5-1] = PfPE
    Pf[3-1,5-1] = PfAE
    Pf[4-1,5-1] = PfBE
    Pf[2-1,6-1] = PfPS
    Pf[3-1,6-1] = PfAS
    Pf[4-1,6-1] = PfBS
    Pf[5-1,6-1] = PfES
    
# Units of dimensional water flux: cm3/s/cm2 epith
# Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
# Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
# dLPV = Pf/Pfref
     
    for jz in range(NZ + 1):
        for k in range(1, NC+1):
            for l in range(1, NC+1):
                sdl[jz].dLPV[k-1, l-1] = Pf[k-1, l-1] / Pfref

    for jz in range(NZ + 1):
        if jz >= (NZ * 0.46):      # Terminal water impermeable segment
            sdl[jz].dLPV[0, 1] *= 0.001
            sdl[jz].dLPV[0, 4] *= 0.001
            sdl[jz].dLPV[1, 4] *= 0.001
            sdl[jz].dLPV[1, 5] *= 0.001

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# sig(I,K,L) = reflection coefficient of Ith solute between K and L
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Initialize
    for jz in range(NZ + 1):
        for I in range(1, NS+1):
            for K in range(1, NC+1):
                for L in range(1, NC+1):
                    sdl[jz].sig[I-1, K-1, L-1] = 1.0

# Values at the basement membrane (ES)
    for jz in range(NZ + 1):
        for i in range(1, NS+1):
            sdl[jz].sig[i-1, 4, 5] = 0.0
            sdl[jz].sig[i-1, 5, 4] = 0.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# BOUNDARY CONDITIONS IN PERITUBULAR SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    xIS = 0.6 / 2.00   # outer-stripe 0.6 mm
    
    for jz in range(NZ + 1):
        sdl[jz].ep[5] = -0.001e-3 / EPref
        pos[jz] = xIS + (1 - xIS) * jz / NZ
        
    from set_intconc import set_intconc
    set_intconc( sdl, NZ, 2, pos )
    
#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------
 
# ndiabetes is 0:  TNa-QO2 ratio in normal SDL
# ndiabetes is not 0:  TNa-QO2 ratio in diabetic SDL
    for jz in range(NZ + 1):
        sdl[jz].TQ = 15.0 if ndiabetes == 0 else 12.0

#--------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------

    elecM = 0.0
    elecS = 0.0
     
    for I in range(1, NS + 1):
        elecM += zval[I-1] * sdl[0].conc[I-1,1-1]
        elecS += zval[I-1] * sdl[0].conc[I-1,6-1]
    
    return
