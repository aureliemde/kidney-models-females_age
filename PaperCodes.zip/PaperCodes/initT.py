# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This is the initialization routine for cTAL
# It sets up several parameters, constants, and initial guess values.

import numpy as np

from values import *
from glo import *
from defs import * 

def initT(ctal):
    
# local variables
    Pf = np.zeros((NC,NC))
    dLA = np.zeros((NS,NS,NC,NC))

    pos = np.zeros(NZ+1)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Calculate initial surfaces and volumes
# Volumes, surfaces, and angles implicitly include the number of
# each type of cell (but the PtoIratio doesn't).
#---------------------------------------------------------------------72
# Data for rat (AMW model, AJP Renal 2005)
#---------------------------------------------------------------------

    SlumPinittal = 2.0
    SbasPinittal = 2.0
    SlatPinittal = 10.0
    
    SlumEinittal = 0.001

    for p in ctal:        
        p.sbasEinit = 0.020
        
        p.volPinit = 5.0
        p.volEinit = 0.40
        
        p.volAinit = 5.0  # Needed for water flux subroutine (AURELIE)
        p.volBinit = 5.0  # Needed for water flux subroutine (AURELIE)
        
#---------------------------------------------------------------------72
# Assign membrane surface area except for basal membrane of E
#---------------------------------------------------------------------72        
        
        p.area[1-1,2-1] = SlumPinittal
        p.area[1-1,3-1] = SlumPinittal
        p.area[1-1,4-1] = SlumPinittal
        p.area[1-1,5-1] = SlumEinittal
        
        p.area[2-1,5-1] = SlatPinittal
        p.area[3-1,5-1] = SlatPinittal
        p.area[4-1,5-1] = SlatPinittal
        
        p.area[2-1,6-1] = SbasPinittal
        p.area[3-1,6-1] = SbasPinittal
        p.area[4-1,6-1] = SbasPinittal
        
    for K in range(1, NC -1 +1):
        for L in range(K + 1, NC + 1):
            for p in ctal:
                p.area[L-1, K-1] = p.area[K-1, L-1]
                  
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Water permeabilities
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# The permeabilities have already been multiplied by the area (cm2/cm2 epith)
# dLPV(K,L) = hydraulic permeability at the K-L interface, in cm/s/mmHg
# Pf(K,L) = osmotic permeability at the K-L interface, in cm/s
# Relationship between the two: LPV=Pf*(Vwbar/RT)
# WATER PERMEABILITIES
    PfMP = 33.0e-4/2.0*1.0e-3 
    PfMA = 0.0
    PfMB = 0.0
    PfME = 0.70e-4/0.0010
    PfPE = 170e-4/10.0
    PfAE = 0.0
    PfBE = 0.0
    PfPS = 33.0e-4/2.0
    PfAS = 0.0
    PfBS = 0.0
    PfES = 8000.0e-4/0.020
    
    Pf = np.zeros((NC, NC))

    Pf[1-1,2-1] = PfMP
    Pf[1-1,3-1] = PfMA
    Pf[1-1,4-1] = PfMB
    Pf[1-1,5-1] = PfME
    Pf[2-1,5-1] = PfPE
    Pf[3-1,5-1] = PfAE
    Pf[4-1,5-1] = PfBE
    Pf[2-1,6-1] = PfPS
    Pf[3-1,6-1] = PfAS
    Pf[4-1,6-1] = PfBS
    Pf[5-1,6-1] = PfES
    
# Units of dimensional water flux: cm3/s/cm2 epith
# Non-dimensional factor for water flux: (Pfref)*Vwbar*Cref
# Calculate non-dimensional dLPV = Pf*Vwbar*Cref / (Pfref*Vwbar*Cref)
# dLPV = Pf/Pfref

    for K in range(1, NC + 1):
        for L in range(1, NC + 1):
            for p in ctal:
                p.dLPV[K-1, L-1] = Pf[K-1, L-1] / Pfref

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# sig(I,K,L) = reflection coefficient of Ith solute between K and L
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(1, NC + 1):
                for p in ctal:
                    p.sig[i-1, k-1, l-1] = 1.0
            
# Values at the basement membrane (ES)
    for i in range(1, NS + 1):
        for p in ctal:
            p.sig[i-1, 5-1, 6-1] = 0.0
            p.sig[i-1, 6-1, 5-1] = 0.0

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional Solute permeabilities
# h(I,K,L) = permeability of ith solute at the K-L interface
# h(I,K,L) in 10-5 cm/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize
    for i in range(1, NS + 1):
        for k in range(1, NC + 1):
            for l in range(k, NC + 1):
                for p in ctal:
                    p.h[i-1, k-1, l-1] = 0.0

# Values at the MP interface (1-2)
    for p in ctal:
        p.h[1-1, 1-1, 2-1] = 0.0
        p.h[2-1, 1-1, 2-1] = 20.0
        p.h[3-1, 1-1, 2-1] = 0.0
        p.h[4-1, 1-1, 2-1] = 0.0
        p.h[5-1, 1-1, 2-1] = 130
        p.h[6-1, 1-1, 2-1] = 1.50e4
        p.h[7-1, 1-1, 2-1] = 0.0
        p.h[8-1, 1-1, 2-1] = 0.0
        p.h[9-1, 1-1, 2-1] = 0.06
        p.h[10-1, 1-1, 2-1] = 1.5e3
        p.h[11-1, 1-1, 2-1] = 4.0
        p.h[12-1, 1-1, 2-1] = 2.0e3
        p.h[13-1, 1-1, 2-1] = 0
        p.h[14-1, 1-1, 2-1] = 0
        p.h[15-1, 1-1, 2-1] = 0.0
        p.h[16-1, 1-1, 2-1] = 0.0001
        
# Values at the PE interface (2-5)
        p.h[1-1, 2-1, 5-1] = 0.000
        p.h[2-1, 2-1, 5-1] = 2.00
        p.h[3-1, 2-1, 5-1] = 0.50
        p.h[4-1, 2-1, 5-1] = 0.10
        p.h[5-1, 2-1, 5-1] = 130
        p.h[6-1, 2-1, 5-1] = 1.50e4
        p.h[7-1, 2-1, 5-1] = 0.008
        p.h[8-1, 2-1, 5-1] = 0.008
        p.h[9-1, 2-1, 5-1] = 0.06
        p.h[10-1, 2-1, 5-1] = 1.0e3
        p.h[11-1, 2-1, 5-1] = 0.40
        p.h[12-1, 2-1, 5-1] = 2.0e3
        p.h[13-1, 2-1, 5-1] = 1.0e-4
        p.h[14-1, 2-1, 5-1] = 1.0e-4
        p.h[15-1, 2-1, 5-1] = 1.0e-4
        p.h[16-1, 2-1, 5-1] = 0.0001
        
# Values at the PS interface (2-6)
    for i in range(1, NS + 1):
        for p in ctal:
            p.h[i-1, 2-1, 6-1] = p.h[i-1, 2-1, 5-1]
            
# Values at the MA interface (1-3)
# Values at the AE interface (3-5)
# Values at the AS interface (3-6)
# Values at the MB interface (1-4)
# Values at the BE interface (4-5)
# Values at the BS interface (4-6)

    for I in range(1, NS + 1):
        for p in ctal:
            p.h[I-1, 1-1, 3-1] = 0
            p.h[I-1, 3-1, 5-1] = 0
            p.h[I-1, 3-1, 6-1] = 0
            p.h[I-1, 1-1, 4-1] = 0
            p.h[I-1, 4-1, 5-1] = 0
            p.h[I-1, 4-1, 6-1] = 0
            
# Values at the ME interface (1-5)
    ClTJperm = 1000.0  # Factor for area = 1/0.001
    
    for p in ctal:
        p.h[1-1, 1-1, 5-1] = 2.80*ClTJperm
        p.h[2-1, 1-1, 5-1] = 3.00*ClTJperm
        p.h[3-1, 1-1, 5-1] = 1.40*ClTJperm            
        p.h[4-1, 1-1, 5-1] = 0.50*ClTJperm
        p.h[5-1, 1-1, 5-1] = 2.00*ClTJperm
        p.h[6-1, 1-1, 5-1] = 2.00*ClTJperm
        p.h[7-1, 1-1, 5-1] = 0.20*ClTJperm
        p.h[8-1, 1-1, 5-1] = 0.20*ClTJperm
        p.h[9-1, 1-1, 5-1] = 0.40*ClTJperm
        p.h[10-1, 1-1, 5-1] = 6.00*ClTJperm
        p.h[11-1, 1-1, 5-1] = 3.00*ClTJperm
        p.h[12-1, 1-1, 5-1] = 6.00*ClTJperm
        p.h[13-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[14-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[15-1, 1-1, 5-1] = 0.01*ClTJperm
        p.h[16-1, 1-1, 5-1] = 8.40*ClTJperm   # cTAL paracellular permeability to Ca2+   
            
# Values at the ES interface (5-6)
    areafactor = 1 / 0.02
    
    for p in ctal:
        p.h[1-1, 5-1, 6-1] = 72.14*areafactor
        p.h[2-1, 5-1, 6-1] = 96.18*areafactor
        p.h[3-1, 5-1, 6-1] = 96.18*areafactor
        p.h[4-1, 5-1, 6-1] = 48.09*areafactor
        p.h[5-1, 5-1, 6-1] = 72.14*areafactor
        p.h[6-1, 5-1, 6-1] = 72.14*areafactor
        p.h[7-1, 5-1, 6-1] = 48.09*areafactor
        p.h[8-1, 5-1, 6-1] = 48.09*areafactor
        p.h[9-1, 5-1, 6-1] = 48.09*areafactor
        p.h[10-1, 5-1, 6-1] = 60.11*areafactor
        p.h[11-1, 5-1, 6-1] = 96.18*areafactor
        p.h[12-1, 5-1, 6-1] = 480.90*areafactor
        p.h[13-1, 5-1, 6-1] = 1.0*areafactor
        p.h[14-1, 5-1, 6-1] = 1.0*areafactor
        p.h[15-1, 5-1, 6-1] = 1.0*areafactor
        p.h[16-1, 5-1, 6-1] = ( p.h[1-1,5-1,6-1] ) * (7.93/13.3)            

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional Solute permeabilities
# Divide h(I,K,L) by (href)
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            for L in range(K, NC + 1):
                for p in ctal:
                    p.h[I-1, K-1, L-1] *= 1.0e-5 / href
                    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Dimensional NET coefficients
# dLA(I,J,K,L) = coefficient of ith and jth solute at the K-L interface
# dLA(I,J,K,L) in mmol2/J/s initially
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Initialize

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    dLA[I-1, J-1, K-1, L-1] = 0.0
                        
# Cl/HCO3 exchanger on basolateral membrane

    dLA[3-1, 4-1, 2-1, 5-1] = 3.0e-9
    dLA[3-1, 4-1, 2-1, 6-1] = dLA[3-1, 4-1, 2-1, 5-1]
    
# Na/H exchangers on basolateral membrane

    dLA[1-1, 12-1, 2-1, 5-1] = 10.0e-9
    dLA[1-1, 12-1, 2-1, 6-1] = dLA[1-1, 12-1, 2-1, 5-1]
    
# Na2/HPO4 co-transporters on basolateral membrane

    dLA[1-1, 7-1, 2-1, 5-1] = 0.50e-9
    dLA[1-1, 7-1, 2-1, 6-1] = dLA[1-1, 7-1, 2-1, 5-1]
    
# Na/3HCO3 exchanger on basolateral membrane
    dLA[1-1, 4-1, 2-1, 5-1] = 0.50e-9
    dLA[1-1, 4-1, 2-1, 6-1] = dLA[1-1, 4-1, 2-1, 5-1]
     
# Apical NKCC2
    xNKCC2A = 1.3 * 15.0e-9 / 1.50 
    xNKCC2B = 1.3 * 18.0e-9 / 1.50 
    xNKCC2F = 1.3 * 0
    
# Apical NHE3
    xNHE3 = 6.0e-9
    
# Basolateral KCC4
    xKCC4 = 0.70e-9 
            
# Basolateral Na-K-ATPase
    ATPNaKPES = 1.3 * 1300.0e-9
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-Dimensional coefficients
# Divide dLA(I,J,K,L) by (href)*Cref for consistency with other
# solute flux terms
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72    
    
    for I in range(1, NS - 1 + 1):
        for J in range(I+1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(1, NC + 1):
                        dLA[J-1, I-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1]

    for I in range(1, NS + 1):
        for J in range(1, NS + 1):
            for K in range(1, NC + 1):
                for L in range(K, NC + 1):
                    for p in ctal:
                        p.dLA[I-1, J-1, K-1, L-1] = dLA[I-1, J-1, K-1, L-1] / (href * Cref)

    for p in ctal:
        p.xNKCC2B = xNKCC2B / (href*Cref)
        p.xNKCC2A = xNKCC2A / (href*Cref)
        p.xNKCC2F = xNKCC2F / (href*Cref)
    
        p.xNHE3 = xNHE3 / (href*Cref)
        p.xKCC4 = xKCC4 / (href*Cref)
    
        p.ATPNaK[2-1,5-1] = ATPNaKPES / (href*Cref)
        p.ATPNaK[2-1,6-1] = ATPNaKPES / (href*Cref)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Other kinetic parameters
# Units of kinetic constants are s-1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    dkhcat = 1.450e3
    dkdcat = 496.0e3
    
    for p in ctal:
        p.dkd[1-1] = dkdcat
        p.dkh[1-1] = dkhcat
        p.dkd[2-1] = dkdcat
        p.dkh[2-1] = dkhcat
        p.dkd[5-1] = dkdcat
        p.dkh[5-1] = dkhcat
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# BOUNDARY CONDITIONS IN PERITUBULAR SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
  
    ctal[0].ep[6-1] = -0.001e-3 / EPref
    
    for jz in range(0, NZ + 1):
        ctal[jz].ph[6-1] = ctal[0].ph[6-1]
        pos[jz] = 1.0 * (NZ-jz) / NZ 

    from set_intconc import set_intconc
    set_intconc(ctal, NZ, 1, pos)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIAL CONDITIONS AT LUMEN ENTRANCE
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    with open('mTALoutlet', 'r') as f:
        for I in range(1, 5):
            ctal[0].conc[I-1,1-1], ctal[0].conc[I-1,6-1] = map(float, f.readline().split())
        for I in range(5, NS + 1):
            ctal[0].conc[I-1,1-1], ctal[0].conc[I-1,6-1] = map(float, f.readline().split())
        ctal[0].ph[1-1], ctal[0].ph[6-1] = map(float, f.readline().split())
        ctal[0].ep[1-1], ctal[0].ep[6-1] = map(float, f.readline().split())
        ctal[0].vol[1-1], ctal[0].pres = map(float, f.readline().split())

    for p in ctal:
        p.volLuminit = ctal[0].vol[1-1]        

#---------------------------------------------------------------------72
# For metabolic calculations
#---------------------------------------------------------------------72

    for p in ctal:
        p.TQ = 15.0 if not bdiabetes else 12.0 
        # !TNa-QO2 ratio in normal cTAL, else TNa-QO2 ratio in diabetic cTAL
        
#--------------------------------------------------------------------72
# Check electroneutrality
#---------------------------------------------------------------------72
       
    elecM = 0.0
    elecS = 0.0
    elecS_out = 0.0
    
    for I in range(1, NS + 1):
        elecM += zval[I-1] * ctal[0].conc[I-1,1-1]
        elecS += zval[I-1] * ctal[0].conc[I-1,6-1]
        elecS_out += zval[I-1] * ( ctal[NZ].conc[I-1,6-1] )

    return
