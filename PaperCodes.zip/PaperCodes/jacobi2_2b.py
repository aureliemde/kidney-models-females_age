# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

import numpy as np

from values import *
from defs import * 
        
def jacobi2_2b(n, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, pt, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
   
    fvec_J = fvec
    fjac = np.zeros((ldfjac,n))
   
# local variables

    zero = 0.0

    epsmch = 2.22044604926e-16  

    eps = np.sqrt(max(epsfcn, epsmch))
    
# !
# ! computation of dense approximate jacobian.
# !
    
    for j in range(1, n + 1):
        temp = x[j-1]
        h = eps * np.abs(temp)
        
        if h == zero:
            h = eps
        
        x[j-1] = temp + h
        
        from fcn2b import fcn2b
        wa1 = fcn2b(n, x, iflag, numpar, pars, pt, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
# Restore x(j) to its original value
        x[j-1] = temp
        
        for i in range(1, n + 1):
            fjac[i-1, j-1] = (wa1[i-1] - fvec_J[i-1]) / h

    return fjac, wa1, fvec_J
