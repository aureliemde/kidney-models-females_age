# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This code is to mathematically model
# renal physiology in young, female rats
# and to compute the steady-state results.

# The folder Data includes the input/output results
# for the different blocks of the code. 

###########################################

# The Python version of this code uses numpy library 
# to handle arrays and data structures.
 
############################################

# Description: This is the main module (in the original fortran code) 
# for the entire nephron.

# This model yields the values of concentrations, volumes, and EP
# in the lumen and epithelial compartments at equilibrium.

# The units are those of the cgs system: cm, mmol, mmol/cm3 = M, s.
# The morphological parameters are those of the rat.

# Solute Indices:
#  1 = Na+,  2 = K+,  3 = Cl-,  4 = HCO3-,  
#  5 = H2CO3,  6 = CO2,  7 = HPO4(2-),  8 = H2PO4-,  
#  9 = urea,  10 = NH3,  11 = NH4+, 12 = H+,
#  13 = HCO2(-),  14 = H2CO2,  15 = glucose,  16 = Ca2+

#############################################
import time
import numpy as np

# Start the timer
tic = time.time()

from values import *
from glo import *
from defs import * 

# Create an instance of Membrane
membrane_inst = Membrane(NSPT, NC, NS)

# Initialize membrane arrays
pt = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
sdl = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
mtal = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
ctal = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
dct = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
cnt = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
ccd = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
omcd = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
imcd = [Membrane(NSPT, NC, NS) for _ in range(NZIMC + 1)]

# Variables used in printing output
inlet = np.zeros(NS)
outlet = np.zeros(NS)
fluxs = np.zeros(NS)
deliv = np.zeros(NS)
fracdel = np.zeros(NS)
totalAct = 0.0
totalTNa = 0.0
o2consum = 0.0
nephronAct = 0.0
nephronTNa = 0.0
nephronQO2 = 0.0

# Scaling factors for volume flows, which are normalized by Vref
# Assume that there are 36,000 nephrons that coalesce to 7,200 CDs
cw = Vref * 60.0 * Nneph  # to convert cm3/s to ml/min with Nneph nephrons
# cw = Vref * 60.0 * 1e6  # If basis is one nephron 
    
print("****************************************************")
print("                    PT RESULTS")
print("****************************************************")
print()

# Initialize tubular transport parameters and inflow conditions
from initPT import initPT
PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT = initPT(pt)

# First solve for the first cell: given BC, need only solve for values in cells
LzPT = -1
from qnewton1PT import qnewton1PT
qnewton1PT(pt, CPimprefPT, CPbuftotPT, 0, ncompl, ntorq, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)

# Then the rest of the PT: solve for values in lumen and cells
LzPT = 0
for J in range(1, NZ + 1):
    from qnewton2PT import qnewton2PT
    qnewton2PT(pt, J - 1, 0, pt[0].vol, CPimprefPT, CPbuftotPT, NDPT, ncompl, ntorq, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzPT += 1


# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('PToutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{pt[LzPT].conc[I-1, 1-1]:12.5f} {pt[LzPT].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{pt[LzPT].conc[I-1, 1-1]:12.5e} {pt[LzPT].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{pt[LzPT].ph[0]:12.5f} {pt[LzPT].ph[5]:12.5f}\n")
    f.write(f"{pt[LzPT].ep[0]:12.5f} {pt[LzPT].ep[5]:12.5f}\n")
    f.write(f"{pt[LzPT].vol[0]:12.5e} {pt[LzPT].vol[5]:12.5e}\n")

with open('PToutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{pt[LzPT].conc[I-1, 2-1]:12.5f} {pt[LzPT].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{pt[LzPT].conc[I-1, 2-1]:12.5e} {pt[LzPT].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{pt[LzPT].ph[1]:12.5f} {pt[LzPT].ph[4]:12.5f}\n")
    f.write(f"{pt[LzPT].ep[1]:12.5f} {pt[LzPT].ep[4]:12.5f}\n")
    f.write(f"{pt[LzPT].vol[1]:12.5e} {pt[LzPT].vol[4]:12.5e}\n")

# STOP
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE SDL
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

print("****************************************************")
print("                    SDL RESULTS")
print("****************************************************")
print()

# Initialization routine
from initSDL import initSDL
initSDL (sdl)

# If starting from PT, replace luminal concentrations 
# with PT outflow values
for j in range(1, NS+1):
    sdl[0].conc[j-1, 0] = pt[NZ].conc[j-1, 0]
sdl[0].ph[0] = pt[NZ].ph[0]
sdl[0].ep[0] = pt[NZ].ep[0]
sdl[0].vol[0] = pt[NZ].vol[0]
sdl[0].pres = pt[NZ].pres

# Determine luminal flow and concentrations along the SDL
LzSDL = 0  
for jz in range(1, NZ + 1):
    from qnewton2SDL import qnewton2SDL
    qnewton2SDL (sdl, jz-1, 2, sdl[0].vol, NDA, PTinitVol)
    LzSDL += 1

# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('SDLoutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{sdl[LzSDL].conc[I-1, 1-1]:12.5f} {sdl[LzSDL].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{sdl[LzSDL].conc[I-1, 1-1]:12.5e} {sdl[LzSDL].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{sdl[LzSDL].ph[0]:12.5f} {sdl[LzSDL].ph[5]:12.5f}\n")
    f.write(f"{sdl[LzSDL].ep[0]:12.5f} {sdl[LzSDL].ep[5]:12.5f}\n")
    f.write(f"{sdl[LzSDL].vol[0]:12.5e} {sdl[LzSDL].vol[5]:12.5e}\n")

# ---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE mTAL
#---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

print("****************************************************")
print("                    mTAL RESULTS")
print("****************************************************")
print()

# Initialization routine
from initA import initA
initA (mtal)

# Luminal concentrations are set to SDL outflow values in initA
# Initial guesses for cellular and LIS concentrations are in mTALresults

with open('mTALresults', 'r') as f:
    for I in range(1, 5):
        mtal[0].conc[I-1,2-1], mtal[0].conc[I-1,5-1] = map(float, f.readline().split())
    for I in range(5, NS + 1):
        mtal[0].conc[I-1,2-1], mtal[0].conc[I-1,5-1] = map(float, f.readline().split())
    mtal[0].ph[2-1], mtal[0].ph[5-1] = map(float, f.readline().split())
    mtal[0].vol[2-1], mtal[0].vol[5-1] = map(float, f.readline().split())
    mtal[0].ep[2-1], mtal[0].ep[5-1] = map(float, f.readline().split())

# Determine luminal flow and concentrations along the mTAL

LzA = 0  
for jz in range(1, NZ + 1):
    from qnewton2b import qnewton2b
    qnewton2b(mtal, mtal[0].vol, jz - 1, 3, NDA, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzA += 1
    
# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('mTALoutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{mtal[LzA].conc[I-1, 1-1]:12.5f} {mtal[LzA].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{mtal[LzA].conc[I-1, 1-1]:12.5e} {mtal[LzA].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{mtal[LzA].ph[0]:12.5f} {mtal[LzA].ph[5]:12.5f}\n")
    f.write(f"{mtal[LzA].ep[0]:12.5f} {mtal[LzA].ep[5]:12.5f}\n")
    f.write(f"{mtal[LzA].vol[0]:12.5e} {mtal[LzA].vol[5]:12.5e}\n")

with open('mTALoutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{mtal[LzA].conc[I-1, 2-1]:12.5f} {mtal[LzA].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{mtal[LzA].conc[I-1, 2-1]:12.5e} {mtal[LzA].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{mtal[LzA].ph[1]:12.5f} {mtal[LzA].ph[4]:12.5f}\n")
    f.write(f"{mtal[LzA].ep[1]:12.5f} {mtal[LzA].ep[4]:12.5f}\n")
    f.write(f"{mtal[LzA].vol[1]:12.5e} {mtal[LzA].vol[4]:12.5e}\n")

# ---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE cTAL
#---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

print("****************************************************")
print("                    cTAL RESULTS")
print("****************************************************")
print()

# Initialization routine
from initT import initT
initT (ctal)

# Luminal concentrations are set to mTAL outflow values in initT
# Initial guesses for cellular and LIS concentrations are in cTALresults

with open('cTALresults', 'r') as f:
    for I in range(1, 5):
        ctal[0].conc[I-1,2-1], ctal[0].conc[I-1,5-1] = map(float, f.readline().split())
    for I in range(5, NS + 1):
        ctal[0].conc[I-1,2-1], ctal[0].conc[I-1,5-1] = map(float, f.readline().split())
    ctal[0].ph[2-1], ctal[0].ph[5-1] = map(float, f.readline().split())
    ctal[0].vol[2-1], ctal[0].vol[5-1] = map(float, f.readline().split())
    ctal[0].ep[2-1], ctal[0].ep[5-1] = map(float, f.readline().split())
 
# Determine luminal flow and concentrations along the cTAL

LzT = 0  
for jz in range(1, NZ + 1):
    from qnewton2b import qnewton2b
    qnewton2b(ctal, ctal[0].vol, jz - 1, 4, NDA, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzT += 1

# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('cTALoutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{ctal[LzT].conc[I-1, 1-1]:12.5f} {ctal[LzT].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{ctal[LzT].conc[I-1, 1-1]:12.5e} {ctal[LzT].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{ctal[LzT].ph[0]:12.5f} {ctal[LzT].ph[5]:12.5f}\n")
    f.write(f"{ctal[LzT].ep[0]:12.5f} {ctal[LzT].ep[5]:12.5f}\n")
    f.write(f"{ctal[LzT].vol[0]:12.5e} {ctal[LzT].vol[5]:12.5e}\n")

with open('cTALoutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{ctal[LzT].conc[I-1, 2-1]:12.5f} {ctal[LzT].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{ctal[LzT].conc[I-1, 2-1]:12.5e} {ctal[LzT].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{ctal[LzT].ph[1]:12.5f} {ctal[LzT].ph[4]:12.5f}\n")
    f.write(f"{ctal[LzT].ep[1]:12.5f} {ctal[LzT].ep[4]:12.5f}\n")
    f.write(f"{ctal[LzT].vol[1]:12.5e} {ctal[LzT].vol[4]:12.5e}\n")

# # # # STOP
# ---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE DCT
#---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

print("****************************************************")
print("                    DCT RESULTS")
print("****************************************************")
print()

from initD import initD
initD (dct)

# Luminal concentrations are set to cTAL outflow values in initD
# Initial guesses for cellular and LIS concentrations are in DCTresults

with open('DCTresults', 'r') as f:
    for I in range(1, 5):
        dct[0].conc[I-1,2-1], dct[0].conc[I-1,5-1] = map(float, f.readline().split())
    for I in range(5, NS + 1):
        dct[0].conc[I-1,2-1], dct[0].conc[I-1,5-1] = map(float, f.readline().split())
    dct[0].ph[2-1], dct[0].ph[5-1] = map(float, f.readline().split())
    dct[0].vol[2-1], dct[0].vol[5-1] = map(float, f.readline().split())
    dct[0].ep[2-1], dct[0].ep[5-1] = map(float, f.readline().split())

# Determine luminal flow and concentrations along the DCT

LzD = 0  
for jz in range(1, NZ + 1):
    from qnewton2b import qnewton2b
    qnewton2b(dct, dct[0].vol, jz - 1, 5, NDA, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzD += 1

# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('DCToutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{dct[LzD].conc[I-1, 1-1]:12.5f} {dct[LzD].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{dct[LzD].conc[I-1, 1-1]:12.5e} {dct[LzD].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{dct[LzD].ph[0]:12.5f} {dct[LzD].ph[5]:12.5f}\n")
    f.write(f"{dct[LzD].ep[0]:12.5f} {dct[LzD].ep[5]:12.5f}\n")
    f.write(f"{dct[LzD].vol[0]:12.5e} {dct[LzD].vol[5]:12.5e}\n")

with open('DCToutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{dct[LzD].conc[I-1, 2-1]:12.5f} {dct[LzD].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{dct[LzD].conc[I-1, 2-1]:12.5e} {dct[LzD].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{dct[LzD].ph[1]:12.5f} {dct[LzD].ph[4]:12.5f}\n")
    f.write(f"{dct[LzD].ep[1]:12.5f} {dct[LzD].ep[4]:12.5f}\n")
    f.write(f"{dct[LzD].vol[1]:12.5e} {dct[LzD].vol[4]:12.5e}\n")

# ---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE CNT
#---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

print("****************************************************")
print("                    CNT RESULTS")
print("****************************************************")
print()

from initC import initC
initC (cnt)

# Luminal concentrations are set to DCT outflow values in initC
# Initial guesses for cellular and LIS concentrations are in CNTresults

with open('CNTresults', 'r') as f:
    for I in range(1, 5):
        cnt[0].conc[I-1,2-1], cnt[0].conc[I-1,3-1], cnt[0].conc[I-1,4-1], cnt[0].conc[I-1,5-1] = map(float, f.readline().split())
    for I in range(5, NS + 1):
        cnt[0].conc[I-1,2-1], cnt[0].conc[I-1,3-1], cnt[0].conc[I-1,4-1], cnt[0].conc[I-1,5-1] = map(float, f.readline().split())
    cnt[0].ph[2-1], cnt[0].ph[3-1], cnt[0].ph[4-1], cnt[0].ph[5-1] = map(float, f.readline().split())
    cnt[0].vol[2-1], cnt[0].vol[3-1], cnt[0].vol[4-1], cnt[0].vol[5-1] = map(float, f.readline().split())
    cnt[0].ep[2-1], cnt[0].ep[3-1], cnt[0].ep[4-1], cnt[0].ep[5-1] = map(float, f.readline().split())

# Determine luminal flow and concentrations along the CNT

LzC = 0  
for jz in range(1, NZ + 1):
    from qnewton2icb import qnewton2icb
    qnewton2icb(cnt, jz - 1, 6, cnt[0].vol, cnt[jz].volEinit, cnt[jz].volPinit, cnt[jz].volAinit, cnt[jz].volBinit, NDC, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzC += 1

# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('CNToutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{cnt[LzC].conc[I-1, 1-1]:12.5f} {cnt[LzC].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{cnt[LzC].conc[I-1, 1-1]:12.5e} {cnt[LzC].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{cnt[LzC].ph[0]:12.5f} {cnt[LzC].ph[5]:12.5f}\n")
    f.write(f"{cnt[LzC].ep[0]:12.5f} {cnt[LzC].ep[5]:12.5f}\n")
    f.write(f"{cnt[LzC].vol[0]:12.5e} {cnt[LzC].vol[5]:12.5e}\n")

with open('CNToutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{cnt[LzC].conc[I-1, 2-1]:12.5f} {cnt[LzC].conc[I-1, 3-1]:12.5f} {cnt[LzC].conc[I-1, 4-1]:12.5f} {cnt[LzC].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{cnt[LzC].conc[I-1, 2-1]:12.5e} {cnt[LzC].conc[I-1, 3-1]:12.5e} {cnt[LzC].conc[I-1, 4-1]:12.5e} {cnt[LzC].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{cnt[LzC].ph[1]:12.5f} {cnt[LzC].ph[2]:12.5f} {cnt[LzC].ph[3]:12.5f} {cnt[LzC].ph[4]:12.5f}\n")
    f.write(f"{cnt[LzC].ep[1]:12.5f} {cnt[LzC].ep[2]:12.5f} {cnt[LzC].ep[3]:12.5f} {cnt[LzC].ep[4]:12.5f}\n")
    f.write(f"{cnt[LzC].vol[1]:12.5e} {cnt[LzC].vol[2]:12.5e} {cnt[LzC].vol[3]:12.5e} {cnt[LzC].vol[4]:12.5e}\n")

#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE CCD
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

print("****************************************************")
print("                    CCD RESULTS")
print("****************************************************")
print()

from initCCD import initCCD
initCCD (ccd)

# Luminal concentrations are set to CNT outflow values in initD
# Initial guesses for cellular and LIS concentrations are in CCDresults

with open('CCDresults', 'r') as f:
    for I in range(1, 5):
        ccd[0].conc[I-1,2-1], ccd[0].conc[I-1,3-1], ccd[0].conc[I-1,4-1], ccd[0].conc[I-1,5-1] = map(float, f.readline().split())
    for I in range(5, NS + 1):
        ccd[0].conc[I-1,2-1], ccd[0].conc[I-1,3-1], ccd[0].conc[I-1,4-1], ccd[0].conc[I-1,5-1] = map(float, f.readline().split())
    ccd[0].ph[2-1], ccd[0].ph[3-1], ccd[0].ph[4-1], ccd[0].ph[5-1] = map(float, f.readline().split())
    ccd[0].vol[2-1], ccd[0].vol[3-1], ccd[0].vol[4-1], ccd[0].vol[5-1] = map(float, f.readline().split())
    ccd[0].ep[2-1], ccd[0].ep[3-1], ccd[0].ep[4-1], ccd[0].ep[5-1] = map(float, f.readline().split())

# Determine luminal flow and concentrations along the CCD

LzCCD = 0  
for jz in range(1, NZ + 1):
    from qnewton2icb import qnewton2icb
    qnewton2icb(ccd, jz - 1, 7, ccd[0].vol, ccd[jz].volEinit, ccd[jz].volPinit, ccd[jz].volAinit, ccd[jz].volBinit, NDC, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzCCD += 1

# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('CCDoutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{ccd[LzCCD].conc[I-1, 1-1]:12.5f} {ccd[LzCCD].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{ccd[LzCCD].conc[I-1, 1-1]:12.5e} {ccd[LzCCD].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{ccd[LzCCD].ph[0]:12.5f} {ccd[LzCCD].ph[5]:12.5f}\n")
    f.write(f"{ccd[LzCCD].ep[0]:12.5f} {ccd[LzCCD].ep[5]:12.5f}\n")
    f.write(f"{ccd[LzCCD].vol[0]:12.5e} {ccd[LzCCD].vol[5]:12.5e}\n")

with open('CCDoutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{ccd[LzCCD].conc[I-1, 2-1]:12.5f} {ccd[LzCCD].conc[I-1, 3-1]:12.5f} {ccd[LzCCD].conc[I-1, 4-1]:12.5f} {ccd[LzCCD].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{ccd[LzCCD].conc[I-1, 2-1]:12.5e} {ccd[LzCCD].conc[I-1, 3-1]:12.5e} {ccd[LzCCD].conc[I-1, 4-1]:12.5e} {ccd[LzCCD].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{ccd[LzCCD].ph[1]:12.5f} {ccd[LzCCD].ph[2]:12.5f} {ccd[LzCCD].ph[3]:12.5f} {ccd[LzCCD].ph[4]:12.5f}\n")
    f.write(f"{ccd[LzCCD].ep[1]:12.5f} {ccd[LzCCD].ep[2]:12.5f} {ccd[LzCCD].ep[3]:12.5f} {ccd[LzCCD].ep[4]:12.5f}\n")
    f.write(f"{ccd[LzCCD].vol[1]:12.5e} {ccd[LzCCD].vol[2]:12.5e} {ccd[LzCCD].vol[3]:12.5e} {ccd[LzCCD].vol[4]:12.5e}\n")

# ---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE OMCD
#---------------------------------------------------------------------72
# ---------------------------------------------------------------------72

print("****************************************************")
print("                    OMCD RESULTS")
print("****************************************************")
print()

from initOMC import initOMC
initOMC (omcd)

# Luminal concentrations are set to CCD outflow values in initOMC
# Initial guesses for cellular and LIS concentrations are in OMCresults

with open('OMCresults', 'r') as f:
    for I in range(1, 5):
        omcd[0].conc[I-1,2-1], omcd[0].conc[I-1,3-1], omcd[0].conc[I-1,4-1], omcd[0].conc[I-1,5-1] = map(float, f.readline().split())
    for I in range(5, NS + 1):
        omcd[0].conc[I-1,2-1], omcd[0].conc[I-1,3-1], omcd[0].conc[I-1,4-1], omcd[0].conc[I-1,5-1] = map(float, f.readline().split())
    omcd[0].ph[2-1], omcd[0].ph[3-1], omcd[0].ph[4-1], omcd[0].ph[5-1] = map(float, f.readline().split())
    omcd[0].vol[2-1], omcd[0].vol[3-1], omcd[0].vol[4-1], omcd[0].vol[5-1] = map(float, f.readline().split())
    omcd[0].ep[2-1], omcd[0].ep[3-1], omcd[0].ep[4-1], omcd[0].ep[5-1] = map(float, f.readline().split())

# Determine luminal flow and concentrations along the OMCD
LzOMC = 0  
for jz in range(1, NZ + 1):
    from qnewton2icb import qnewton2icb
    qnewton2icb(omcd, jz - 1, 8, omcd[0].vol, omcd[jz].volEinit, omcd[jz].volPinit, omcd[jz].volAinit, omcd[jz].volBinit, NDC, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzOMC += 1
    
# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('OMCoutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{omcd[LzOMC].conc[I-1, 1-1]:12.5f} {omcd[LzOMC].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{omcd[LzOMC].conc[I-1, 1-1]:12.5e} {omcd[LzOMC].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{omcd[LzOMC].ph[0]:12.5f} {omcd[LzOMC].ph[5]:12.5f}\n")
    f.write(f"{omcd[LzOMC].ep[0]:12.5f} {omcd[LzOMC].ep[5]:12.5f}\n")
    f.write(f"{omcd[LzOMC].vol[0]:12.5e} {omcd[LzOMC].vol[5]:12.5e}\n")

with open('OMCoutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{omcd[LzOMC].conc[I-1, 2-1]:12.5f} {omcd[LzOMC].conc[I-1, 3-1]:12.5f} {omcd[LzOMC].conc[I-1, 4-1]:12.5f} {omcd[LzOMC].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{omcd[LzOMC].conc[I-1, 2-1]:12.5e} {omcd[LzOMC].conc[I-1, 3-1]:12.5e} {omcd[LzOMC].conc[I-1, 4-1]:12.5e} {omcd[LzOMC].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{omcd[LzOMC].ph[1]:12.5f} {omcd[LzOMC].ph[2]:12.5f} {omcd[LzOMC].ph[3]:12.5f} {omcd[LzOMC].ph[4]:12.5f}\n")
    f.write(f"{omcd[LzOMC].ep[1]:12.5f} {omcd[LzOMC].ep[2]:12.5f} {omcd[LzOMC].ep[3]:12.5f} {omcd[LzOMC].ep[4]:12.5f}\n")
    f.write(f"{omcd[LzOMC].vol[1]:12.5e} {omcd[LzOMC].vol[2]:12.5e} {omcd[LzOMC].vol[3]:12.5e} {omcd[LzOMC].vol[4]:12.5e}\n")

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE PROFILES ALONG THE IMCD
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

print("****************************************************")
print("                    IMCD RESULTS")
print("****************************************************")
print()

from initIMC import initIMC
initIMC (imcd)

# Luminal concentrations are set to CCD outflow values in initIMC
# Initial guesses for cellular and LIS concentrations are in IMCresults

with open('IMCresults', 'r') as f:
    for I in range(1, 5):
        imcd[0].conc[I-1,2-1], imcd[0].conc[I-1,5-1] = map(float, f.readline().split())
    for I in range(5, NS + 1):
        imcd[0].conc[I-1,2-1], imcd[0].conc[I-1,5-1] = map(float, f.readline().split())
    imcd[0].ph[2-1], imcd[0].ph[5-1] = map(float, f.readline().split())
    imcd[0].vol[2-1], imcd[0].vol[5-1] = map(float, f.readline().split())
    imcd[0].ep[2-1], imcd[0].ep[5-1] = map(float, f.readline().split())

# Determine luminal flow and concentrations along the IMC
LzIMC = 0
for jz in range(1, NZIMC + 1):
    from qnewton2b import qnewton2b
    qnewton2b(imcd, imcd[0].vol, jz - 1, 9, NDIMC, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
    LzIMC += 1

# ---------------------------------------------------------------------72
# print to output file
# ---------------------------------------------------------------------72

with open('IMCoutlet', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{imcd[LzIMC].conc[I-1, 1-1]:12.5f} {imcd[LzIMC].conc[I-1, 6-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{imcd[LzIMC].conc[I-1, 1-1]:12.5e} {imcd[LzIMC].conc[I-1, 6-1]:12.5e}\n")
    f.write(f"{imcd[LzIMC].ph[0]:12.5f} {imcd[LzIMC].ph[5]:12.5f}\n")
    f.write(f"{imcd[LzIMC].ep[0]:12.5f} {imcd[LzIMC].ep[5]:12.5f}\n")
    f.write(f"{imcd[LzIMC].vol[0]:12.5e} {imcd[LzIMC].vol[5]:12.5e}\n")

with open('IMCoutlet_all', 'w') as f:
    for I in range(1, 4+1):
        f.write(f"{imcd[LzIMC].conc[I-1, 2-1]:12.5f} {imcd[LzIMC].conc[I-1, 5-1]:12.5f}\n")
    for I in range(5, NS + 1):
        f.write(f"{imcd[LzIMC].conc[I-1, 2-1]:12.5e} {imcd[LzIMC].conc[I-1, 5-1]:12.5e}\n")
    f.write(f"{imcd[LzIMC].ph[1]:12.5f} {imcd[LzIMC].ph[4]:12.5f}\n")
    f.write(f"{imcd[LzIMC].ep[1]:12.5f} {imcd[LzIMC].ep[4]:12.5f}\n")
    f.write(f"{imcd[LzIMC].vol[1]:12.5e} {imcd[LzIMC].vol[4]:12.5e}\n")

#---------------------------------------------------------------------72
# Output solute flux
#---------------------------------------------------------------------72

for I in range(1, NS + 1):
    outlet[I-1] = imcd[NZ].vol[1-1] * imcd[NZ].conc[I-1, 1-1] * cw

with open('Outlet_SS', 'w') as f:
    for I in range(1, NS + 1):
        f.write(f"{outlet[I-1]:12.5f}\n")
        
Outp_1 = imcd[NZ].vol[1-1] * cw
Outp_2 = outlet[1-1]
Outp_3 = outlet[2-1]
Outp_4 = imcd[NZ].ph[1-1]

# End the timer
toc = time.time()
