# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

import numpy as np

from values import *
from glo import *
from defs import * 

def out_data_PT(pt):
    
# variables used in printing output
    inlet = np.zeros(NSPT)
    outlet = np.zeros(NSPT)
    fluxs = np.zeros(NSPT)
    
    deliv = np.zeros(NSPT)
    fracdel = np.zeros(NSPT)
    
# ---------------------------------------------------------------------72
# Output solute flux
# ---------------------------------------------------------------------72
    
# convert from cm3/s to nl/min/mm tubule
    cwplPT = Vref * 60.0 * 1.0e6 / (dimLPT * 10.0)  # to convert to nl/min/mm
    
# Assume that there are 36,000 nephrons that coalesce to 7,200 CDs
    cw = Vref * 60.0 * 36000  # to convert to ml/min
   
# If the basis is one nephron
# cw = Vref*60.d0*1e6 !to convert to nl/min
    
    for I in range(1, NSPT + 1):
        deliv[I-1] = pt[0].conc[I-1, 1-1] * pt[0].vol[1-1] * cw
    
    print("****************************************************")
    print("\nOVERALL PT RESULTS\n")
    volreab = (pt[0].vol[1-1] - pt[NZ].vol[1-1]) * cw
    print(f" Water in, reabsorbed, out (nl/min): {pt[0].vol[1-1] * cw * 1.0e3:.3f}, {-volreab * 1.0e3:.3f}, {pt[NZ].vol[1-1] * cw * 1.0e3:.3f}")
    print(f" % Water reabsorbed: {1.0 - pt[NZ].vol[1-1] / pt[0].vol[1-1]:.3f}")
    print(f" distal pressure: {pt[NZ].pres:.4f}\n")
    
    print("Solute in, reabsorbed, out (pmol/min)\n")
    
    for I in range(1, NSPT + 1):
        outlet[I-1] = pt[NZ].vol[1-1] * pt[NZ].conc[I-1, 1-1] * cw
        inlet[I-1] = pt[0].vol[1-1] * pt[0].conc[I-1, 1-1] * cw
        fluxs[I-1] = inlet[I-1] - outlet[I-1]
        fracdel[I-1] = fluxs[I-1] / deliv[I-1]
        print(f" Solute {I-1}: {inlet[I-1]:.4f}, {-fluxs[I-1]:.4f}, {outlet[I-1]:.4f}")
    print("\n")
    
#---------------------------------------------------------------------72
# Results summary
# reabsorption along PT, and DL delivery
#---------------------------------------------------------------------72

    ReabNapt = (pt[0].vol[1-1] * pt[0].conc[1-1, 1-1] - pt[NZ].vol[1-1] * pt[NZ].conc[1-1, 1-1]) * cw
    DelivNa = pt[NZ].vol[1-1] * pt[NZ].conc[1-1, 1-1] * cw
    
    ReabClpt = (pt[0].vol[1-1] * pt[0].conc[3-1, 1-1] - pt[NZ].vol[1-1] * pt[NZ].conc[3-1, 1-1]) * cw
    DelivCl = pt[NZ].vol[1-1] * pt[NZ].conc[3-1, 1-1] * cw
    
    ReabKpt = (pt[0].vol[1-1] * pt[0].conc[2-1, 1-1] - pt[NZ].vol[1-1] * pt[NZ].conc[2-1, 1-1]) * cw
    DelivK = pt[NZ].vol[1-1] * pt[NZ].conc[2-1, 1-1] * cw
    
    print("PT reabs: absolute vs. percentage")
    print(f" Na: {ReabNapt:.4f}, {ReabNapt / (pt[0].vol[1-1] * pt[0].conc[1-1, 1-1] * cw):.4f}")
    print(f" Cl: {ReabClpt:.4f}, {ReabClpt / (pt[0].vol[1-1] * pt[0].conc[3-1, 1-1] * cw):.4f}")
    print(f" K : {ReabKpt:.4f}, {ReabKpt / (pt[0].vol[1-1] * pt[0].conc[2-1, 1-1] * cw):.4f}")
    print(f" pH: {pt[0].ph[1-1]:.4f}, {pt[NZ].ph[1-1]:.4f}")
    
# generate output files
# call output_pt_profiles (pt)

#---------------------------------------------------------------------72
# Results summary
# integrated fluxes along PT
#---------------------------------------------------------------------72
    
    from compute_o2_consumption import compute_o2_consumption
    nephronAct, nephronTNa, nephronQO2, nephronTK = compute_o2_consumption(pt, 'PT', dimLPT, 0, NZ)
    
    NZS3 = int( 88 * NZ / 100 - 1 )
    ReabGluS3 = (pt[NZS3].vol[1-1] * pt[NZS3].conc[15-1, 1-1] - pt[NZ].vol[1-1] * pt[NZ].conc[15-1, 1-1]) * cw
    percS3 = ReabGluS3 / inlet[15-1]  # Percent of glucose load, not of glucose reabsorbed
    
    nephronActPCT = 0
    nephronTNaPCT = 0
    nephronQO2PCT = 0
    
    from compute_o2_consumption import compute_o2_consumption
    nephronActPCT, nephronTNaPCT, nephronQO2PCT, nephronTKPCT = compute_o2_consumption(pt, 'PCT', dimLPT * NZS3 / NZ, 0, NZS3)
    
    nephronActS3 = 0
    nephronTNaS3 = 0
    nephronQO2S3 = 0
    
    from compute_o2_consumption import compute_o2_consumption
    nephronActS3, nephronTNaS3, nephronQO2S3, nephronTKS3 = compute_o2_consumption(pt, 'S3', dimLPT - dimLPT * NZS3 / NZ, NZS3, NZ)

    return nephronAct, nephronTNa, nephronQO2, nephronTK
