# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This is a subroutine to compute PT fluxes

# INPUT ARGUMENTS:
# x: vector of 4*NSPT concentrations, 4 volumes, and 4 potentials
#
# OUTPUT ARGUMENTS:
# Jvol: volume fluxes
# Jsol: solute fluxes
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 

# Note:
LzPT = -1 # LzPT in "main" starts from -1 for "qnewton1PT"
# Thus, it is LzPT+1 as Fortran version (No need for LzPT+1-1)
  
def qflux1PT(x, Cext, EPext, pt, vol0, dcompl, dtorq, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    C = np.zeros((NSPT, NC))
    ph = np.zeros(NC)
    Vol = np.zeros(NC)
    EP = np.zeros(NC)
    
    nagluparam = np.zeros(7)
   
# for HKATPase matrix inversion

    lwork = 10000  
    ipiv = np.zeros(Natp)
    work = np.zeros(lwork)
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ASSIGN CONCENTRATIONS, VOLUMES, AND POTENTIALS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for J in range(1, NSPT + 1):
        C[J-1, 6-1] = Cext[J-1]
    EP[6-1] = EPext

    for I in range(1, NSPT + 1):
        C[I-1, 1-1] = x[1 + 3 * (I-1) -1]
        C[I-1, 2-1] = x[2 + 3 * (I-1) -1]
        C[I-1, 5-1] = x[3 + 3 * (I-1) -1]

    Vol[0] = x[0 + 3 * NSPT]
    Vol[1] = x[1 + 3 * NSPT]
    Vol[4] = x[2 + 3 * NSPT]
    EP[0] = x[3 + 3 * NSPT]
    EP[1] = x[4 + 3 * NSPT]
    EP[4] = x[5 + 3 * NSPT]
    PM = x[6 + 3 * NSPT]
    
# Assign dummy values to compartments 3 and 4

    for I in range(1, NSPT + 1):
        C[I-1, 3-1] = C[I-1, 2-1]
        C[I-1, 4-1] = C[I-1, 2-1]

    for K in range(1, NC + 1):
        ph[K-1] = -np.log10( C[12-1, K-1] / 1.0e3 )
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE THE NEW SURFACE AREAS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    pt[0].area[5-1, 6-1] = pt[0].sbasEinit * max( Vol[5-1] / pt[0].volEinit, 1.0 )
    pt[0].area[6-1, 5-1] = pt[0].area[5-1, 6-1]
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIALIZE ALL FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NSPT, NC, NC))
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    from compute_water_fluxes import compute_water_fluxes
    
    Jvol = compute_water_fluxes (C, PM, PbloodPT, Vol, pt[0].volLuminit, 
                           pt[0].volEinit, pt[0].volPinit, CPimprefPT,
                           pt[0].volAinit, CAimprefPT, pt[0].volBinit, 
                           CBimprefPT, pt[0].area, pt[0].sig, pt[0].dLPV,
                           complPT, PTinitVol)
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOLUTE FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FOR TORQUE-MODULATED EFFECTS
#---------------------------------------------------------------------72
# compliant tubule radius (Eq. 38 in 2007 PT model)

    if dcompl < 0:
        RMtorq = pt[0].diam / 2.0  # non-compliant tubule
    else:
        RMtorq = torqR * (1.0 + torqvm * (PM - PbloodPT))

# Torque (Eq. 37 in 2007 PT model)
    factor1 = 8.0 * visc * (Vol[1-1] * Vref) * torqL / (RMtorq ** 2)
    factor2 = 1.0 + (torqL + torqd) / RMtorq + 0.50 * ((torqL / RMtorq) ** 2)
    Torque = factor1 * factor2
    
# Torque scaling parameter (Eq. 39 in 2007 PT model)
    if dtorq < 0:
        Scaletorq = 1.0  # No torque effect on transporter density
    else:
        Scaletorq = 1.0 + TS * pt[0].scaleT * (Torque / pt[0].TM0 - 1.0)
        PTtorque[LzPT +1] = Scaletorq
        
    Scaletorq = max(Scaletorq, 0.001)

# Non-dimensional solute fluxes are first converted to dimensional fluxes
# (in mmol/s/cm2 epith) by multiplying by href*Cref
# Then they are converted to units of pmol/min/mm tubule

    convert = href * Cref * np.pi * pt[0].diam * 60 / 10 * 1.0e9 * Scaletorq  # Conversion factor

#---------------------------------------------------------------------72
# ELECTRO-CONVECTIVE-DIFFUSIVE FLUXES
#---------------------------------------------------------------------72
    from compute_ecd_fluxes import compute_ecd_fluxes

    Jsol, delmu = compute_ecd_fluxes (C, EP, pt[0].area, pt[0].sig, pt[0].h, Jvol)
    
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  FLUXES ACROSS EXCHANGERS AND COTRANSPORTERS
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  Luminal Na/glucose cotransporters
# ---------------------------------------------------------------------72
# ---------------------------------------------------------------------72
#  Compute SGLT1 fluxes
# ---------------------------------------------------------------------72
#  Use kinetic description of SGLT1

    nagluparam[0] = C[0, 0]
    nagluparam[1] = C[0, 1]
    nagluparam[2] = C[14, 0]
    nagluparam[3] = C[14, 1]
    nagluparam[4] = EP[0]
    nagluparam[5] = EP[1]
    nagluparam[6] = pt[0].CTsglt1
    
    n = 1
    
    from sglt import sglt
    fluxsglt1 = sglt(n, nagluparam, pt[0].area[1-1,2-1])

    Jsol[0, 0, 1] += fluxsglt1[0] * pt[0].xSGLT1
    Jsol[14, 0, 1] += fluxsglt1[1] * pt[0].xSGLT1
    fluxnasglt1 = fluxsglt1[0] * pt[0].xSGLT1 * convert
    fluxglusglt1 = fluxsglt1[1] * pt[0].xSGLT1 * convert
    
#---------------------------------------------------------------------72
# Compute SGLT2 fluxes
#---------------------------------------------------------------------72
# NET formulation from Alan's 2007 PT model
#---------------------------------------------------------------------72
# dJNaglu1=SAreapt2(1,2)*dLApt(1,15,1,2)*(delmu(1,1,2)+delmu(15,1,2))

    zeta = F * EPref * (EP[0] - EP[1]) / RT
    affglu = 4.90
    affna = 25.0
    snal = C[0, 0] / affna
    snac = C[0, 1] / affna
    glul = C[14, 0] / affglu
    gluc = C[14, 1] / affglu
    
    denom = ((1.0 + snal + glul + snal * glul) * (1.0 + snac * gluc) +
              (1.0 + snac + gluc + snac * gluc) * (1.0 + snal * glul * np.exp(zeta)))
    dJNaglu = (pt[0].area[0, 1] * pt[0].dLA[0, 14, 0, 1] *
                (C[0, 0] * C[14, 0] * np.exp(zeta) - C[0, 1] * C[14, 1]) / denom)

    Jsol[0, 0, 1] += dJNaglu * pt[0].xSGLT2
    Jsol[14, 0, 1] += dJNaglu * pt[0].xSGLT2
    fluxnasglt2 = dJNaglu * pt[0].xSGLT2 * convert
    fluxglusglt2 = dJNaglu * pt[0].xSGLT2 * convert
    
# ---------------------------------------------------------------------72
# Basolateral glucose transporters
# ---------------------------------------------------------------------72

    Gi = C[14, 1]
    Go5 = C[14, 4]
    Go6 = C[14, 5]
    
# Compute GLUT1 fluxes
#---------------------------------------------------------------------72

    affglut1 = 2.0
    Ro5 = affglut1 * (Gi - Go5) / (affglut1 + Gi) / (affglut1 + Go5)
    fluxglut1PE = pt[0].CTglut1 * pt[0].area[1, 4] * Ro5
    Ro6 = affglut1 * (Gi - Go6) / (affglut1 + Gi) / (affglut1 + Go6)
    fluxglut1PS = pt[0].CTglut1 * pt[0].area[1, 5] * Ro6
    Jsol[14, 1, 4] += fluxglut1PE * pt[0].xGLUT1
    Jsol[14, 1, 5] += fluxglut1PS * pt[0].xGLUT1
    fluxglut1 = (fluxglut1PE + fluxglut1PS) * pt[0].xGLUT1 * convert

# Compute GLUT2 fluxes
#---------------------------------------------------------------------72

    affglut2 = 17.0
    Ro5 = affglut2 * (Gi - Go5) / (affglut2 + Gi) / (affglut2 + Go5)
    fluxglut2PE = pt[0].CTglut2 * pt[0].area[1, 4] * Ro5
    Ro6 = affglut2 * (Gi - Go6) / (affglut2 + Gi) / (affglut2 + Go6)
    fluxglut2PS = pt[0].CTglut2 * pt[0].area[1, 5] * Ro6
    Jsol[14, 1, 4] += fluxglut2PE * pt[0].xGLUT2
    Jsol[14, 1, 5] += fluxglut2PS * pt[0].xGLUT2
    fluxglut2 = (fluxglut2PE + fluxglut2PS) * pt[0].xGLUT2 * convert

#---------------------------------------------------------------------72
# Luminal NaH2PO4 cotransporter
#---------------------------------------------------------------------72

    dJNaP = pt[0].area[0, 1] * pt[0].dLA[0, 7, 0, 1] * (delmu[0, 0, 1] + delmu[7, 0, 1])

    fluxNaP = dJNaP * convert

# This Na-Pi cotransporter represents NaPiIIa: 3 Na+ with 1 HPO4^{2-}
    dJNaPiIIa = pt[0].area[0, 1] * xNaPiIIaPT * (3 * delmu[0, 0, 1] + delmu[6, 0, 1])
    Jsol[0, 0, 1] += 3.0 * dJNaPiIIa
    Jsol[6, 0, 1] += dJNaPiIIa
    fluxNaPiIIa = dJNaPiIIa * convert
    
# This Na-Pi cotransporter represents NaPiIIc: 2 Na+ with 1 HPO4^{2-}
# xSGLT2 is used owing to the non-homoegeneous distribution of NaPiII-c

    dJNaPiIIc = pt[0].area[0, 1] * xNaPiIIcPT * (2 * delmu[0, 0, 1] + delmu[6, 0, 1])
    dJNaPiIIc *= pt[0].xSGLT2
    Jsol[0, 0, 1] += 2.0 * dJNaPiIIc
    Jsol[6, 0, 1] += dJNaPiIIc
    fluxNaPiIIc = dJNaPiIIc * convert

# This Na-Pi cotransporter represents PiT-2: 2 Na+ with 1 H2PO4-
# xSGLT2 is used owing to the non-homoegeneous distribution of Pit-2

    dJPit2 = pt[0].area[0, 1] * xPit2PT * (2 * delmu[0, 0, 1] + delmu[7, 0, 1])
    dJPit2 *= pt[0].xSGLT2
    Jsol[0, 0, 1] += 2.0 * dJPit2
    Jsol[7, 0, 1] += dJPit2
    fluxPit2 = dJPit2 * convert
    
#---------------------------------------------------------------------72
# Luminal Cl/HCO3 exchanger
#---------------------------------------------------------------------72

    dJClBic = pt[0].area[0, 1] * pt[0].dLA[2, 3, 0, 1] * (delmu[2, 0, 1] - delmu[3, 0, 1])
    Jsol[2, 0, 1] += dJClBic
    Jsol[3, 0, 1] -= dJClBic
    fluxClBic = dJClBic * convert
    
#---------------------------------------------------------------------72
# Luminal Cl/HCO2 exchanger
#---------------------------------------------------------------------72
    
    dJClHco2 = pt[0].area[0, 1] * pt[0].dLA[2, 12, 0, 1] * (delmu[2, 0, 1] - delmu[12, 0, 1])
    Jsol[2, 0, 1] += dJClHco2
    Jsol[12, 0, 1] -= dJClHco2
    fluxClHco2 = dJClHco2 * convert
    
#---------------------------------------------------------------------72
# Luminal H-HCO2 cotransporter - ADDITION TO AMW MODEL
#---------------------------------------------------------------------72

    dJH_Hco2 = pt[0].area[0, 1] * pt[0].dLA[11, 12, 0, 1] * (delmu[11, 0, 1] + delmu[12, 0, 1])
    Jsol[11, 0, 1] += dJH_Hco2
    Jsol[12, 0, 1] += dJH_Hco2
    fluxH_Hco2 = dJH_Hco2 * convert
    
#---------------------------------------------------------------------72
# Basolateral KCl cotransporter
#---------------------------------------------------------------------72

    sumJES = 0.0
    for L in range(5, 6+1):
        dJKCl = pt[0].area[2-1, L-1] * pt[0].dLA[2-1, 3-1, 2-1, L-1] * (delmu[2-1, 2-1, L-1] + delmu[3-1, 2-1, L-1])
        Jsol[2-1, 2-1, L-1] += dJKCl
        Jsol[3-1, 2-1, L-1] += dJKCl
        sumJES += dJKCl
    fluxKCl = sumJES * convert
    
#---------------------------------------------------------------------72
# Basolateral Na(1)-HCO3(3) cotransporter
#---------------------------------------------------------------------72

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaBic = pt[0].area[1, L-1] * pt[0].dLA[0, 3, 1, L-1] * (delmu[0, 1, L-1] + 3 * delmu[3, 1, L-1])
        Jsol[0, 1, L-1] += dJNaBic
        Jsol[3, 1, L-1] += 3 * dJNaBic
        sumJES += dJNaBic
    fluxNaBic = sumJES * convert
    
#---------------------------------------------------------------------72
# Basolateral Na(1)-HCO3(2)/Cl(1) cotransporter (NDCBE)
#---------------------------------------------------------------------72

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNDCBE = pt[0].area[1, L-1] * pt[0].dLA[0, 2, 1, L-1] * (delmu[0, 1, L-1] - delmu[2, 1, L-1] + 2 * delmu[3, 1, L-1])
        Jsol[0, 1, L-1] += dJNDCBE
        Jsol[2, 1, L-1] -= dJNDCBE
        Jsol[3, 1, L-1] += 2 * dJNDCBE
        sumJES += dJNDCBE
    fluxNDCBE = sumJES * convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS EXCHANGERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# NHE3 EXCHANGER AT LUMINAL MEMBRANE OF CELL
# n is for Na, c is for Cl
# p (or prime) is for the luminal compartment (M)
# pp (or double prime) is for the cytosolic compartment (I)
#---------------------------------------------------------------------72
    from compute_nhe3_fluxes import compute_nhe3_fluxes
    dJNHEsod, dJNHEprot, dJNHEamm = compute_nhe3_fluxes (C, pt[0].area[1-1,2-1], pt[0].xNHE3)
    
# The rate constants are different for the PT. They need to be divided by
# 8000./792.

    dJNHEsod *= 792.0 / 8000.0
    dJNHEprot *= 792.0 / 8000.0
    dJNHEamm *= 792.0 / 8000.0
    Jsol[0, 0, 1] += dJNHEsod
    Jsol[11, 0, 1] += dJNHEprot
    Jsol[10, 0, 1] += dJNHEamm
    fluxNHEsod = dJNHEsod * convert
    fluxNHEprot = dJNHEprot * convert
    fluxNHEamm = dJNHEamm * convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ACTIVE TRANSPORT VIA ATPases
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Na-K-ATPase
#---------------------------------------------------------------------72

    AffNa = 0.2 * (1.0 + C[1, 1] / 8.33)
    actNa = C[0, 1] / (C[0, 1] + AffNa)

    AffK5 = 0.1 * (1.0 + C[0, 4] / 18.5)
    AffNH5 = AffK5
    actK5 = (C[1, 4] + C[10, 4]) / (C[1, 4] + C[10, 4] + AffK5)

    AffK6 = 0.1 * (1.0 + C[0, 5] / 18.5)
    AffNH6 = AffK6
    actK6 = (C[1, 5] + C[10, 5]) / (C[1, 5] + C[10, 5] + AffK6)

    ro5 = (C[10, 4] / AffNH5) / (C[1, 4] / AffK5)
    ro6 = (C[10, 5] / AffNH6) / (C[1, 5] / AffK6)

    dJactNa5 = pt[0].area[1, 4] * pt[0].ATPNaK[1, 4] * (actNa**3.0) * (actK5**2.0)
    dJactNa6 = pt[0].area[1, 5] * pt[0].ATPNaK[1, 5] * (actNa**3.0) * (actK6**2.0)

    dJactK5 = -2.0 / 3.0 * dJactNa5 / (1.0 + ro5)
    dJactK6 = -2.0 / 3.0 * dJactNa6 / (1.0 + ro6)

    Jsol[0, 1, 4] += dJactNa5
    Jsol[0, 1, 5] += dJactNa6

    Jsol[1, 1, 4] += dJactK5
    Jsol[1, 1, 5] += dJactK6

    Jsol[10, 1, 4] += dJactK5 * ro5
    Jsol[10, 1, 5] += dJactK6 * ro6

    fluxNaKsod = (dJactNa5 + dJactNa6) * convert
    fluxNaKpot = (dJactK5 + dJactK6) * convert
    fluxNaKamm = (dJactK5 * ro5 + dJactK6 * ro6) * convert
    
#---------------------------------------------------------------------72
# H-ATPase
# See Strieter & Weinstein paper for signs (AJP 263, 1992)
#---------------------------------------------------------------------72

    DactH = 1.0 + np.exp(steepATPH * (delmu[11, 0, 1] - dmuATPHPT))
    dJactH = -pt[0].area[0, 1] * pt[0].ATPH[0, 1] / DactH

    Jsol[11, 0, 1] += dJactH
    
    fluxHATPase = dJactH * convert
    
#---------------------------------------------------------------------72
# Putative basolateral PMCA pump
#---------------------------------------------------------------------72

    AffCa = 75.6e-6  # Tsukamoto et al., Biochim Biophys Acta 1992
    dJPMCA5 = pt[0].area[1, 4] * pt[0].PMCA * C[15, 1] / (C[15, 1] + AffCa)
    dJPMCA6 = pt[0].area[1, 5] * pt[0].PMCA * C[15, 1] / (C[15, 1] + AffCa)

    Jsol[15, 1, 4] += dJPMCA5
    Jsol[15, 1, 5] += dJPMCA6

    fluxPMCA = (dJPMCA5 + dJPMCA6) * convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#
# ADD TORQUE-MODULATED EFFECTS ON TRANSCELLULAR TRANSPORTER DENSITY
#
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Torque scaling parameter (Eq. 39 in 2007 PT model)
# Scale transcellular water and solute fluxes

    for I in range(1, NSPT + 1):
        Jsol[I-1, 0, 1] *= Scaletorq
        Jsol[I-1, 1, 4] *= Scaletorq
        Jsol[I-1, 1, 5] *= Scaletorq

    Jvol[0, 1] *= Scaletorq
    Jvol[1, 4] *= Scaletorq
    Jvol[1, 5] *= Scaletorq
    
#---------------------------------------------------------------------72
#
# STORE LOCAL FLUX VALUES FOR LATER INTEGRATION
#
#---------------------------------------------------------------------72

    cv = href * Cref * np.pi * pt[0].diam * 60 / 10 * 1.0e9  # for dimensional solute fluxes
    cvw = Pfref * Cref * Vwbar * np.pi * pt[0].diam * 60 / 10 * 1.0e6  # for dimensional water flux

    pt[0].FNatrans = Jsol[0, 0, 1] * cv  # FNatrans
    pt[0].FNapara = Jsol[0, 0, 4] * cv  # FNapara
    pt[0].FNaK = fluxNaKsod  # FNaK, already converted to pmol/min/mm
    pt[0].FHase = fluxHATPase  # FHase
    pt[0].FGluPara = Jsol[14, 0, 4] * cv
    pt[0].FGluSGLT1 = fluxglusglt1  
    pt[0].FGluSGLT2 = fluxglusglt2  

    pt[0].FKtrans = Jsol[1, 0, 1] * cv  # FNatrans
    pt[0].FKpara = Jsol[1, 0, 4] * cv  # FNapara

    fCaTransPT[LzPT + 1] = Jsol[15, 0, 1] * cv
    fCaParaPT[LzPT + 1] = Jsol[15, 0, 4] * cv

    nlocal = 1

    return Jvol, Jsol
