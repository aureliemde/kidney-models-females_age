# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** FLUXES ***************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# This subroutine computes the fluxes in the CCD

# INPUT ARGUMENTS:
# x: vector of 4*NS concentrations, 4 volumes, and 4 potentials
#
# OUTPUT ARGUMENTS:
# Jvol: volume fluxes
# Jsol: solute fluxes
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 


# Note:
# LzPT in "main" for "qnewton2PT" is equal to J - 1, in Fortran
# In python, LzPT is just equal to Lz
# It is LzPT+1 as Fortran version (No need for LzPT+1-1)
# Below def, LzPT = Lz

# Note:
cnt = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
from initC_Var import initC_Var
hENaC_CNT, hROMK_CNT, hCltj_CNT, xTRPV5_cnt, xPTRPV4_cnt = initC_Var(cnt)

# Note:
ccd = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
from initCCD_Var import initCCD_Var
hENaC_CCD, hROMK_CCD, hCltj_CCD = initCCD_Var(ccd)


def qflux2CCD(x, ccd, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    LzCCD = Lz # added in python code
    
    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))
    
    ONC = np.zeros(NC) 
    PRES = np.zeros(NC)
    
    C = np.zeros((NS,NC))
    dmu = np.zeros((NS,NC))
    ph = np.zeros(NC)
    Vol = np.zeros(NC)
    EP = np.zeros(NC)
    
    delmu = np.zeros((NS,NC,NC))
    
    hkconc = np.zeros(4)
    Amat = np.zeros((Natp,Natp))
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
# for HKATPase matrix inversion
    
    lwork = 10000  
    ipiv = np.zeros(Natp)
    work = np.zeros(lwork)
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ASSIGN CONCENTRATIONS, VOLUMES, AND POTENTIALS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for J in range(1, NS + 1):
        C[J-1, 6-1] = ccd[Lz+1].conc[J-1, 6-1]
    EP[6-1] = ccd[Lz+1].ep[6-1]

    for I in range(1, NS2 + 1):
        C[I-1, 1-1] = x[1 + 5 * (I-1) -1]
        C[I-1, 2-1] = x[2 + 5 * (I-1) -1]
        C[I-1, 3-1] = x[3 + 5 * (I-1) -1]
        C[I-1, 4-1] = x[4 + 5 * (I-1) -1]
        C[I-1, 5-1] = x[5 + 5 * (I-1) -1]
    
    for K in range(1, NC - 1 + 1):
        ph[K-1] = -np.log10(C[12-1, K-1] / 1.0e3)
        Vol[K-1] = x[K + 5*NS2 -1]  # where Vol(1) is the volume flux
        EP[K-1] = x[K + 5 + 5*NS2 -1]
        
    PM = x[11 + 5 * NS2 -1]  # Hydraulic pressure in lumen
              
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE THE NEW SURFACE AREAS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    ccd[Lz+1].area[5-1, 6-1] = ccd[Lz+1].sbasEinit * max( Vol[5-1] / ccd[Lz+1].volEinit, 1.0 )
    ccd[Lz+1].area[6-1, 5-1] = ccd[Lz+1].area[5-1, 6-1]
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIALIZE ALL FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    from compute_water_fluxes import compute_water_fluxes

    Jvol = compute_water_fluxes (C, PM, 0, Vol, ccd[Lz+1].volLuminit, 
                          ccd[Lz+1].volEinit, ccd[Lz+1].volPinit, CPimprefCCD,
                          ccd[Lz+1].volAinit, CAimprefCCD, ccd[Lz+1].volBinit, 
                          CBimprefCCD, ccd[Lz+1].area, ccd[Lz+1].sig, ccd[Lz+1].dLPV,
                          complCCD, PTinitVol)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOLUTE FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-dimensional solute fluxes are first converted to dimensional fluxes
# (in mmol/s/cm2 epith) by multiplying by href*Cref
# Then they are converted to units of pmol/min/mm tubule

    convert = href * Cref * np.pi * DiamCCD * 60 / 10 * 1.0e9  # Conversion factor
    eps = 1.0e-6  # For exponential (Peclet) terms
    
#---------------------------------------------------------------------72
# ELECTRO-CONVECTIVE-DIFFUSIVE FLUXES
#---------------------------------------------------------------------72
    
# dependence of ENaC, ROMK, and apical paracellular Cl permeability on pH

    facphMP = 1.0 * (0.1 + 2/ (1 + np.exp(-6.0 * (ph[2-1]-7.50))))
    facphTJ = 2.0 / (1.0 + np.exp(10.0 * (ph[5-1] - 7.32)))
    
    facNaMP = (30 / (30 + C[1-1, 1-1])) * (50 / (50 + C[1-1, 2-1]))

    ccd[Lz+1].h[1-1, 1-1, 2-1] = hENaC_CCD * facNaMP * facphMP
    
    ccd[Lz+1].h[2-1, 1-1, 2-1] = hROMK_CCD * facphMP
    
    ccd[Lz+1].h[3-1, 1-1, 5-1] = hCltj_CCD * facphTJ

# define electrochemical potential of each solute in each compartment
 
    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            dmu[I-1, K-1] = RT * np.log(np.abs(C[I-1, K-1])) + zval[I-1] * F * EPref * EP[K-1]

# begin flux calculation

    for I in range(1, NS + 1):
        for K in range(1, NC - 1 + 1):
            for L in range(K + 1, NC + 1):

# electrodiffusive component

                XI = zval[I-1] * F * EPref / RT * ( EP[K-1] - EP[L-1] )
                dint = np.exp(-XI)
                if ( np.abs(1.0 - dint) < eps ):
                    Jsol[I-1, K-1, L-1] = ccd[Lz+1].area[K-1, L-1] * ccd[Lz+1].h[I-1, K-1, L-1] * ( C[I-1, K-1] - C[I-1, L-1] )
                else:
                    Jsol[I-1, K-1, L-1] = ccd[Lz+1].area[K-1, L-1] * ccd[Lz+1].h[I-1, K-1, L-1] * XI * (C[I-1, K-1] - C[I-1, L-1] * dint) / (1.0-dint)

# convective component

                concdiff = C[I-1, K-1] - C[I-1, L-1]
                
                if (np.abs(concdiff) > eps):
                    concmean = (C[I-1, K-1] - C[I-1, L-1]) / np.log(np.abs(C[I-1, K-1] / C[I-1, L-1]))
                    dimless = (Pfref * Vwbar * Cref) / href
                    convect = (1.0 - ccd[Lz+1].sig[I-1, K-1, L-1]) * concmean * Jvol[K-1, L-1] * dimless
                    Jsol[I-1, K-1, L-1] += convect

# define driving force for coupled fluxes below

                delmu[I-1, K-1, L-1] = dmu[I-1, K-1] - dmu[I-1, L-1]  # for coupled flux calculations

# dimensional fluxes through channels, for print out

    fluxENaC = Jsol[1-1,1-1,2-1] * convert
    fluxROMK = Jsol[2-1,1-1,2-1] * convert
        
    fluxKchPES = (Jsol[2-1,2-1,5-1] + Jsol[2-1,2-1,6-1]) * convert
    fluxKchAES = (Jsol[2-1,3-1,5-1] + Jsol[2-1,3-1,6-1]) * convert
    fluxKchBES = (Jsol[2-1,4-1,5-1] + Jsol[2-1,4-1,6-1]) * convert
    fluxClchPES = (Jsol[3-1,2-1,5-1] + Jsol[3-1,2-1,6-1]) * convert
    fluxClchAES = (Jsol[3-1,3-1,5-1] + Jsol[3-1,3-1,6-1]) * convert
    fluxClchBES = (Jsol[3-1,4-1,5-1] + Jsol[3-1,4-1,6-1]) * convert
    fluxBichPES = (Jsol[4-1,2-1,5-1] + Jsol[4-1,2-1,6-1]) * convert
    fluxBichAES = (Jsol[4-1,3-1,5-1] + Jsol[4-1,3-1,6-1]) * convert
    fluxBichBES = (Jsol[4-1,4-1,5-1] + Jsol[4-1,4-1,6-1]) * convert
   
    fluxH2CO3MP = Jsol[5-1,1-1,2-1] * convert
    fluxH2CO3MA = Jsol[5-1,1-1,3-1] * convert
    fluxH2CO3MB = Jsol[5-1,1-1,4-1] * convert
    fluxCO2MP = Jsol[6-1,1-1,2-1] * convert
    fluxCO2MA = Jsol[6-1,1-1,3-1] * convert
    fluxCO2MB = Jsol[6-1,1-1,4-1] * convert
    
    fluxH2CO3PES = (Jsol[5-1,2-1,5-1] + Jsol[5-1,2-1,6-1]) * convert
    fluxH2CO3AES = (Jsol[5-1,3-1,5-1] + Jsol[5-1,3-1,6-1]) * convert
    fluxH2CO3BES = (Jsol[5-1,4-1,5-1] + Jsol[5-1,4-1,6-1]) * convert
    fluxCO2PES = (Jsol[6-1,2-1,5-1] + Jsol[6-1,2-1,6-1]) * convert
    fluxCO2AES = (Jsol[6-1,3-1,5-1] + Jsol[6-1,3-1,6-1]) * convert
    fluxCO2BES = (Jsol[6-1,4-1,5-1] + Jsol[6-1,4-1,6-1]) * convert
        
    fluxHP2mchPES = (Jsol[7-1,2-1,5-1] + Jsol[7-1,2-1,6-1]) * convert
    fluxHP2mchAES = (Jsol[7-1,3-1,5-1] + Jsol[7-1,3-1,6-1]) * convert
    fluxHP2mchBES = (Jsol[7-1,4-1,5-1] + Jsol[7-1,4-1,6-1]) * convert
    fluxHPmPES = (Jsol[8-1,2-1,5-1] + Jsol[8-1,2-1,6-1]) * convert
    fluxHPmAES = (Jsol[8-1,3-1,5-1] + Jsol[8-1,3-1,6-1]) * convert
    fluxHPmBES = (Jsol[8-1,4-1,5-1] + Jsol[8-1,4-1,6-1]) * convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS COTRANSPORTERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Na2HPO4 cotransporter at PE,PS,AE,AS,BE,BS interfaces
    
    for K in range(2, 4+1):
        sumJES = 0.0
        for L in range(5, 6+1):
            dJNaP = ccd[Lz+1].area[K-1, L-1] * ccd[Lz+1].dLA[1-1, 7-1, K-1, L-1] * (2*delmu[1-1, K-1, L-1] + delmu[7-1, K-1, L-1])
            Jsol[1-1, K-1, L-1] += 2*dJNaP
            Jsol[7-1, K-1, L-1] += dJNaP
            sumJES += 2*dJNaP
            
        if (K == 2): 
            fluxNaPatPES = sumJES * convert
            
        if (K == 3): 
            fluxNaPatAES = sumJES * convert
            
        if (K == 4): 
            fluxNaPatBES = sumJES * convert
            
# AE4 = NaHCO3 cotransporter at BE and BS interfaces
    sumJES = 0
    for L in range(5, 6+1):
        dJNaBic = ccd[Lz+1].area[4-1, L-1] * ccd[Lz+1].dLA[1-1, 4-1, 4-1, L-1] * (delmu[1-1, 4-1, L-1] + nstoch * delmu[4-1, 4-1, L-1])

        sumJES += dJNaBic

    fluxAE4BES = sumJES * convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS EXCHANGERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# NaH exchanger at PE,PS,AE,AS,BE,BS interfaces
# NHE1 model for principal cell

    for K in range(2, 4+1):
        sumJES = 0.0
        for L in range(5, 6+1):
            dJNaH = ccd[Lz+1].area[K-1, L-1] * ccd[Lz+1].dLA[1-1, 12-1, K-1, L-1] * (delmu[1-1, K-1, L-1] - delmu[12-1, K-1, L-1])
            Jsol[1-1, K-1, L-1] += dJNaH
            Jsol[12-1, K-1, L-1] -= dJNaH
            sumJES += dJNaH
            
        if (K == 2): 
            fluxNaHPES = sumJES * convert
            
        if (K == 3): 
            fluxNaHAES = sumJES * convert
            
        if (K == 4): 
            fluxNaHBES = sumJES * convert

# Cl/HCO3 exchanger at PE,PS interfaces

    sumJES = 0.0
    for L in range(5, 6+1):
        dJClHCO3 = ccd[Lz+1].area[2-1,L-1] * ccd[Lz+1].dLA[3-1,4-1,2-1,L-1] * ( delmu[3-1,2-1,L-1] - delmu[4-1,2-1,L-1] )           
        Jsol[3-1,2-1,L-1] += dJClHCO3
        Jsol[4-1,2-1,L-1] -= dJClHCO3
        sumJES += dJClHCO3
    fluxClHCO3exPES = sumJES*convert

# Cl/HCO3 exchanger at BE,BS interfaces - REMOVED

    sumJES = 0.0
    for L in range(5, 6+1):
        dJClHCO3 = ccd[Lz+1].area[4-1,L-1] * ccd[Lz+1].dLA[3-1,4-1,4-1,L-1] * ( delmu[3-1,4-1,L-1] - delmu[4-1,4-1,L-1] )           
        Jsol[3-1,4-1,L-1] += dJClHCO3
        Jsol[4-1,4-1,L-1] -= dJClHCO3
        sumJES += dJClHCO3
    fluxClHCO3exBES = sumJES*convert
    
#---------------------------------------------------------------------72
# NDBCE exchanger at MB interface
#---------------------------------------------------------------------72

# Assume a ping-pong model with equal translocation rates

    alpe = C[1-1, 1-1] / dKnaeBCE
    alpi = C[1-1, 4-1] / dKnaiBCE
    bete = C[4-1, 1-1] / dKbieBCE
    beti = C[4-1, 4-1] / dKbiiBCE
    game = C[3-1, 1-1] / dKcleBCE
    gami = C[3-1, 4-1] / dKcliBCE
    
    dele = 1.0 + alpe * (1.0 + bete + bete**2) + game
    deli = 1.0 + alpi * (1.0 + beti + beti**2) + gami
    etae = game + alpe * (bete**2)
    etai = gami + alpi * (beti**2)
    sigma = dele * etai + deli * etae
    
    xe = etai / sigma
    xi = etae / sigma
    dJNDBCE4 = ccd[Lz+1].xNDBCE * ccd[Lz+1].area[1-1, 4-1] * pBCE * (alpe * (bete**2) * xe-alpi * (beti**2) * xi)
    
    Jsol[1-1, 1-1, 4-1] +=  dJNDBCE4
    Jsol[3-1, 1-1, 4-1] -=  dJNDBCE4
    Jsol[4-1, 1-1, 4-1] +=  2*dJNDBCE4
    fluxNDBCEatMB = dJNDBCE4 * convert

#---------------------------------------------------------------------72
# Pendrin exchanger at the apical membrane of the beta cell
#---------------------------------------------------------------------72

# Old formulation
    
    dJClHCO3 = ccd[Lz+1].dLA[3-1, 4-1, 1-1, 4-1] * (delmu[3-1, 1-1, 4-1] - delmu[4-1, 1-1, 4-1])

    Pbiiclepd = Pbieclepd * Pcliclepd  # assuming internal = external affinity
    Pohiclepd = Poheclepd * Pcliclepd  # assuming internal = external affinity
    
    ohe = 1.0e-11 / C[12-1, 1-1] # H+ concentrations are in mM, OH- are in M
    ohi = 1.0e-11 / C[12-1, 4-1] # H+ concentrations in mM, OH- in M
    alpe = ohe / dKohpd
    alpi = ohi / dKohpd
    game = C[3-1, 1-1] / dKclpd
    gami = C[3-1, 4-1] / dKclpd
    bete = C[4-1, 1-1] / dKbipd
    beti = C[4-1, 4-1] / dKbipd
   
    dele = 1.0 + game + bete + alpe
    deli = 1.0 + gami + beti + alpi
    etae = (1.0 * game + Pbieclepd * bete + Poheclepd * alpe)
    etai = (Pcliclepd * gami + Pbiiclepd * beti + Pohiclepd * alpi)
    sigma = dele * etai + deli * etae

# Stimulation by low pHi
    if (ph[4-1] < 7.9):
        adj = np.exp((1 / 6.4189) * np.log((7.9 - ph[4-1]) / 0.0115))
    else:
        adj = 1.0

    factpd = ccd[Lz+1].area[1-1, 4-1] * ccd[Lz+1].xPendrin * Pclepd * adj
    
    dJclpd = factpd * (1.0 * game * etai - Pcliclepd * gami * etae) / sigma
    dJbipd = factpd * (Pbieclepd * bete * etai - Pbiiclepd * beti * etae) / sigma
    dJohpd = factpd * (Poheclepd * alpe * etai - Pohiclepd * alpi * etae) / sigma
    
    Jsol[3-1, 1-1, 4-1] += dJclpd
    Jsol[4-1, 1-1, 4-1] += dJbipd
    fluxPdMB = dJclpd * convert
    
#---------------------------------------------------------------------72
# AE1 EXCHANGER AT PERITUBULAR MEMBRANE OF ALPHA CELL
# b is for HCO3, c is for Cl
# p (or prime) is for the internal compartment (A, or 3)
# pp (or double prime) is for the external compartment (E/S)
#---------------------------------------------------------------------72
    
    bpp = C[4-1, 3-1]
    cpp = C[3-1, 3-1]
    betapp = bpp / dKbpp
    gampp = cpp / dKcpp
    
    sumJES = 0.0
    for K in range(5, 6 + 1):
        bp = C[4-1, K-1]
        cp = C[3-1, K-1]
        betap = bp / dKbp
        gamp = cp / dKcp
        xT = ccd[Lz+1].xAE1 / (1 + bpp / 172.0)
        sumum = (1 + betap + gamp) * (Pbpp * betapp + Pcpp * gampp)
        sumum = sumum + (1 + betapp + gampp) * (Pbp * betap + Pcp * gamp)
        
        befflux = ccd[Lz+1].area[3-1, K-1] * xT / sumum * (Pbpp * betapp * Pcp * gamp - Pbp * betap * Pcpp * gampp)
        Jsol[4-1, 3-1, K-1] += befflux
        Jsol[3-1, 3-1, K-1] -= befflux
        sumJES -= befflux

    fluxAE1 = sumJES * convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ACTIVE TRANSPORT VIA ATPases
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Na-K-ATPase
#---------------------------------------------------------------------

    for M in range(2, 4 + 1):  # For compartments P, A, B
        AffNa = 0.2 * (1.0 + C[2-1,M-1] / 8.33)
        actNa = C[1-1,M-1] / ( C[1-1,M-1] + AffNa )
        AffK = 0.1 * ( 1.0 + C[1-1,6-1] / 18.5 )
        AffNH4 = AffK / 0.20  # Per Alan's email
        actK5 = C[2-1,5-1] / ( C[2-1,5-1] + AffK )
        actK6 = C[2-1,6-1] / ( C[2-1,6-1] + AffK )
    
        dJact5 = ccd[Lz+1].area[M-1,5-1] * ccd[Lz+1].ATPNaK[M-1,5-1] * (actNa ** 3.0) * (actK5 ** 2.0)
        dJact6 = ccd[Lz+1].area[M-1,6-1] * ccd[Lz+1].ATPNaK[M-1,6-1] * (actNa ** 3.0) * (actK6 ** 2.0)
    
        ro5 = ( C[11-1,5-1] / AffNH4 ) / ( C[2-1,5-1] / AffK )
        ro6 = ( C[11-1,6-1] / AffNH4 ) / ( C[2-1,6-1] / AffK )

        Jsol[1-1, M-1, 5-1] += dJact5
        Jsol[1-1, M-1, 6-1] += dJact6
    
        Jsol[2-1, M-1, 5-1] -= 2.0/3.0*dJact5/(1+ro5)
        Jsol[2-1, M-1, 6-1] -= 2.0/3.0*dJact6/(1+ro6)
    
        Jsol[11-1, M-1, 5-1] -= 2.0/3.0*dJact5*ro5/(1+ro5)
        Jsol[11-1, M-1, 6-1] -= 2.0/3.0*dJact6*ro6/(1+ro6)
    
        if (M == 2): 
            fluxNaKasePES = (dJact5+dJact6)*convert
        if (M == 3): 
            fluxNaKaseAES = (dJact5+dJact6)*convert
        if (M == 4): 
            fluxNaKaseBES = (dJact5+dJact6)*convert
        
#---------------------------------------------------------------------72
# H-ATPase
# See Strieter & Weinstein paper for signs (AJP 263, 1992)
#---------------------------------------------------------------------72
    
    denom13 = 1.0 + np.exp(steepA * (dmu[12-1, 1-1] - dmu[12-1, 3-1] - dmuATPH))
    denom45 = 1.0 + np.exp(-steepB * (dmu[12-1, 4-1] - dmu[12-1, 5-1] - dmuATPH))
    denom46 = 1.0 + np.exp(-steepB * (dmu[12-1, 4-1] - dmu[12-1, 6-1] - dmuATPH))
    dJact13 = -ccd[Lz+1].area[1-1, 3-1] * ccd[Lz+1].ATPH[1-1, 3-1] / denom13
    dJact45 = ccd[Lz+1].area[4-1, 5-1] * ccd[Lz+1].ATPH[4-1, 5-1] / denom45
    dJact46 = ccd[Lz+1].area[4-1, 6-1] * ccd[Lz+1].ATPH[4-1, 6-1] / denom46
    
    Jsol[12-1, 1-1, 3-1] += dJact13
    Jsol[12-1, 4-1, 5-1] += dJact45
    Jsol[12-1, 4-1, 6-1] += dJact46
    
    fluxHATPaseMA = dJact13 * convert
    fluxHATPaseBES = (dJact45 + dJact46) * convert
    
#---------------------------------------------------------------------72
# H-K-ATPase at MP, MA and MB interfaces
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# H-K-ATPase at MP interface
#---------------------------------------------------------------------72
    
    hkconc[1-1] = C[2-1, 2-1]  # [K]in = K in P
    hkconc[2-1] = C[2-1, 1-1]  # [K]out = K in M
    hkconc[3-1] = C[12-1, 2-1]  # [H]in = H in P
    hkconc[4-1] = C[12-1, 1-1]  # [H]out = H in M
    
    from fatpase import fatpase

    Amat = fatpase(Natp,hkconc)
    
    Amat_org = Amat
    
# invert Jacobian matrix
    
    Amat_n = Amat_org
    
    if np.linalg.det(Amat_n) != 0:
        
        Amat_inv = np.linalg.inv(Amat_n)
        Amat = Amat_inv
    
# determine needed variables for calculating H efflux = K influx
# Need c(7) = H2-E1-P and c(8) = H2-E2-P

        c7 = Amat[7-1, 1-1]
        c8 = Amat[8-1, 1-1]
        dkf5 = 4.0e1
        dkb5 = 2.0e2
        hefflux = ccd[Lz+1].area[1-1, 2-1] * ccd[Lz+1].ATPHK[1-1, 2-1] * (dkf5 * c7 - dkb5 * c8)
        Jsol[2-1, 1-1, 2-1] += 2 * hefflux
        Jsol[12-1, 1-1, 2-1] -= 2 * hefflux
        fluxHKATPaseMP = 2 * hefflux * convert
    
#---------------------------------------------------------------------72
# H-K-ATPase at MA interface
#---------------------------------------------------------------------72
    
    hkconc[1-1] = C[2-1, 3-1]  # [K]in = K in A
    hkconc[2-1] = C[2-1, 1-1]  # [K]out = K in M
    hkconc[3-1] = C[12-1, 3-1]  # [H]in = H in A
    hkconc[4-1] = C[12-1, 1-1]  # [H]out = H in M
    
    from fatpase import fatpase

    Amat = fatpase(Natp,hkconc)
    
    Amat_org = Amat
    
# invert Jacobian matrix
    
    Amat_n = Amat_org
    
    if np.linalg.det(Amat_n) != 0:

        Amat_inv = np.linalg.inv(Amat_n)
        Amat = Amat_inv
    
        c7 = Amat[7-1, 1-1]
        c8 = Amat[8-1, 1-1]
        dkf5 = 4.0e1
        dkb5 = 2.0e2
        hefflux = ccd[Lz+1].area[1-1, 3-1] * ccd[Lz+1].ATPHK[1-1, 3-1] * (dkf5 * c7 - dkb5 * c8)
        Jsol[2-1, 1-1, 3-1] += 2*hefflux
        Jsol[12-1, 1-1, 3-1] -= 2*hefflux
        fluxHKATPaseMA = 2 * hefflux * convert
    
#---------------------------------------------------------------------72
# H-K-ATPase at MB interface
#---------------------------------------------------------------------72
    
    hkconc[1-1] = C[2-1, 4-1]  # [K]in = K in B
    hkconc[2-1] = C[2-1, 1-1]  # [K]out = K in M
    hkconc[3-1] = C[12-1, 4-1]  # [H]in = H in B
    hkconc[4-1] = C[12-1, 1-1]  # [H]out = H in M
    
    from fatpase import fatpase

    Amat = fatpase(Natp,hkconc)
    
    Amat_org = Amat
    
# invert Jacobian matrix
    
    Amat_n = Amat_org
    
    if np.linalg.det(Amat_n) != 0:

        Amat_inv = np.linalg.inv(Amat_n)
        Amat = Amat_inv
    
        c7 = Amat[7-1, 1-1]
        c8 = Amat[8-1, 1-1]
        dkf5 = 4.0e1
        dkb5 = 2.0e2
        hefflux = ccd[Lz+1].area[1-1, 4-1] * ccd[Lz+1].ATPHK[1-1, 4-1] * (dkf5 * c7 - dkb5 * c8)
        Jsol[2-1, 1-1, 4-1] += 2*hefflux
        Jsol[12-1, 1-1, 4-1] -= 2*hefflux
        fluxHKATPaseMB = 2 * hefflux * convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Print results
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    cv = href*Cref*np.pi*DiamCCD*60/10*1.0e9  # for dimensional solute fluxes
    cvw = Pfref*Cref*Vwbar*np.pi*DiamCCD*60/10*1.0e6  # for dimensional water flux

#---------------------------------------------------------------------72
#
# STORE LOCAL FLUX VALUES FOR LATER INTEGRATION
#
#---------------------------------------------------------------------

    ccd[Lz+1].FNatrans = (Jsol[1-1, 1-1, 2-1] + Jsol[1-1, 1-1, 3-1] + Jsol[1-1, 1-1, 4-1]) * cv * ccd[Lz+1].coalesce
    ccd[Lz+1].FNapara = Jsol[1-1, 1-1, 5-1] * cv * ccd[Lz+1].coalesce
    ccd[Lz+1].FNaK = (fluxNaKasePES + fluxNaKaseAES + fluxNaKaseBES) * ccd[Lz+1].coalesce
    
    ccd[Lz+1].FKtrans = (Jsol[2-1, 1-1, 2-1] + Jsol[2-1, 1-1, 3-1] + Jsol[2-1, 1-1, 4-1]) * cv * ccd[Lz+1].coalesce
    ccd[Lz+1].FKpara = Jsol[2-1, 1-1, 5-1] * cv * ccd[Lz+1].coalesce
    
    return Jvol, Jsol
