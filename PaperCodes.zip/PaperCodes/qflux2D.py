# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** FLUXES ***************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# This is a subroutine to compute the fluxes in the DCT

# INPUT ARGUMENTS:
# x: vector of 4*NS concentrations, 4 volumes, and 4 potentials
#
# OUTPUT ARGUMENTS:
# Jvol: volume fluxes
# Jsol: solute fluxes
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 


# Note:
# LzPT in "main" for "qnewton2PT" is equal to J - 1, in Fortran
# In python, LzPT is just equal to Lz
# It is LzPT+1 as Fortran version (No need for LzPT+1-1)
# Below def, LzPT = Lz

# Note:
dct = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
from initD_Var import initD_Var
xTRPV5_dct = initD_Var(dct)    
    
def qflux2D(x, Cext, EPext, dct, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    LzD = Lz # added in python code
    
    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))
    
    ONC = np.zeros(NC) 
    PRES = np.zeros(NC)
    
    C = np.zeros((NS,NC))
    dmu = np.zeros((NS,NC))
    ph = np.zeros(NC)
    Vol = np.zeros(NC)
    EP = np.zeros(NC)
    
    delmu = np.zeros((NS,NC,NC))
    
    hkconc = np.zeros(4)
    Amat = np.zeros((Natp,Natp))
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
# for HKATPase matrix inversion
    
    lwork = 10000  
    ipiv = np.zeros(Natp)
    work = np.zeros(lwork)
    
# for NCX fluxes
    var_ncx = np.zeros(16)
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ASSIGN CONCENTRATIONS, VOLUMES, AND POTENTIALS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for J in range(1, NS + 1):
        C[J-1, 6-1] = Cext[J-1]
    EP[6-1] = EPext

    for I in range(1, NS2 + 1):
        C[I-1, 1-1] = x[1 + 3 * (I-1) -1]
        C[I-1, 2-1] = x[2 + 3 * (I-1) -1]
        C[I-1, 5-1] = x[3 + 3 * (I-1) -1]

    Vol[0] = x[0 + 3 * NS2]
    Vol[1] = x[1 + 3 * NS2]
    Vol[4] = x[2 + 3 * NS2]
    EP[0] = x[3 + 3 * NS2]
    EP[1] = x[4 + 3 * NS2]
    EP[4] = x[5 + 3 * NS2]
    PM = x[6 + 3 * NS2]
    
# Assign dummy values to compartments 3 and 4

    for I in range(1, NS + 1):
        C[I-1, 3-1] = C[I-1, 2-1]
        C[I-1, 4-1] = C[I-1, 2-1]

    for K in range(1, NC + 1):
        ph[K-1] = -np.log10( C[12-1, K-1] / 1.0e3 )
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE THE NEW SURFACE AREAS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    dct[Lz+1].area[5-1, 6-1] = dct[Lz+1].sbasEinit * max( Vol[5-1] / dct[Lz+1].volEinit, 1.0 )
    dct[Lz+1].area[6-1, 5-1] = dct[Lz+1].area[5-1, 6-1]
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIALIZE ALL FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    from compute_water_fluxes import compute_water_fluxes

    Jvol = compute_water_fluxes (C, PM, 0, Vol, dct[Lz+1].volLuminit, 
                          dct[Lz+1].volEinit, dct[Lz+1].volPinit, CPimprefD,
                          dct[Lz+1].volAinit, CAimprefD, dct[Lz+1].volBinit, 
                          CBimprefD, dct[Lz+1].area, dct[Lz+1].sig, dct[Lz+1].dLPV,
                          complD, PTinitVol)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOLUTE FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-dimensional solute fluxes are first converted to dimensional fluxes
# (in mmol/s/cm2 epith) by multiplying by href*Cref
# Then they are converted to units of pmol/min/mm tubule

    convert = href * Cref * np.pi * DiamD * 60 / 10 * 1.0e9  # Conversion factor
    eps = 1.0e-6  # For exponential (Peclet) terms

#---------------------------------------------------------------------72
# PARTIAL OVERLAP OF NCC AND ENAC IN THE DCT2
# NO Calcium transporters in DCT1
#---------------------------------------------------------------------72

    xl = Lz + 1.0  # convert to real number
    xn = NZ  # convert to real number
    xdct2 = 2.0/3  # DCT1: first 2/3rds of length, DCT2 last 1/3rd
    
    if ((xl/xn) < xdct2):
        NCCexp = 1.0
        ENaCexp = 0.0
        CaTexp = 0.001
    else:
        NCCexp = ( 1.0 - (xl/xn - xdct2) / (1.0-xdct2) )
        ENaCexp = (xl/xn - xdct2)/(1.0-xdct2)
        CaTexp = 1.0

#---------------------------------------------------------------------72
# ELECTRO-CONVECTIVE-DIFFUSIVE FLUXES
#---------------------------------------------------------------------72
    
# define electrochemical potential of each solute in each compartment

    for I in range(1, NS + 1):
        for K in range(1, NC + 1):
            dmu[I-1,K-1] = RT * np.log( np.abs( C[I-1,K-1] ) ) + zval[I-1] * F * EPref * EP[K-1]

# begin flux calculation

    for I in range(1, NS2 + 1):
        for K in range(1, NC - 1 + 1):
            for L in range(K+1, NC + 1):
                
# electrodiffusive component
                XI = zval[I-1] * F * EPref / RT * (EP[K-1]-EP[L-1])
                dint = np.exp(-XI)
                if ( np.abs(1.0-dint) < eps ):
                    Jsol[I-1,K-1,L-1] = dct[Lz+1].area[K-1,L-1]*dct[Lz+1].h[I-1,K-1,L-1]*(C[I-1,K-1]-C[I-1,L-1])
                else:
                    Jsol[I-1,K-1,L-1] = dct[Lz+1].area[K-1,L-1]*dct[Lz+1].h[I-1,K-1,L-1]* XI *(C[I-1,K-1]-C[I-1,L-1]*dint)/(1.0-dint)

# convective component
                concdiff = C[I-1,K-1]-C[I-1,L-1]
                if (np.abs(concdiff) > eps):
                    concmean = (C[I-1,K-1]-C[I-1,L-1]) / np.log( np.abs( C[I-1,K-1]/C[I-1,L-1] ) )
                    dimless = (Pfref*Vwbar*Cref)/href
                    convect = (1.0-dct[Lz+1].sig[I-1,K-1,L-1])*concmean*Jvol[K-1,L-1]*dimless
                    Jsol[I-1,K-1,L-1] += convect

# define driving force for coupled fluxes below
                delmu[I-1,K-1,L-1] = dmu[I-1,K-1] - dmu[I-1,L-1]  # for coupled flux calculations

# dimensional fluxes through channels, for print out

    fluxNachMP = Jsol[1-1,1-1,2-1]*convert
    
    fluxKchMP = Jsol[2-1,1-1,2-1]*convert
    fluxKchPES = (Jsol[2-1,2-1,5-1]+Jsol[2-1,2-1,6-1])*convert
    
    fluxClchPES = (Jsol[3-1,2-1,5-1]+Jsol[3-1,2-1,6-1])*convert
    fluxBichPES = (Jsol[4-1,2-1,5-1]+Jsol[4-1,2-1,6-1])*convert
    
    fluxH2CO3MP = Jsol[5-1,1-1,2-1]*convert
    fluxCO2MP = Jsol[6-1,1-1,2-1]*convert
    
    fluxH2CO3PES = (Jsol[5-1,2-1,5-1]+Jsol[5-1,2-1,6-1])*convert
    fluxCO2PES = (Jsol[6-1,2-1,5-1]+Jsol[6-1,2-1,6-1])*convert
    
    fluxHP2mchPES = (Jsol[7-1,2-1,5-1]+Jsol[7-1,2-1,6-1])*convert
    fluxHPmPES = (Jsol[8-1,2-1,5-1]+Jsol[8-1,2-1,6-1])*convert
    
    Jsol[16-1,1-1,2-1] = CaTexp*Jsol[16-1,1-1,2-1]  # Ca2+ transport in DCT2 only
    Jsol[16-1,2-1,5-1] = CaTexp*Jsol[16-1,2-1,5-1]  # Ca2+ transport in DCT2 only
    Jsol[16-1,2-1,6-1] = CaTexp*Jsol[16-1,2-1,6-1]  # Ca2+ transport in DCT2 only

#---------------------------------------------------------------------72
# ENaC in DCT2 only
#---------------------------------------------------------------------72
# dependence of ENaC permeability to Na

    facNaMP = (30/(30 + C[1-1,1-1])) * (50/(50 + C[1-1,2-1]))
    facphMP = 1.0 * (0.1 + 2.0/ (1 + np.exp(-6.0*(ph[2-1]-7.50)) ))
    hENaC = ENaCexp * dct[Lz+1].hNaMP * facNaMP * facphMP  # ENaCexp is zero in early DCT
    
    XI = zval[1-1] * F * EPref / RT * (EP[1-1]-EP[2-1])
    dint = np.exp(-XI)
    if (np.abs(1.0 - dint) < eps):
        dJENaC = dct[Lz+1].area[1-1,2-1] * hENaC * (C[1-1,1-1]-C[1-1,2-1])
    else:
        dJENaC = dct[Lz+1].area[1-1,2-1] * hENaC * XI * (C[1-1,1-1]-C[1-1,2-1]*dint) / (1.0-dint)

    Jsol[1-1,1-1,2-1] += dJENaC
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS COTRANSPORTERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Basolateral Na2HPO4 cotransporter
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaP = dct[Lz+1].area[2-1, L-1] * dct[Lz+1].dLA[1-1, 7-1, 2-1, L-1] * (2*delmu[1-1, 2-1, L-1] + delmu[7-1, 2-1, L-1])
        Jsol[1-1, 2-1, L-1] += 2*dJNaP
        Jsol[7-1, 2-1, L-1] += dJNaP
        sumJES += 2*dJNaP
    fluxNaPatPES = sumJES * convert    

#---------------------------------------------------------------------72
# Apical and basolateral KCl cotransporter
#---------------------------------------------------------------------72

    dJKClMP = dct[Lz+1].area[1-1, 2-1] * dct[Lz+1].dLA[2-1, 3-1, 1-1, 2-1] * ( delmu[2-1, 1-1, 2-1] + delmu[3-1, 1-1, 2-1] )
    Jsol[2-1, 1-1, 2-1] += dJKClMP
    Jsol[3-1, 1-1, 2-1] += dJKClMP
    fluxKClMP = dJKClMP * convert
    
    sumJES = 0
    for L in range(5, 6+1):
        dJKCl = dct[Lz+1].area[2-1, L-1] * dct[Lz+1].dLA[2-1, 3-1, 2-1, L-1] * ( delmu[2-1, 2-1, L-1] + delmu[3-1, 2-1, L-1] )
        Jsol[2-1, 2-1, L-1] += dJKCl
        Jsol[3-1, 2-1, L-1] += dJKCl
        sumJES += dJKCl

    fluxKClPES = sumJES * convert

#---------------------------------------------------------------------72
# NCC cotransporter at the apical membrane of principal cells
#---------------------------------------------------------------------72
    alp = C[1-1, 1-1] / dKnncc
    alpp = C[1-1, 2-1] / dKnncc
    betp = C[3-1, 1-1] / dKcncc
    betpp = C[3-1, 2-1] / dKcncc
    
    gamp = C[1-1, 1-1] * C[3-1, 1-1] / (dKnncc * dKncncc)
    gampp = C[1-1, 2-1] * C[3-1, 2-1] / (dKnncc * dKncncc)
    
    rhop = 1 + alp + betp + gamp
    rhopp = 1 + alpp + betpp + gampp
    sigma = rhop * (poppncc + gampp * pnppncc) + rhopp * (popncc + gamp * pnpncc)
    dJNCC = NCCexp * dct[Lz+1].area[1-1, 2-1] * dct[Lz+1].xNCC * pnpncc * poppncc * (gamp-gampp) / sigma
    
    Jsol[1-1, 1-1, 2-1] += dJNCC
    Jsol[3-1, 1-1, 2-1] += dJNCC
    fluxNCC = dJNCC * convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS EXCHANGERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# NHE3 EXCHANGER AT LUMINAL MEMBRANE OF CELL
# n is for Na, c is for Cl
# p (or prime) is for the luminal compartment (M)
# pp (or double prime) is for the cytosolic compartment (I)
#---------------------------------------------------------------------

    from compute_nhe3_fluxes import compute_nhe3_fluxes
 
    dJNHEsod, dJNHEprot, dJNHEamm = compute_nhe3_fluxes (C, dct[Lz+1].area[1-1, 2-1], 
                               dct[Lz+1].xNHE3)
    
    Jsol[1-1, 1-1, 2-1] += dJNHEsod
    Jsol[12-1, 1-1, 2-1] += dJNHEprot
    Jsol[11-1, 1-1, 2-1] += dJNHEamm
    
    fluxNHEsod = dJNHEsod * convert
    fluxNHEprot = dJNHEprot * convert
    fluxNHEamm = dJNHEamm * convert

#---------------------------------------------------------------------72
# Basolateral NaH exchangers
#---------------------------------------------------------------------72

    for K in range(2, 2+1):

        sumJES = 0.0
        for L in range(5, 6+1):
            dJNaH = dct[Lz+1].area[K-1, L-1] * dct[Lz+1].dLA[1-1, 12-1, K-1, L-1] *(delmu[1-1, K-1, L-1] - delmu[12-1, K-1, L-1])

# ! NHE1 model for principal cell
# ! Model of Fuster et al (J Gen Physiol 2009)
            affnao = 34.0
            affnai = 102.0
            affho = 0.0183e-3
            affhi = 0.054e-3
            fnai = C[1-1, K-1]
            hi = C[12-1, K-1]
            fnao = C[1-1, L-1]
            ho = C[12-1, L-1]
            Fno = (fnao/affnao) / (1.0 + fnao/affnao + ho/affho)
            Fni = (fnai/affnai) / (1.0 + fnai/affnai + hi/affhi)
            Fho = (ho/affho) / (1.0 + fnao/affnao + ho/affho)
            Fhi = (hi/affhi) / (1.0 + fnai/affnai + hi/affhi)
            E2mod1 = (Fni+Fhi) / (Fni+Fhi+Fno+Fho)
            E1mod1 = 1.0 - E2mod1
            E2mod2 = (Fni**2 + Fhi**2) / (Fni**2 + Fhi**2 + Fno**2 + Fho**2)
            E1mod2 = 1.0 - E2mod2
            Fmod1 = (hi**2) / ( hi**2 + (0.3e-3)**2 )
            Rnhe = 1.0e3 * (1.0 * (1.0 - Fmod1) * (E2mod2 * (Fno**2) - E1mod2 * (Fni**2)) + Fmod1 * (E2mod1 * Fno - E1mod1 * Fni))
            
            Jsol[1-1,K-1,L-1] += dJNaH
            Jsol[12-1,K-1,L-1] -= dJNaH
            sumJES += dJNaH

        fluxNaHPES = sumJES * convert

#---------------------------------------------------------------------72
# Cl/HCO3 exchanger at PE,PS interfaces
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJClHCO3 = dct[Lz+1].area[2-1,L-1] * dct[Lz+1].dLA[3-1,4-1,2-1,L-1] * ( delmu[3-1,2-1,L-1] - delmu[4-1,2-1,L-1] )           
        Jsol[3-1,2-1,L-1] += dJClHCO3
        Jsol[4-1,2-1,L-1] -= dJClHCO3
        sumJES += dJClHCO3
    fluxClHCO3exPES = sumJES*convert

#---------------------------------------------------------------------72
# NCX EXCHANGER AT BASOLATERAL MEMBRANE OF CELL
#---------------------------------------------------------------------72
    var_ncx[1-1] = C[1-1, 2-1]
    var_ncx[2-1] = C[1-1, 5-1]
    var_ncx[3-1] = C[1-1, 6-1]
    var_ncx[4-1] = C[16-1, 2-1]
    var_ncx[5-1] = C[16-1, 5-1]
    var_ncx[6-1] = C[16-1, 6-1]
    var_ncx[7-1] = EP[2-1]
    var_ncx[8-1] = EP[5-1]
    var_ncx[9-1] = EP[6-1]
    var_ncx[10-1] = dct[Lz+1].area[2-1, 5-1]
    var_ncx[11-1] = dct[Lz+1].area[2-1, 6-1]
    var_ncx[12-1] = dct[Lz+1].xNCX

    from compute_ncx_fluxes import compute_ncx_fluxes
    
    dJNCXca5,dJNCXca6 = compute_ncx_fluxes(var_ncx)
    
    dJNCXca5 = CaTexp*dJNCXca5
    dJNCXca6 = CaTexp*dJNCXca6
    
    Jsol[1-1, 2-1, 5-1] -= 3.0*dJNCXca5
    Jsol[1-1, 2-1, 6-1] -= 3.0*dJNCXca6
    Jsol[16-1, 2-1, 5-1] += dJNCXca5
    Jsol[16-1, 2-1, 6-1] += dJNCXca6
    fluxNCXca = (dJNCXca5 + dJNCXca6) * convert

#---------------------------------------------------------------------72
# Ca2+ flux across TRPV5
#---------------------------------------------------------------------72
    k1v5 = 42.7
    k3v5 = 0.1684 * np.exp(0.6035*ph[2-1])
    k4v5 = 58.7
    
    if (ph[2-1] < 7.4):
        k2v5 = 55.9 + (173.3 - 55.9) / (7.0 - 7.4) * (ph[2-1] - 7.4)
    else:
        k2v5 = 55.9 + (30.4 - 55.9) / (8.4 - 7.4) * (ph[2-1] - 7.4)

    psv5 = 1.0 / (1.0 + k3v5/k4v5 + k2v5/k1v5)
    pcv5 = k2v5 / k1v5 * psv5
    pfv5 = k3v5 / k4v5 * psv5
    
    gfv5 = 59 + 59 / (59 + 29.0) * (91.0 - 58.0) / (7.4 - 5.4) * (ph[1-1] - 7.4)
    gsv5 = 29 + 29 / (59 + 29.0) * (91.0 - 58.0) / (7.4 - 5.4) * (ph[1-1] - 7.4)
    gv5 = (gfv5 * pfv5 + gsv5 * psv5) * 1.0e-12
    
    ECa = RT / (2*F) * np.log( C[16-1,2-1]/C[16-1,1-1] )  # in volts (RT/F in J/C)
    dfv5 = (EP[1-1] - EP[2-1]) * EPref - ECa
    finhib_v5 = 1.0 / (1.0 + C[16-1,2-1]/Cinhib_v5)
    
    dJTRPV5 = CaTexp * dct[Lz+1].area[1-1, 2-1] * xTRPV5_dct * finhib_v5 * gv5 * dfv5 / (2*F)
    
    Jsol[16-1, 1-1, 2-1] += dJTRPV5
    
    fluxTRPV5 = dJTRPV5 * convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ACTIVE TRANSPORT VIA ATPases
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Na-K-ATPase
#---------------------------------------------------------------------

    AffNa = 0.2 * (1.0 + C[2-1,2-1] / 8.33)
    actNa = C[1-1,2-1] / ( C[1-1,2-1] + AffNa )
    AffK = 0.1 * ( 1.0 + C[1-1,6-1] / 18.5 )
    AffNH4 = AffK
    actK5 = C[2-1,5-1] / ( C[2-1,5-1] + AffK )
    actK6 = C[2-1,6-1] / ( C[2-1,6-1] + AffK )
    
    dJact5 = dct[Lz+1].area[2-1,5-1] * dct[Lz+1].ATPNaK[2-1,5-1] * (actNa ** 3.0) * (actK5 ** 2.0)
    dJact6 = dct[Lz+1].area[2-1,6-1] * dct[Lz+1].ATPNaK[2-1,6-1] * (actNa ** 3.0) * (actK6 ** 2.0)
    
    ro5 = ( C[11-1,5-1] / AffNH4 ) / ( C[2-1,5-1] / AffK )
    ro6 = ( C[11-1,6-1] / AffNH4 ) / ( C[2-1,6-1] / AffK )

    Jsol[1-1, 2-1, 5-1] += dJact5
    Jsol[1-1, 2-1, 6-1] += dJact6
    
    Jsol[2-1, 2-1, 5-1] -= 2.0/3.0*dJact5/(1+ro5)
    Jsol[2-1, 2-1, 6-1] -= 2.0/3.0*dJact6/(1+ro6)
    
    Jsol[11-1, 2-1, 5-1] -= 2.0/3.0*dJact5*ro5/(1+ro5)
    Jsol[11-1, 2-1, 6-1] -= 2.0/3.0*dJact6*ro6/(1+ro6)
    
    fluxNaKPESsod = (dJact5 + dJact6) * convert
    
    fluxNaKPESpot = -2/3.0*(dJact5/(1+ro5)+dJact6/(1+ro6))*convert
    fluxNaKPESamm = -2/3.0*(dJact5*ro5/(1+ro5)+dJact6*ro6/(1+ro6))*convert

#---------------------------------------------------------------------72
# PMCA Ca2+ PUMP AT BASOLATERAL MEMBRANE OF CELL
#---------------------------------------------------------------------72
    ratio = C[16-1,2-1] / ( C[16-1,2-1] + dKmPMCA )
    dJPMCA5 = CaTexp * dct[Lz+1].PMCA * dct[Lz+1].area[2-1,5-1] * ratio
    dJPMCA6 = CaTexp * dct[Lz+1].PMCA * dct[Lz+1].area[2-1,6-1] * ratio
    
    Jsol[16-1,2-1,5-1] += dJPMCA5
    Jsol[16-1,2-1,6-1] += dJPMCA6
    
    fluxPMCA = (dJPMCA5 + dJPMCA6) * convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Print results
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    cv = href*Cref*np.pi*DiamD*60/10*1.0e9  # for dimensional solute fluxes
    cvw = Pfref*Cref*Vwbar*np.pi*DiamD*60/10*1.0e6  # for dimensional water flux

    for I in range(1, 3+1):
        apfluxnet = Jsol[I-1,1-1,2-1] + Jsol[I-1,1-1,3-1] + Jsol[I-1,1-1,4-1] + Jsol[I-1,1-1,5-1]
        basfluxnet = Jsol[I-1,2-1,6-1] + Jsol[I-1,3-1,6-1] + Jsol[I-1,4-1,6-1] + Jsol[I-1,5-1,6-1]
        fluxlatnet = Jsol[I-1,1-1,5-1] + Jsol[I-1,2-1,5-1] + Jsol[I-1,3-1,5-1] + Jsol[I-1,4-1,5-1] - Jsol[I-1,5-1,6-1]
        
#---------------------------------------------------------------------72
#
# STORE LOCAL FLUX VALUES FOR LATER INTEGRATION
#
#---------------------------------------------------------------------

    dct[Lz+1].FNatrans = Jsol[1-1, 1-1, 2-1]*cv
    dct[Lz+1].FNapara = Jsol[1-1, 1-1, 5-1]*cv
    dct[Lz+1].FNaK = fluxNaKPESsod
    dct[Lz+1].FHase = 0.0
    
    dct[Lz+1].FKtrans = Jsol[2-1, 1-1, 2-1]*cv
    dct[Lz+1].FKpara = Jsol[2-1, 1-1, 5-1]*cv
    
    fTRPV5_dct[Lz +1 -1] = fluxTRPV5
    fNCX_dct[Lz +1 -1] = fluxNCXca
    fPMCA_dct[Lz +1 -1] = fluxPMCA

    return Jvol, Jsol
