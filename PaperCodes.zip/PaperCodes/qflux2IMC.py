# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** FLUXES ***************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# This is a subroutine to compute the fluxes in the IMCD

# INPUT ARGUMENTS:
# x: vector of 4*NS concentrations, 4 volumes, and 4 potentials
#
# OUTPUT ARGUMENTS:
# Jvol: volume fluxes
# Jsol: solute fluxes
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 


# Note:
# LzPT in "main" for "qnewton2PT" is equal to J - 1, in Fortran
# In python, LzPT is just equal to Lz
# It is LzPT+1 as Fortran version (No need for LzPT+1-1)
# Below def, LzPT = Lz

# Note:
imcd = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
from initIMC_Var import initIMC_Var
hENaC_IMC, hROMK_IMC, hCltj_IMC = initIMC_Var (imcd)


def qflux2IMC(x, Cext, EPext, imcd, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    LzIMC = Lz # added in python code
    
    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))
    
    ONC = np.zeros(NC) 
    PRES = np.zeros(NC)
    
    C = np.zeros((NS,NC))
    dmu = np.zeros((NS,NC))
    ph = np.zeros(NC)
    Vol = np.zeros(NC)
    EP = np.zeros(NC)
    
    delmu = np.zeros((NS,NC,NC))
    
    hkconc = np.zeros(4)
    Amat = np.zeros((Natp,Natp))
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
# for HKATPase matrix inversion
    
    lwork = 10000  
    ipiv = np.zeros(Natp)
    work = np.zeros(lwork)
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ASSIGN CONCENTRATIONS, VOLUMES, AND POTENTIALS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for J in range(1, NS + 1):
        C[J-1, 6-1] = Cext[J-1]
    EP[6-1] = EPext

    for I in range(1, NS2 + 1):
        C[I-1, 1-1] = x[1 + 3 * (I-1) -1]
        C[I-1, 2-1] = x[2 + 3 * (I-1) -1]
        C[I-1, 5-1] = x[3 + 3 * (I-1) -1]

    Vol[0] = x[0 + 3 * NS2]
    Vol[1] = x[1 + 3 * NS2]
    Vol[4] = x[2 + 3 * NS2]
    EP[0] = x[3 + 3 * NS2]
    EP[1] = x[4 + 3 * NS2]
    EP[4] = x[5 + 3 * NS2]
    PM = x[6 + 3 * NS2]
    
# Assign dummy values to compartments 3 and 4

    for I in range(1, NS + 1):
        C[I-1, 3-1] = C[I-1, 2-1]
        C[I-1, 4-1] = C[I-1, 2-1]

    for K in range(1, NC + 1):
        ph[K-1] = -np.log10( C[12-1, K-1] / 1.0e3 )
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE THE NEW SURFACE AREAS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    imcd[Lz+1].area[5-1, 6-1] = imcd[Lz+1].sbasEinit * max( Vol[5-1] / imcd[Lz+1].volEinit, 1.0 )
    imcd[Lz+1].area[6-1, 5-1] = imcd[Lz+1].area[5-1, 6-1]
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIALIZE ALL FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    from compute_water_fluxes import compute_water_fluxes

    Jvol = compute_water_fluxes (C, PM, 0, Vol, imcd[Lz+1].volLuminit, 
                          imcd[Lz+1].volEinit, imcd[Lz+1].volPinit, CPimprefIMC,
                          imcd[Lz+1].volAinit, CAimprefIMC, imcd[Lz+1].volBinit, 
                          CBimprefIMC, imcd[Lz+1].area, imcd[Lz+1].sig, imcd[Lz+1].dLPV,
                          complIMC, PTinitVol)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOLUTE FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-dimensional solute fluxes are first converted to dimensional fluxes
# (in mmol/s/cm2 epith) by multiplying by href*Cref
# Then they are converted to units of pmol/min/mm tubule

    convert = href * Cref * np.pi * DiamIMC * 60 / 10 * 1.0e9  # Conversion factor

#---------------------------------------------------------------------72
# ELECTRO-CONVECTIVE-DIFFUSIVE FLUXES
#---------------------------------------------------------------------72
    
# dependence of ENaC, ROMK, and apical paracellular Cl permeability on pH

    facphMP = 1.0 * (0.1 + 2.0/(1+np.exp(-6.0*(ph[2-1]-7.50))))
    facphTJ = 2.0/(1.0 + np.exp(10.0*(ph[5-1]-7.32)))
    
    facNaMP = (30 / (30 + C[1-1,1-1])) * (50 / (50 + C[1-1,2-1]))

    imcd[Lz+1].h[1-1, 1-1, 2-1] = hENaC_IMC * facNaMP * facphMP
    
    imcd[Lz+1].h[2-1, 1-1, 2-1] = hROMK_IMC * facphMP
    
    imcd[Lz+1].h[3-1, 1-1, 5-1] = hCltj_IMC * facphTJ


    from compute_ecd_fluxes import compute_ecd_fluxes

    Jsol, delmu = compute_ecd_fluxes (C, EP, imcd[Lz+1].area, imcd[Lz+1].sig, imcd[Lz+1].h, Jvol)

# dimensional fluxes through channels, for print out
    
    fluxNachMP = Jsol[1-1, 1-1, 2-1] * convert
    fluxNachPES = (Jsol[1-1, 2-1, 5-1] + Jsol[1-1, 2-1, 6-1]) * convert
    
    fluxKchMP = Jsol[2-1, 1-1, 2-1] * convert
    fluxKchPES = (Jsol[2-1, 2-1, 5-1] + Jsol[2-1, 2-1, 6-1]) * convert
    
    fluxClchMP = Jsol[3-1, 1-1, 2-1] * convert
    fluxClchPES = (Jsol[3-1, 2-1, 5-1] + Jsol[3-1, 2-1, 6-1]) * convert
    fluxBichPES = (Jsol[4-1, 2-1, 5-1] + Jsol[4-1, 2-1, 6-1]) * convert
    
    fluxH2CO3MP = Jsol[5-1, 1-1, 2-1] * convert
    fluxCO2MP = Jsol[6-1, 1-1, 2-1] * convert
    
    fluxH2CO3PES = (Jsol[5-1, 2-1, 5-1] + Jsol[5-1, 2-1, 6-1]) * convert
    fluxCO2PES = (Jsol[6-1, 2-1, 5-1] + Jsol[6-1, 2-1, 6-1]) * convert
    
    fluxHP2mchPES = (Jsol[7-1, 2-1, 5-1] + Jsol[7-1, 2-1, 6-1]) * convert
    fluxHPmPES = (Jsol[8-1, 2-1, 5-1] + Jsol[8-1, 2-1, 6-1]) * convert
    
    fluxNH3MP = Jsol[10-1, 1-1, 2-1] * convert
    fluxNH3PES = (Jsol[10-1, 2-1, 5-1] + Jsol[10-1, 2-1, 6-1]) * convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS COTRANSPORTERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

#---------------------------------------------------------------------72
# Apical NaCl cotransporter
#---------------------------------------------------------------------

    dJNaCl = imcd[Lz+1].area[1-1, 2-1] * imcd[Lz+1].dLA[1-1, 3-1, 1-1, 2-1] * (delmu[1-1, 1-1, 2-1] + delmu[3-1, 1-1, 2-1])
    Jsol[1-1, 1-1, 2-1] = Jsol[1-1, 1-1, 2-1] + dJNaCl
    Jsol[3-1, 1-1, 2-1] = Jsol[3-1, 1-1, 2-1] + dJNaCl
    fluxNaClMP = dJNaCl * convert

#---------------------------------------------------------------------72
# Basolateral Na2HPO4 cotransporter
#---------------------------------------------------------------------

# Factor 1/2 to be consistent with AMW model results

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaP = imcd[Lz+1].area[2-1, L-1] * imcd[Lz+1].dLA[1-1, 7-1, 2-1, L-1] / 2 * (2*delmu[1-1, 2-1, L-1] + delmu[7-1, 2-1, L-1])
        Jsol[1-1, 2-1, L-1] += 2*dJNaP
        Jsol[7-1, 2-1, L-1] += dJNaP
        sumJES += 2*dJNaP
    fluxNaPatPES = sumJES * convert    

#---------------------------------------------------------------------72
# Basolateral KCl cotransporter
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJKCl = imcd[Lz+1].area[2-1, L-1] * imcd[Lz+1].dLA[2-1, 3-1, 2-1, L-1] * (delmu[2-1, 2-1, L-1] + delmu[3-1, 2-1, L-1])
        Jsol[2-1, 2-1, L-1] += dJKCl
        Jsol[3-1, 2-1, L-1] += dJKCl
        sumJES += dJKCl
    fluxKClPES = sumJES * convert    
    
#---------------------------------------------------------------------72
# Basolateral NKCl2 cotransporter
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNKCl2 = imcd[Lz+1].area[2-1, L-1] * imcd[Lz+1].dLA[1-1, 2-1, 2-1, L-1] * (delmu[1-1, 2-1, L-1] + delmu[2-1, 2-1, L-1] + 2 * delmu[3-1, 2-1, L-1])
        Jsol[1-1, 2-1, L-1] += dJNKCl2
        Jsol[2-1, 2-1, L-1] += dJNKCl2
        Jsol[3-1, 2-1, L-1] += 2 * dJNKCl2
        sumJES += dJNKCl2
    fluxNKCl2PES = sumJES * convert    

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS EXCHANGERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

#---------------------------------------------------------------------72
# Basolateral NaH exchangers
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaH = imcd[Lz+1].area[2-1, L-1] * imcd[Lz+1].dLA[1-1, 12-1, 2-1, L-1] * (delmu[1-1, 2-1, L-1] - delmu[12-1, 2-1, L-1])
        Jsol[1-1, 2-1, L-1] += dJNaH
        Jsol[12-1, 2-1, L-1] -= dJNaH
        sumJES += dJNaH
    fluxNaHPES = sumJES * convert    

#---------------------------------------------------------------------72
# Cl/HCO3 exchanger at PE,PS interfaces
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJClHCO3 = imcd[Lz+1].area[2-1,L-1] * imcd[Lz+1].dLA[3-1,4-1,2-1,L-1] * ( delmu[3-1,2-1,L-1] - delmu[4-1,2-1,L-1] )           
        Jsol[3-1,2-1,L-1] += dJClHCO3
        Jsol[4-1,2-1,L-1] -= dJClHCO3
        sumJES += dJClHCO3
    fluxClHCO3exPES = sumJES*convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ACTIVE TRANSPORT VIA ATPases
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Basolateral Na-K-ATPase
#---------------------------------------------------------------------

    AffNa = 0.2 * (1.0 + C[2-1,2-1] / 8.33)
    actNa = C[1-1,2-1] / ( C[1-1,2-1] + AffNa )
    AffK = 0.1 * ( 1.0 + C[1-1,6-1] / 18.5 )
    AffNH4 = 5.0 * AffK
    actK5 = C[2-1,5-1] / ( C[2-1,5-1] + AffK )
    actK6 = C[2-1,6-1] / ( C[2-1,6-1] + AffK )
    
    dJact5 = imcd[Lz+1].area[2-1,5-1] * imcd[Lz+1].ATPNaK[2-1,5-1] * (actNa ** 3.0) * (actK5 ** 2.0)
    dJact6 = imcd[Lz+1].area[2-1,6-1] * imcd[Lz+1].ATPNaK[2-1,6-1] * (actNa ** 3.0) * (actK6 ** 2.0)
    
    ro5 = ( C[11-1,5-1] / AffNH4 ) / ( C[2-1,5-1] / AffK )
    ro6 = ( C[11-1,6-1] / AffNH4 ) / ( C[2-1,6-1] / AffK )

    Jsol[1-1, 2-1, 5-1] += dJact5
    Jsol[1-1, 2-1, 6-1] += dJact6
    
    Jsol[2-1, 2-1, 5-1] -= 2.0/3.0*dJact5/(1+ro5)
    Jsol[2-1, 2-1, 6-1] -= 2.0/3.0*dJact6/(1+ro6)
    
    Jsol[11-1, 2-1, 5-1] -= 2.0/3.0*dJact5*ro5/(1+ro5)
    Jsol[11-1, 2-1, 6-1] -= 2.0/3.0*dJact6*ro6/(1+ro6)
    
    fluxNaKPESsod = (dJact5 + dJact6) * convert
    
    fluxNaKPESpot = -2/3.0*(dJact5/(1+ro5)+dJact6/(1+ro6))*convert
    fluxNaKPESamm = -2/3.0*(dJact5*ro5/(1+ro5)+dJact6*ro6/(1+ro6))*convert

#---------------------------------------------------------------------72
# Luminal H-K-ATPase
#---------------------------------------------------------------------72
    
    hkconc[1-1] = C[2-1, 2-1]  # [K]in = K in P
    hkconc[2-1] = C[2-1, 1-1]  # [K]out = K in M
    hkconc[3-1] = C[12-1, 2-1]  # [H]in = H in P
    hkconc[4-1] = C[12-1, 1-1]  # [H]out = H in M
    
    
    from fatpase import fatpase
    
    Amat = fatpase(Natp,hkconc)
    
    Amat_org = Amat
    
# invert Jacobian matrix
    
    Amat_n = Amat_org
    Amat_inv = np.linalg.inv(Amat_n)
    Amat = Amat_inv
    
# determine needed variables for calculating H efflux = K influx
# Need c(7) = H2-E1-P and c(8) = H2-E2-P
    
    c7 = Amat[7-1, 1-1]
    c8 = Amat[8-1, 1-1]
    dkf5 = 4.0e1
    dkb5 = 2.0e2
    hefflux = imcd[Lz+1].area[1-1, 2-1] * imcd[Lz+1].ATPHK[1-1, 2-1] * (dkf5 * c7 - dkb5 * c8)
    Jsol[2-1, 1-1, 2-1] += hefflux
    Jsol[12-1, 1-1, 2-1] -= hefflux
    fluxHKATPaseMP = hefflux * convert
# No factor 2 to be consistent with AMW model results

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Print results
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    cv = href*Cref*np.pi*DiamIMC*60/10*1.0e9  # for dimensional solute fluxes
    cvw = Pfref*Cref*Vwbar*np.pi*DiamIMC*60/10*1.0e6  # for dimensional water flux

#---------------------------------------------------------------------72
#
# STORE LOCAL FLUX VALUES FOR LATER INTEGRATION
#
#---------------------------------------------------------------------

    imcd[Lz+1].FNatrans = Jsol[1-1, 1-1, 2-1] * cv * imcd[Lz+1].coalesce
    imcd[Lz+1].FNapara = Jsol[1-1, 1-1, 5-1] * cv * imcd[Lz+1].coalesce
    imcd[Lz+1].FNaK = fluxNaKPESsod * cv * imcd[Lz+1].coalesce
    imcd[Lz+1].FHase = 0
    
    imcd[Lz+1].FKtrans = Jsol[2-1, 1-1, 2-1] * cv * imcd[Lz+1].coalesce
    imcd[Lz+1].FKpara = Jsol[2-1, 1-1, 5-1] * cv * imcd[Lz+1].coalesce

    return Jvol, Jsol
