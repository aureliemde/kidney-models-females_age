# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** FLUXES ***************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# This is a subroutine to compute the fluxes in the OMCD

# INPUT ARGUMENTS:
# x: vector of 4*NS concentrations, 4 volumes, and 4 potentials
#
# OUTPUT ARGUMENTS:
# Jvol: volume fluxes
# Jsol: solute fluxes
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 


# Note:
# LzPT in "main" for "qnewton2PT" is equal to J - 1, in Fortran
# In python, LzPT is just equal to Lz
# It is LzPT+1 as Fortran version (No need for LzPT+1-1)
# Below def, LzPT = Lz
  
# Note:
omcd = [Membrane(NSPT, NC, NS) for _ in range(NZ + 1)]
from initOMC_Var import initOMC_Var
hENaC_OMC, hROMK_OMC, hCltj_OMC = initOMC_Var (omcd)


def qflux2OMC(x, omcd, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    LzOMC = Lz # added in python code
    
    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))
    
    ONC = np.zeros(NC) 
    PRES = np.zeros(NC)
    
    C = np.zeros((NS,NC))
    dmu = np.zeros((NS,NC))
    ph = np.zeros(NC)
    Vol = np.zeros(NC)
    EP = np.zeros(NC)
    
    delmu = np.zeros((NS,NC,NC))
    delmu2 = np.zeros((NS,NC,NC))
    
    hkconc = np.zeros(4)
    Amat = np.zeros((Natp,Natp))
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
# for HKATPase matrix inversion
    
    lwork = 10000  
    ipiv = np.zeros(Natp)
    work = np.zeros(lwork)
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ASSIGN CONCENTRATIONS, VOLUMES, AND POTENTIALS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for J in range(1, NS + 1):
        C[J-1, 6-1] = omcd[Lz+1].conc[J-1, 6-1]
        
    EP[6-1] = omcd[Lz+1].ep[6-1]

    for I in range(1, NS2 + 1):
        C[I-1, 1-1] = x[1 + 5 * (I-1) -1]
        C[I-1, 2-1] = x[2 + 5 * (I-1) -1]
        C[I-1, 3-1] = x[3 + 5 * (I-1) -1]
        C[I-1, 4-1] = x[4 + 5 * (I-1) -1]
        C[I-1, 5-1] = x[5 + 5 * (I-1) -1]

    for K in range(1, NC - 1 + 1):
        ph[K-1] = -np.log10(C[12-1, K-1] / 1.0e3)
        Vol[K-1] = x[K + 5*NS2 -1]  
        EP[K-1] = x[K + 5 + 5*NS2 -1]
        
    PM = x[11 + 5 * NS2 - 1]  # Hydraulic pressure in lumen
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE THE NEW SURFACE AREAS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    omcd[Lz+1].area[5-1, 6-1] = omcd[Lz+1].sbasEinit * max( Vol[5-1] / omcd[Lz+1].volEinit, 1.0 )
    omcd[Lz+1].area[6-1, 5-1] = omcd[Lz+1].area[5-1, 6-1]
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIALIZE ALL FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    from compute_water_fluxes import compute_water_fluxes

    Jvol = compute_water_fluxes (C, PM, 0, Vol, omcd[Lz+1].volLuminit, 
                          omcd[Lz+1].volEinit, omcd[Lz+1].volPinit, CPimprefOMC,
                          omcd[Lz+1].volAinit, CAimprefOMC, omcd[Lz+1].volBinit, 
                          CBimprefOMC, omcd[Lz+1].area, omcd[Lz+1].sig, omcd[Lz+1].dLPV,
                          complOMC, PTinitVol)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOLUTE FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-dimensional solute fluxes are first converted to dimensional fluxes
# (in mmol/s/cm2 epith) by multiplying by href*Cref
# Then they are converted to units of pmol/min/mm tubule

    convert = href * Cref * np.pi * DiamOMC * 60 / 10 * 1.0e9  # Conversion factor

#---------------------------------------------------------------------72
# ELECTRO-CONVECTIVE-DIFFUSIVE FLUXES
#---------------------------------------------------------------------72
    
# dependence of ENaC, ROMK, and apical paracellular Cl permeability on pH

    facphMP = 1.0 * (0.1 + 2.0/(1+np.exp(-6.0*(ph[2-1]-7.50))))
    facphTJ = 2.0/(1.0 + np.exp(10.0*(ph[5-1]-7.32)))
    
    facNaMP = (30 / (30 + C[1-1,1-1])) * (50 / (50 + C[1-1,2-1]))

    omcd[Lz+1].h[1-1, 1-1, 2-1] = hENaC_OMC * facNaMP * facphMP
    
    omcd[Lz+1].h[2-1, 1-1, 2-1] = hROMK_OMC * facphMP
    
    omcd[Lz+1].h[3-1, 1-1, 5-1] = hCltj_OMC * facphTJ

# define electrochemical potential of each solute in each compartment
    from compute_ecd_fluxes import compute_ecd_fluxes

    Jsol, delmu = compute_ecd_fluxes (C, EP, omcd[Lz+1].area, omcd[Lz+1].sig, omcd[Lz+1].h, Jvol)

    XI = zval[1-1] * F * EPref / RT * ( EP[1-1] - EP[2-1] )
    dint = np.exp(-XI)
    if ( np.abs(1.0 - dint) < 1e-6 ):
        JNa = omcd[Lz+1].area[1-1, 2-1] * omcd[Lz+1].h[1-1, 1-1, 2-1] * ( C[1-1, 1-1] - C[1-1, 2-1] )
    else:
        JNa = omcd[Lz+1].area[1-1, 2-1] * omcd[Lz+1].h[1-1, 1-1, 2-1] * XI * (C[1-1, 1-1] - C[1-1, 2-1] * dint) / (1.0-dint)

# dimensional fluxes through channels, for print out
    
    fluxENaC = Jsol[1-1, 1-1, 2-1] * convert
    fluxROMK = Jsol[2-1, 1-1, 2-1] * convert
    
    fluxKchPES = (Jsol[2-1, 2-1, 5-1] + Jsol[2-1, 2-1, 6-1]) * convert
    fluxKchAES = (Jsol[2-1, 3-1, 5-1] + Jsol[2-1, 3-1, 6-1]) * convert
    fluxClchPES = (Jsol[3-1, 2-1, 5-1] + Jsol[3-1, 2-1, 6-1]) * convert
    fluxClchAES = (Jsol[3-1, 3-1, 5-1] + Jsol[3-1, 3-1, 6-1]) * convert
    fluxBichPES = (Jsol[4-1, 2-1, 5-1] + Jsol[4-1, 2-1, 6-1]) * convert
    fluxBichAES = (Jsol[4-1, 3-1, 5-1] + Jsol[4-1, 3-1, 6-1]) * convert
    
    fluxH2CO3MP = Jsol[5-1, 1-1, 2-1] * convert
    fluxH2CO3MA = Jsol[5-1, 1-1, 3-1] * convert
    fluxCO2MP = Jsol[6-1, 1-1, 2-1] * convert
    fluxCO2MA = Jsol[6-1, 1-1, 3-1] * convert
    
    fluxH2CO3PES = (Jsol[5-1, 2-1, 5-1] + Jsol[5-1, 2-1, 6-1]) * convert
    fluxH2CO3AES = (Jsol[5-1, 3-1, 5-1] + Jsol[5-1, 3-1, 6-1]) * convert
    fluxCO2PES = (Jsol[6-1, 2-1, 5-1] + Jsol[6-1, 2-1, 6-1]) * convert
    fluxCO2AES = (Jsol[6-1, 3-1, 5-1] + Jsol[6-1, 3-1, 6-1]) * convert
    
    fluxHP2mchPES = (Jsol[7-1, 2-1, 5-1] + Jsol[7-1, 2-1, 6-1]) * convert
    fluxHP2mchAES = (Jsol[7-1, 3-1, 5-1] + Jsol[7-1, 3-1, 6-1]) * convert
    fluxHPmPES = (Jsol[8-1, 2-1, 5-1] + Jsol[8-1, 2-1, 6-1]) * convert
    fluxHPmAES = (Jsol[8-1, 3-1, 5-1] + Jsol[8-1, 3-1, 6-1]) * convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS COTRANSPORTERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# Na2HPO4 cotransporter at PE,PS,AE,AS,BE,BS interfaces

    for K in range(2, 3 + 1):
        sumJES = 0.0
        for L in range(5, 6+1):
            dJNaP = omcd[Lz+1].area[K-1, L-1] * omcd[Lz+1].dLA[1-1, 7-1, K-1, L-1] * (2*delmu[1-1, K-1, L-1] + delmu[7-1, K-1, L-1])
            Jsol[1-1, K-1, L-1] += 2*dJNaP
            Jsol[7-1, K-1, L-1] += dJNaP
            sumJES += 2*dJNaP
    
    if (K == 2): 
        fluxNaPatPES = sumJES * convert
        
    if (K == 3):
        fluxNaPatAES = sumJES * convert
  
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS EXCHANGERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# NaH exchanger at PE,PS,AE,AS interfaces
# NHE1 model for principal cell ! Model of Fuster et al (J Gen Physiol 2009) 
# - NOT USED

    K = 2
    sumJES = 0.0
    for L in range(5, 6 + 1):
        affnao = 34.0
        affnai = 102.0
        affho = 0.0183e-3
        affhi = 0.054e-3
        fnai = C[1-1, K-1]
        hi = C[12-1, K-1]
        fnao = C[1-1, L-1]
        ho = C[12-1, L-1]
        Fno = (fnao/affnao) / (1.0 + fnao/affnao + ho/affho)
        Fni = (fnai/affnai) / (1.0 + fnai/affnai + hi/affhi)
        Fho = (ho/affho) / (1.0 + fnao/affnao + ho/affho)
        Fhi = (hi/affhi) / (1.0 + fnai/affnai + hi/affhi)
        E2mod1 = (Fni+Fhi) / (Fni+Fhi+Fno+Fho)
        E1mod1 = 1.0 - E2mod1
        E2mod2 = (Fni**2 + Fhi**2) / (Fni**2 + Fhi**2 + Fno**2 + Fho**2)
        E1mod2 = 1.0 - E2mod2
        Fmod1 = (hi**2) / (hi**2 + (0.3e-3)**2)
        Rnhe = 1.0e3 * (1.0 * (1.0 - Fmod1) * (E2mod2 * (Fno**2) - E1mod2 * (Fni**2)) + Fmod1 * (E2mod1 * Fno - E1mod1 * Fni))
        dJNaH = -1 * omcd[Lz+1].area[K-1, L-1] * omcd[Lz+1].xNHE1[K-1] * Rnhe

        sumJES += dJNaH
    fluxNaHPES = sumJES * convert

# NaH exchanger at PE and PS interfaces

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaHPES = omcd[Lz+1].area[2-1, L-1] * omcd[Lz+1].dLA[1-1, 12-1, 2-1, L-1] * (delmu[1-1, 2-1, L-1] - delmu[12-1, 2-1, L-1])
        Jsol[1-1, 2-1, L-1] += dJNaHPES
        Jsol[12-1, 2-1, L-1] -= dJNaHPES
        sumJES += dJNaHPES
    fluxNaHPES = sumJES * convert    
    
# NaH exchanger at AE and AS interfaces
    
    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaHAES = omcd[Lz+1].area[3-1, L-1] * omcd[Lz+1].dLA[1-1, 12-1, 3-1, L-1] * (delmu[1-1, 3-1, L-1] - delmu[12-1, 3-1, L-1])
        Jsol[1-1, 3-1, L-1] += dJNaHAES
        Jsol[12-1, 3-1, L-1] -= dJNaHAES
        sumJES += dJNaHAES
    fluxNaHAES = sumJES * convert   
    
# Cl/HCO3 exchanger at PE,PS interfaces

    sumJES = 0.0
    for L in range(5, 6+1):
        dJClHCO3 = omcd[Lz+1].area[2-1,L-1] * omcd[Lz+1].dLA[3-1,4-1,2-1,L-1] * ( delmu[3-1,2-1,L-1] - delmu[4-1,2-1,L-1] )           
        Jsol[3-1,2-1,L-1] += dJClHCO3
        Jsol[4-1,2-1,L-1] -= dJClHCO3
        sumJES += dJClHCO3
    fluxClHCO3exPES = sumJES*convert

#---------------------------------------------------------------------72
# AE1 EXCHANGER AT PERITUBULAR MEMBRANE OF ALPHA CELL
# b is for HCO3, c is for Cl
# p (or prime) is for the internal compartment (A, or 3)
# pp (or double prime) is for the external compartment (E/S)
#---------------------------------------------------------------------

    bpp = C[4-1, 3-1]
    cpp = C[3-1, 3-1]
    betapp = bpp/dKbpp
    gampp = cpp/dKcpp
    sumJES = 0.0
    for K in range(5, 6+1):
        bp = C[4-1, K-1]
        cp = C[3-1, K-1]
        betap = bp/dKbp
        gamp = cp/dKcp
        xT = omcd[Lz+1].xAE1 / (1 + bpp / 172.0)
        sumum = (1 + betap + gamp) * (Pbpp * betapp + Pcpp * gampp)
        sumum += (1 + betapp + gampp) * (Pbp * betap + Pcp * gamp)
        befflux = omcd[Lz+1].area[3-1, K-1] * xT / sumum * (Pbpp * betapp * Pcp * gamp - Pbp * betap * Pcpp * gampp)
        Jsol[4-1, 3-1, K-1] += befflux
        Jsol[3-1, 3-1, K-1] -= befflux
        sumJES -= befflux
    fluxAE1 = sumJES * convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ACTIVE TRANSPORT VIA ATPases
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Na-K-ATPase
#---------------------------------------------------------------------
    
    for M in range(2, 4+1):  # For compartments P, A, B
        AffNa = 0.2 * (1.0 + C[2-1,M-1] / 8.33)

        actNa = C[1-1,M-1] / ( C[1-1,M-1] + AffNa )
        AffK = 0.1 * ( 1.0 + C[1-1,6-1] / 18.5 )
        AffNH4 = AffK / 0.20  # Per Alan's email
        actK5 = C[2-1,5-1] / ( C[2-1,5-1] + AffK )
        actK6 = C[2-1,6-1] / ( C[2-1,6-1] + AffK )
    
        dJact5 = omcd[Lz+1].area[M-1,5-1] * omcd[Lz+1].ATPNaK[M-1,5-1] * (actNa ** 3.0) * (actK5 ** 2.0)
        dJact6 = omcd[Lz+1].area[M-1,6-1] * omcd[Lz+1].ATPNaK[M-1,6-1] * (actNa ** 3.0) * (actK6 ** 2.0)
    
        ro5 = ( C[11-1,5-1] / AffNH4 ) / ( C[2-1,5-1] / AffK )
        ro6 = ( C[11-1,6-1] / AffNH4 ) / ( C[2-1,6-1] / AffK )

        Jsol[1-1, M-1, 5-1] += dJact5
        Jsol[1-1, M-1, 6-1] += dJact6
    
        Jsol[2-1, M-1, 5-1] -= 2.0/3.0*dJact5/(1+ro5)
        Jsol[2-1, M-1, 6-1] -= 2.0/3.0*dJact6/(1+ro6)
    
        Jsol[11-1, M-1, 5-1] -= 2.0/3.0*dJact5*ro5/(1+ro5)
        Jsol[11-1, M-1, 6-1] -= 2.0/3.0*dJact6*ro6/(1+ro6)
    
        if (M == 2): 
            fluxNaKasePES = (dJact5 + dJact6) * convert
        if (M == 3):
            fluxNaKaseAES = (dJact5 + dJact6) * convert
        if (M == 4):
            fluxNaKaseBES = (dJact5 + dJact6) * convert

#---------------------------------------------------------------------72
# H-ATPase
# See Strieter & Weinstein paper for signs (AJP 263, 1992)
#---------------------------------------------------------------------72

    denom13 = 1.0 + np.exp(steepA * (delmu[12-1, 1-1, 3-1] - dmuATPH) )
    dJact13 = -1 * omcd[Lz+1].area[1-1, 3-1] * omcd[Lz+1].ATPH[1-1, 3-1] / denom13
    Jsol[12-1, 1-1, 3-1] += dJact13
    fluxHATPaseMA = (dJact13) * convert

#---------------------------------------------------------------------72
# H-K-ATPase at MP and MA interfaces
#---------------------------------------------------------------------72

#---------------------------------------------------------------------72
# H-K-ATPase at MP interface
#---------------------------------------------------------------------72
    
    hkconc[1-1] = C[2-1, 2-1]  # [K]in = K in P
    hkconc[2-1] = C[2-1, 1-1]  # [K]out = K in M
    hkconc[3-1] = C[12-1, 2-1]  # [H]in = H in P
    hkconc[4-1] = C[12-1, 1-1]  # [H]out = H in M
    
    
    from fatpase import fatpase
    
    Amat = fatpase(Natp,hkconc)
    
    Amat_org = Amat
    
# invert Jacobian matrix
    
    Amat_n = Amat_org
    
    if np.linalg.det(Amat_n) != 0:
        
        Amat_inv = np.linalg.inv(Amat_n)
        Amat = Amat_inv
    
# determine needed variables for calculating H efflux = K influx
# Need c(7) = H2-E1-P and c(8) = H2-E2-P
    
        c7 = Amat[7-1, 1-1]
        c8 = Amat[8-1, 1-1]
        dkf5 = 4.0e1
        dkb5 = 2.0e2
        hefflux = omcd[Lz+1].area[1-1, 2-1] * omcd[Lz+1].ATPHK[1-1, 2-1] * (dkf5 * c7 - dkb5 * c8)
        Jsol[2-1, 1-1, 2-1] += hefflux
        Jsol[12-1, 1-1, 2-1] -= hefflux
        fluxHKATPaseMP = 2 * hefflux * convert

#---------------------------------------------------------------------72
# H-K-ATPase at MA interface
#---------------------------------------------------------------------72
    
    hkconc[1-1] = C[2-1, 3-1]  # [K]in = K in A
    hkconc[2-1] = C[2-1, 1-1]  # [K]out = K in M
    hkconc[3-1] = C[12-1, 3-1]  # [H]in = H in A
    hkconc[4-1] = C[12-1, 1-1]  # [H]out = H in M
    
    
    from fatpase import fatpase
    
    Amat = fatpase(Natp,hkconc)
    
    Amat_org = Amat
    
# invert Jacobian matrix
    
    Amat_n = Amat_org
    
    if np.linalg.det(Amat_n) != 0:
        
        Amat_inv = np.linalg.inv(Amat_n)
        Amat = Amat_inv
    
        c7 = Amat[7-1, 1-1]
        c8 = Amat[8-1, 1-1]
        dkf5 = 4.0e1
        dkb5 = 2.0e2
        hefflux = omcd[Lz+1].area[1-1, 3-1] * omcd[Lz+1].ATPHK[1-1, 3-1] * (dkf5 * c7 - dkb5 * c8)
        Jsol[2-1, 1-1, 3-1] += 2 * hefflux
        Jsol[12-1, 1-1, 3-1] -= 2 * hefflux
        fluxHKATPaseMA = 2 * hefflux * convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Cancel all IC-B fluxes
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Jvol[1-1, 4-1] = 0.0
    Jvol[4-1, 5-1] = 0.0
    Jvol[4-1, 6-1] = 0.0
    
    for I in range(1, NS+1):
        Jsol[I-1, 1-1, 4-1] = 0.0
        Jsol[I-1, 4-1, 5-1] = 0.0
        Jsol[I-1, 4-1, 6-1] = 0.0
  
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Print results
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    cv = href*Cref*np.pi*DiamOMC*60/10*1.0e9  # for dimensional solute fluxes
    cvw = Pfref*Cref*Vwbar*np.pi*DiamOMC*60/10*1.0e6  # for dimensional water flux

#---------------------------------------------------------------------72
#
# STORE LOCAL FLUX VALUES FOR LATER INTEGRATION
#
#---------------------------------------------------------------------

    omcd[Lz+1].FNatrans = ( Jsol[1-1, 1-1, 2-1] + Jsol[1-1, 1-1, 3-1] ) * cv * omcd[Lz+1].coalesce
    omcd[Lz+1].FNapara = Jsol[1-1, 1-1, 5-1] * cv * omcd[Lz+1].coalesce
    omcd[Lz+1].FNaK = (fluxNaKasePES + fluxNaKaseAES + fluxNaKaseBES) * omcd[Lz+1].coalesce
    
    omcd[Lz+1].FKtrans = ( Jsol[2-1, 1-1, 2-1] + Jsol[2-1, 1-1, 3-1] ) * cv * omcd[Lz+1].coalesce
    omcd[Lz+1].FKpara = Jsol[2-1, 1-1, 5-1] * cv * omcd[Lz+1].coalesce

    return Jvol, Jsol
