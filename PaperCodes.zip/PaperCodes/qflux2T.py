# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This subroutine computes the fluxes in the cTAL

# INPUT ARGUMENTS:
# x: vector of 4*NS concentrations, 4 volumes, and 4 potentials
#
# OUTPUT ARGUMENTS:
# Jvol: volume fluxes
# Jsol: solute fluxes
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 


# Note:
# LzPT in "main" for "qnewton2PT" is equal to J - 1, in Fortran
# In python, LzPT is just equal to Lz
# It is LzPT+1 as Fortran version (No need for LzPT+1-1)
# Below def, LzPT = Lz

def qflux2T(x, Cext, EPext, ctal, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    LzT = Lz # added in python code
    
    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))
    
    ONC = np.zeros(NC) 
    PRES = np.zeros(NC)
    
    C = np.zeros((NS,NC))
    dmu = np.zeros((NS,NC))
    ph = np.zeros(NC)
    Vol = np.zeros(NC)
    EP = np.zeros(NC)
    
    delmu = np.zeros((NS,NC,NC))
    
    hkconc = np.zeros(4)
    Amat = np.zeros((Natp,Natp))
    
    theta = np.zeros(NC)
    Slum = np.zeros(NC)
    Slat = np.zeros(NC)
    Sbas = np.zeros(NC)
    
# for HKATPase matrix inversion
    
    lwork = 10000  
    ipiv = np.zeros(Natp)
    work = np.zeros(lwork)
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ASSIGN CONCENTRATIONS, VOLUMES, AND POTENTIALS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for J in range(1, NS + 1):
        C[J-1, 6-1] = Cext[J-1]
    EP[6-1] = EPext

    for I in range(1, NS2 + 1):
        C[I-1, 1-1] = x[1 + 3 * (I-1) -1]
        C[I-1, 2-1] = x[2 + 3 * (I-1) -1]
        C[I-1, 5-1] = x[3 + 3 * (I-1) -1]

    Vol[0] = x[0 + 3 * NS2]
    Vol[1] = x[1 + 3 * NS2]
    Vol[4] = x[2 + 3 * NS2]
    EP[0] = x[3 + 3 * NS2]
    EP[1] = x[4 + 3 * NS2]
    EP[4] = x[5 + 3 * NS2]
    PM = x[6 + 3 * NS2]
    
# Assign dummy values to compartments 3 and 4

    for I in range(1, NS + 1):
        C[I-1, 3-1] = C[I-1, 2-1]
        C[I-1, 4-1] = C[I-1, 2-1]

    for K in range(1, NC + 1):
        ph[K-1] = -np.log10( C[12-1, K-1] / 1.0e3 )
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# DETERMINE THE NEW SURFACE AREAS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    ctal[Lz+1].area[5-1, 6-1] = ctal[Lz+1].sbasEinit * max( Vol[5-1] / ctal[Lz+1].volEinit, 1.0 )
    ctal[Lz+1].area[6-1, 5-1] = ctal[Lz+1].area[5-1, 6-1]
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIALIZE ALL FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    Jvol = np.zeros((NC, NC))
    Jsol = np.zeros((NS, NC, NC))

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE WATER FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    from compute_water_fluxes import compute_water_fluxes

    Jvol = compute_water_fluxes (C, PM, 0, Vol, ctal[Lz+1].volLuminit, 
                          ctal[Lz+1].volEinit, ctal[Lz+1].volPinit, CPimprefT,
                          ctal[Lz+1].volAinit, CAimprefT, ctal[Lz+1].volBinit, 
                          CBimprefT, ctal[Lz+1].area, ctal[Lz+1].sig, ctal[Lz+1].dLPV,
                          complT, PTinitVol)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOLUTE FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Non-dimensional solute fluxes are first converted to dimensional fluxes
# (in mmol/s/cm2 epith) by multiplying by href*Cref
# Then they are converted to units of pmol/min/mm tubule

    convert = href * Cref * np.pi * DiamT * 60 / 10 * 1.0e9  # Conversion factor
    eps = 1.0e-4  # For exponential (Peclet) terms

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# COMPUTE SOLUTE FLUXES
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

#---------------------------------------------------------------------72
# ELECTRO-CONVECTIVE-DIFFUSIVE FLUXES
#---------------------------------------------------------------------72
    
    from compute_ecd_fluxes import compute_ecd_fluxes

    Jsol, delmu = compute_ecd_fluxes (C, EP, ctal[Lz+1].area, ctal[Lz+1].sig, ctal[Lz+1].h, Jvol)

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS COTRANSPORTERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Basolateral Na2HPO4 cotransporter
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaP = ctal[Lz+1].area[2-1, L-1] * ctal[Lz+1].dLA[1-1, 7-1, 2-1, L-1] * (2*delmu[1-1, 2-1, L-1] + delmu[7-1, 2-1, L-1])
        Jsol[1-1, 2-1, L-1] += 2*dJNaP
        Jsol[7-1, 2-1, L-1] += dJNaP
        sumJES += 2*dJNaP
    fluxNaPatPES = sumJES * convert    

#---------------------------------------------------------------------72
# Basolateral Na(1)-HCO3(3) cotransporter
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJNaBic = ctal[Lz+1].area[2-1, L-1] * ctal[Lz+1].dLA[1-1, 4-2, 2-1, L-1] * (delmu[0, 1, L-1] + 3 * delmu[3, 1, L-1])
        Jsol[0, 1, L-1] += dJNaBic
        Jsol[3, 1, L-1] += 3*dJNaBic
        sumJES += dJNaBic
    fluxNaBicPES = sumJES * convert

#---------------------------------------------------------------------72
# NKCC2 cotransporter on MP interface
#---------------------------------------------------------------------72
# B isoform
#---------------------------------------------------------------------72

    from compute_nkcc2_flux import compute_nkcc2_flux

    dJnNKCC2B,dJkNKCC2B,dJcNKCC2B,dJmNKCC2B = compute_nkcc2_flux ( C, ctal[Lz+1].area[1-1,2-1], ctal[Lz+1].xNKCC2B, 
                             bn2B, bk2B, bc2B, bm2B, popnkccB,
                             pnkccpB,pnmccpB,poppnkccB,pnkccppB,
                             pnmccppB)

    Jsol[1-1,1-1,2-1] += dJnNKCC2B
    Jsol[2-1,1-1,2-1] += dJkNKCC2B
    Jsol[3-1,1-1,2-1] += dJcNKCC2B
    Jsol[11-1,1-1,2-1] += dJmNKCC2B
    
    fluxnNKCC2B = dJnNKCC2B * convert
    fluxkNKCC2B = dJkNKCC2B * convert
    fluxmNKCC2B = dJmNKCC2B * convert
    fluxcNKCC2B = dJcNKCC2B * convert
    
# A isoform
#---------------------------------------------------------------------72

    from compute_nkcc2_flux import compute_nkcc2_flux

    dJnNKCC2A, dJkNKCC2A, dJcNKCC2A, dJmNKCC2A = compute_nkcc2_flux ( C, ctal[Lz+1].area[1-1,2-1], ctal[Lz+1].xNKCC2A,
                              bn2A, bk2A, bc2A, bm2A, popnkccA,
                              pnkccpA, pnmccpA, poppnkccA, pnkccppA,
                              pnmccppA )

    Jsol[1-1,1-1,2-1] += dJnNKCC2A
    Jsol[2-1,1-1,2-1] += dJkNKCC2A
    Jsol[3-1,1-1,2-1] += dJcNKCC2A
    Jsol[11-1,1-1,2-1] += dJmNKCC2A
    
    fluxnNKCC2A = dJnNKCC2A*convert
    fluxkNKCC2A = dJkNKCC2A*convert
    fluxmNKCC2A = dJmNKCC2A*convert
    fluxcNKCC2A = dJcNKCC2A*convert
    
    fluxnNKCC2 = fluxnNKCC2A + fluxnNKCC2B
    fluxkNKCC2 = fluxkNKCC2A + fluxkNKCC2B
    fluxmNKCC2 = fluxmNKCC2A + fluxmNKCC2B
    fluxcNKCC2 = fluxcNKCC2A + fluxcNKCC2B
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FLUXES ACROSS EXCHANGERS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# NHE3 EXCHANGER AT LUMINAL MEMBRANE OF CELL
# n is for Na, c is for Cl
# p (or prime) is for the luminal compartment (M)
# pp (or double prime) is for the cytosolic compartment (I)
#---------------------------------------------------------------------

    from compute_nhe3_fluxes import compute_nhe3_fluxes
 
    dJNHEsod, dJNHEprot, dJNHEamm = compute_nhe3_fluxes (C, ctal[Lz+1].area[1-1, 2-1], 
                               ctal[Lz+1].xNHE3)
    
    Jsol[1-1, 1-1, 2-1] += dJNHEsod
    Jsol[12-1, 1-1, 2-1] += dJNHEprot
    Jsol[11-1, 1-1, 2-1] += dJNHEamm
    
    fluxNHEsod = dJNHEsod * convert
    fluxNHEprot = dJNHEprot * convert
    fluxNHEamm = dJNHEamm * convert

#---------------------------------------------------------------------72
# Basolateral NaH exchangers
#---------------------------------------------------------------------72

    for K in range(2, 2+1):
        sumJES=0.0
        for L in range(5, 6+1):
            dJNaH = ctal[Lz+1].area[K-1,L-1] * ctal[Lz+1].dLA[1-1,12-1,K-1,L-1] * ( delmu[1-1,K-1,L-1] - delmu[12-1,K-1,L-1] )
            Jsol[1-1,K-1,L-1] += dJNaH
            Jsol[12-1,K-1,L-1] -= dJNaH
            sumJES += dJNaH
        fluxNaHPES = sumJES * convert

#---------------------------------------------------------------------72
# Cl/HCO3 exchanger at PE,PS interfaces
#---------------------------------------------------------------------

    sumJES = 0.0
    for L in range(5, 6+1):
        dJClHCO3 = ctal[Lz+1].area[2-1,L-1] * ctal[Lz+1].dLA[3-1,4-1,2-1,L-1] * ( delmu[3-1,2-1,L-1] - delmu[4-1,2-1,L-1] )           
        Jsol[3-1,2-1,L-1] += dJClHCO3
        Jsol[4-1,2-1,L-1] -= dJClHCO3
        sumJES += dJClHCO3
    fluxClHCO3exPES = sumJES*convert

#---------------------------------------------------------------------72
# KCC cotransporter on PE & PS interfaces
#---------------------------------------------------------------------

    from compute_kcc_fluxes import compute_kcc_fluxes

    dJk5, dJc5, dJm5, dJk6, dJc6, dJm6 = compute_kcc_fluxes (C, ctal[Lz+1].area[2-1,5-1], ctal[Lz+1].area[2-1,6-1], 
                             ctal[Lz+1].xKCC4)
    
    Jsol[2-1, 2-1, 5-1] += dJk5
    Jsol[3-1, 2-1, 5-1] += dJc5
    Jsol[11-1, 2-1, 5-1] += dJm5
    
    Jsol[2-1, 2-1, 6-1] += dJk6
    Jsol[3-1, 2-1, 6-1] += dJc6
    Jsol[11-1, 2-1, 6-1] += dJm6

    fluxkKCC = (dJk5 + dJk6)*convert
    fluxcKCC = (dJc5 + dJc6)*convert
    fluxmKCC = (dJm5 + dJm6)*convert
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# ACTIVE TRANSPORT VIA ATPases
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Na-K-ATPase
#---------------------------------------------------------------------

    AffNa = 0.2 * (1.0 + C[2-1,2-1] / 8.33)
    actNa = C[1-1,2-1] / ( C[1-1,2-1] + AffNa )
    AffK = 0.1 * ( 1.0 + C[1-1,6-1] / 18.5 )
    AffNH4 = AffK
    actK5 = C[2-1,5-1] / ( C[2-1,5-1] + AffK )
    actK6 = C[2-1,6-1] / ( C[2-1,6-1] + AffK )
    
    dJact5 = ctal[Lz+1].area[2-1,5-1] * ctal[Lz+1].ATPNaK[2-1,5-1] * (actNa ** 3.0) * (actK5 ** 2.0)
    dJact6 = ctal[Lz+1].area[2-1,6-1] * ctal[Lz+1].ATPNaK[2-1,6-1] * (actNa ** 3.0) * (actK6 ** 2.0)
    
    ro5 = ( C[11-1,5-1] / AffNH4 ) / ( C[2-1,5-1] / AffK )
    ro6 = ( C[11-1,6-1] / AffNH4 ) / ( C[2-1,6-1] / AffK )

    Jsol[1-1, 2-1, 5-1] += dJact5
    Jsol[1-1, 2-1, 6-1] += dJact6
    
    Jsol[2-1, 2-1, 5-1] -= 2.0/3.0*dJact5/(1+ro5)
    Jsol[2-1, 2-1, 6-1] -= 2.0/3.0*dJact6/(1+ro6)
    
    Jsol[11-1, 2-1, 5-1] -= 2.0/3.0*dJact5*ro5/(1+ro5)
    Jsol[11-1, 2-1, 6-1] -= 2.0/3.0*dJact6*ro6/(1+ro6)
    
    fluxNaKPESsod = (dJact5+dJact6)*convert
    
    fluxNaKPESpot = -2/3.0*(dJact5/(1+ro5)+dJact6/(1+ro6))*convert
    fluxNaKPESamm = -2/3.0*(dJact5*ro5/(1+ro5)+dJact6*ro6/(1+ro6))*convert

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Print results
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    cv = href*Cref*np.pi*DiamT*60/10*1.0e9  # for dimensional solute fluxes
    cvw = Pfref*Cref*Vwbar*np.pi*DiamT*60/10*1.0e6  # for dimensional water flux

    for I in range(1, 3+1):
        apfluxnet = Jsol[I-1,1-1,2-1] + Jsol[I-1,1-1,3-1] + Jsol[I-1,1-1,4-1] + Jsol[I-1,1-1,5-1]
        basfluxnet = Jsol[I-1,2-1,6-1] + Jsol[I-1,3-1,6-1] + Jsol[I-1,4-1,6-1] + Jsol[I-1,5-1,6-1]
        fluxlatnet = Jsol[I-1,1-1,5-1] + Jsol[I-1,2-1,5-1] + Jsol[I-1,3-1,5-1] + Jsol[I-1,4-1,5-1] - Jsol[I-1,5-1,6-1]
        
#---------------------------------------------------------------------72
#
# STORE LOCAL FLUX VALUES FOR LATER INTEGRATION
#
#---------------------------------------------------------------------

    ctal[Lz+1].FNatrans = Jsol[1-1, 1-1, 2-1]*cv
    ctal[Lz+1].FNapara = Jsol[1-1, 1-1, 5-1]*cv
    ctal[Lz+1].FNaK = fluxNaKPESsod
    ctal[Lz+1].FHase = 0.0
    
    ctal[Lz+1].FKtrans = Jsol[2-1, 1-1, 2-1]*cv
    ctal[Lz+1].FKpara = Jsol[2-1, 1-1, 5-1]*cv
    
    return Jvol, Jsol
