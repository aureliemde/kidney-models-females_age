# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** NEWTON SOLVER *************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Description: This is the subroutine for the proximal tubule segment
# This model yields values of concentrations, volumes, and EP
# in the lumen and epithelial compartments at equilibrium.
#---------------------------------------------------------------------72
#
# The units are those of the cgs system: cm, mmol, mmol/cm3 = M, s.
# The morphological parameters are those of the rat. Parameters are
# taken from the PT model of A.M. Weinstein (AJP 2007).
#
#---------------------------------------------------------------------72
# Solute Indices: 1 = Na+, 2 = K+, 3 = Cl-, 4 = HCO3-, 5 = H2CO3, 6 = CO2
# 7 = HPO4(2-), 8 = H2PO4-, 9 = urea, 10 = NH3, 11 = NH4+, 12 = H+
# 13 = HCO2-, 14 = H2CO2, 15 = glucose, 16 = Ca2+
#---------------------------------------------------------------------72
#
# The June 2 version differs from the AMW 2007 model in that:
# - the pressure equation has been corrected. TS is taken as 1.6 instead of 2.2.
# - it doesn't include an apical Cl/HCO3 exchanger. See Planelles (2004)
# and Aronson (1997, 2002). No evidence for its presence in the rat
# PT.
# - it includes a small basolateral Cl conductance. See Aronson and Giebisch
# (1997).
# - it includes a glucose consumption term, which depends on the Na-K-ATPase
# activity.
# - it includes the kinetic description of the Na, glucose cotransporters
# SGLT1 and SGLT2
# - it also includes a kinetic description of the GLUT1 & GLUT2 transporters
# - the S3 segment, where SGLT1 and GLUT1 are located, is taken into account.
#
#
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This is the Newton solver used to determine the epithelial
# concentrations, volumes, and EP at the inlet (jz = 0)

import numpy as np

from values import *
from glo import *
from defs import * 

def qnewton1PT(pt, CPimpref, CPbuftot1, idid, ncompl2, ntorq2, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
    
    # Initialize variables
    AVF = np.zeros(NUPT)
    A = np.zeros((NUPT, NUPT))
    
    Cprev = np.zeros((NSPT, NC))
    Volprev = np.zeros(NC)
    EPprev = np.zeros(NC)
    phprev = np.zeros(NC)
    
    osmol = np.zeros(NC)
    
    num = 37
    numpar = 10
    
    pars = np.zeros(numpar)
    
    x = np.zeros(NUPT)
    fvec = np.zeros(num)
    fjac = np.zeros((num, num))
    wa1 = np.zeros(num)
    wa2 = np.zeros(num)
    
    lwork = 10000
    
    ipiv = np.zeros(NUPT)
    work = np.zeros(lwork)
    
#---------------------------------------------------------------------72
# private variables
#---------------------------------------------------------------------72
    TOL = 1.0e-5
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# store initial concentrations
# CPREV's are used in computing iteration residue
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    for K in range(1, NC + 1):
        for I in range(1, NSPT + 1):
            Cprev[I-1, K-1] = pt[0].conc[I-1, K-1]
            
        phprev[K-1] = pt[0].ph[K-1]
        Volprev[K-1] = pt[0].vol[K-1]
        EPprev[K-1] = pt[0].ep[K-1]
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# START ITERATION LOOP TO FIND SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    res = 1.0
    iterat = 0
    
    while res > TOL and iterat < 21:
        res = 0.0
        iterat += 1
        
#---------------------------------------------------------------------72
# Create vector x of variables to solve for
#---------------------------------------------------------------------72
        
        for I in range(1, NSPT + 1):
            x[1 + 2 * (I - 1) -1] = pt[0].conc[I-1, 2-1]
            x[2 + 2 * (I - 1) -1] = pt[0].conc[I-1, 5-1]
        x[1 + 2 * NSPT -1] = pt[0].vol[2 -1]
        x[2 + 2 * NSPT -1] = pt[0].vol[5 -1]
        x[3 + 2 * NSPT -1] = pt[0].ep[1 -1]
        x[4 + 2 * NSPT -1] = pt[0].ep[2 -1]
        x[5 + 2 * NSPT -1] = pt[0].ep[5 -1] 
        
#---------------------------------------------------------------------72
# determine vector fvec of non-linear equations to be solved
# determine Jacobian matrix fjac corresponding to fvec
# fjac is a (NUxNU) matrix
#---------------------------------------------------------------------72
        
        ldfjac = num
        iflag = 1
        ml = num
        mu = num
        epsfcn = 1.0e-5

        
        pars[0] = pt[0].volEinit
        pars[1] = pt[0].volPinit
        pars[2] = CPimpref
        pars[3] = CPbuftot1
        pars[4] = pt[0].dkd[2 -1]
        pars[5] = pt[0].dkd[5 -1]
        pars[6] = pt[0].dkh[2 -1]
        pars[7] = pt[0].dkh[5 -1]
        pars[8] = ncompl2 * 1.0
        pars[9] = ntorq2 * 1.0

        from fcn1PT import fcn1PT
        fvec = fcn1PT(num, x, iflag, numpar, pars, pt, idid, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
       
        from jacobi2_1PT import jacobi2_1PT 
        fjac, wa1, fvec_J = jacobi2_1PT(num, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, pt, idid, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
        fjac_org = fjac
        
# #---------------------------------------------------------------------72
# # invert Jacobian matrix
# #---------------------------------------------------------------------72
        
        fjac_n = fjac_org
        fjac_inv = np.linalg.inv(fjac_n)
        fjac = fjac_inv
        
#---------------------------------------------------------------------72
# Calculate AVF: product of fjac (inverted Jacobian) and fvec
#---------------------------------------------------------------------72
        
        for L in range(1, num + 1):
            AVF[L - 1] = 0.0
            for M in range(1, num + 1):
                AVF[L-1] = AVF[L-1] + 1.0*fjac[L-1,M-1]*fvec[M-1]  # original = 0.500
         
#---------------------------------------------------------------------72
# Calculate updated concentrations, volumes, and potentials
# Then update "old" values
#---------------------------------------------------------------------72      
        
        for I in range(1, NSPT + 1):
            pt[0].conc[I-1, 2-1] = np.abs( Cprev[I-1, 2-1] - AVF[1 + 2 * (I - 1) -1] )  # conc is a positive value
            pt[0].conc[I-1, 5-1] = np.abs( Cprev[I-1, 5-1] - AVF[2 + 2 * (I - 1) -1] ) # conc is a positive value
            res = max(res, abs(pt[0].conc[I-1, 2-1] / Cprev[I-1, 2-1] - 1.0))
            res = max(res, abs(pt[0].conc[I-1, 5-1] / Cprev[I-1, 5-1] - 1.0))
        
        pt[0].vol[2-1] = Volprev[2-1] - AVF[1 + 2 * NSPT -1]
        res = max(res, abs(pt[0].vol[2-1] - Volprev[2-1]))
        pt[0].vol[5-1] = Volprev[5-1] - AVF[2 + 2 * NSPT -1]
        res = max(res, abs(pt[0].vol[5-1] - Volprev[5-1]))
        
        pt[0].ep[1-1] = EPprev[1-1] - AVF[3 + 2 * NSPT -1]
        res = max(res, abs(pt[0].ep[1-1] - EPprev[1-1]))
        pt[0].ep[2-1] = EPprev[2-1] - AVF[4 + 2 * NSPT -1]
        res = max(res, abs(pt[0].ep[2-1] - EPprev[2-1]))
        pt[0].ep[5-1] = EPprev[5-1] - AVF[5 + 2 * NSPT -1]
        res = max(res, abs(pt[0].ep[5-1] - EPprev[5-1]))
        
  # Update "previous" concentrations, volumes, and potentials
 
        for K in [2, 5+1]:
            for I in range(1, NSPT + 1):
                Cprev[I-1, K-1] = pt[0].conc[I-1, K-1]
            pt[0].ph[K-1] = -np.log10(pt[0].conc[12-1, K-1] / 1.0e3)
            phprev[K-1] = pt[0].ph[K-1]
            Volprev[K-1] = pt[0].vol[K-1]
            EPprev[K-1] = pt[0].ep[K-1]
        EPprev[1-1] = pt[0].ep[1-1]
        
        if iterat >= 11:
            if iterat < 20:
                TOL = 1.0e-3
            else:
                TOL = res * 1.010

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# FINAL RESULTS
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

# This variable is needed to determine impermeant concentrations along
# the entire nephron

    VolLumInit = pt[0].vol[1-1]
    
#---------------------------------------------------------------------72
# PRINT FINAL RESULTS
#---------------------------------------------------------------------72
    
    osmol[1-1] = LumImperm
    osmol[2-1] = CPimpref * pt[0].volPinit / pt[0].vol[2-1]
    osmol[5-1] = 0.0
    osmol[6-1] = BathImperm
    es = pt[0].ep[6-1]
    elecM = 0.0
    
    return
    