# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# prev in the code is replaced by pt[Lz]
# pt in the code is replaced by pt[Lz+1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

#  Description: This is the subroutine for the proximal tubule segment
#  This model yields values of concentrations, volumes, and EP 
#	in the lumen and epithelial compartments at equilibrium. 

#---------------------------------------------------------------------72
#									
#  The units are those of the cgs system: cm, mmol, mmol/cm3 = M, s.  
#  The morphological parameters are those of the rat. Parameters are
#  taken from the PT model of A.M. Weinstein (AJP 2007).
#
#---------------------------------------------------------------------72

#   Solute Indices:  1 = Na+, 2 = K+, 3 = Cl-, 4 = HCO3-, 5 = H2CO3, 6 = CO2
#	 7 = HPO4(2-), 8 = H2PO4-, 9 = urea, 10 = NH3, 11 = NH4+, 12 = H+
#	 13 = HCO2-, 14 = H2CO2, 15 = glucose, 16 = Ca2+

#---------------------------------------------------------------------72
#
#  The June 2 version differs from the AMW 2007 model in that:
#   - the pressure equation has been corrected. TS is taken as 1.6 instead of 2.2.
#	- it doesn't include an apical Cl/HCO3 exchanger. See Planelles (2004)
#		and Aronson (1997, 2002). No evidence for its presence in the rat PT.
#   - it includes a small basolateral Cl conductance. See Aronson and Giebisch
#		(1997).
#   - it includes a glucose consumption term, which depends on the Na-K-ATPase
#		activity.
#   - it includes the kinetic description of the Na, glucose cotransporters
#		SGLT1 and SGLT2
#   - it also includes a kinetic description of the GLUT1 & GLUT2 transporters
#   - the S3 segment, where SGLT1 and GLUT1, is accounted for.
#
# 
#---------------------------------------------------------------------72
 
#  *************************** NEWTON SOLVER *************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
#     This is the Newton solver used to determine the luminal and epithelial 
#	concentrations, volumes, and EP below the inlet 
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 

def qnewton2PT(pt, Lz, idid, Vol0, CPimpref, CPbuftot1, ND, ncompl2, ntorq2, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):

    EPzprev = np.zeros(NC)
    EPz = np.zeros(NC)
    
    Cb = np.zeros((NSPT, NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    AVF = np.zeros(ND)
    A = np.zeros((ND, ND))
    
    Cprev = np.zeros((NSPT, NC))
    Volprev = np.zeros(NC)
    EPprev = np.zeros(NC)
    phprev = np.zeros(NC)
    
    osmol = np.zeros(NC)

    num = 55
    numpar = 18 + 4 * NSPT

    x = np.zeros(num)
    fvec = np.zeros(num)
    fjac = np.zeros((num, num))
    wa1 = np.zeros(num)
    wa2 = np.zeros(num)
    
    pars = np.zeros(numpar)
    
    lwork = 10000

    ipiv = np.zeros(ND)
    work = np.zeros(lwork)
    
    TOL = 1.0e-5
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIAL GUESS: ASSUME SAME VALUES AS AT PREVIOUS STEP
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# store initial concentrations
# CPREV's are used in computing iteration residue
#---------------------------------------------------------------------72

    for k in range(1, NC - 1 + 1):
        for i in range(1, NSPT + 1):
            Cb[i-1, k-1] = pt[Lz].conc[i-1, k-1]
            Cprev[i-1, k-1] = Cb[i-1, k-1]
        
        phb[k-1] = pt[Lz].ph[k-1]
        phprev[k-1] = phb[k-1]
        
        Volb[k-1] = pt[Lz].vol[k-1]
        Volprev[k-1] = Volb[k-1]
        
        EPb[k-1] = pt[Lz].ep[k-1]
        EPprev[k-1] = EPb[k-1]

    PMb = pt[Lz].pres
    PMprev = PMb

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# START ITERATION LOOP TO DETERMINE SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    res = 1.0
    iterat = 0
    
    while res > TOL and iterat < 21:
        res = 0.0
        iterat += 1
        
#---------------------------------------------------------------------72
# Create vector x of variables to solve for
#---------------------------------------------------------------------72
        
        for i in range(1, NSPT + 1):
            x[1 + 3 * (i - 1) -1] = Cb[i-1, 1-1]
            x[2 + 3 * (i - 1) -1] = Cb[i-1, 2-1]
            x[3 + 3 * (i - 1) -1] = Cb[i-1, 5-1]
        x[1 + 3 * NSPT -1] = Volb[1 -1]
        x[2 + 3 * NSPT -1] = Volb[2 -1]
        x[3 + 3 * NSPT -1] = Volb[5 -1]
        x[4 + 3 * NSPT -1] = EPb[1 -1]
        x[5 + 3 * NSPT -1] = EPb[2 -1]
        x[6 + 3 * NSPT -1] = EPb[5 -1]
        x[7 + 3 * NSPT -1] = PMb
        
#---------------------------------------------------------------------72
# determine vector fvec of non-linear equations to be solved
# determine Jacobian matrix fjac corresponding to fvec
# fjac is a (NUxNU) matrix
#---------------------------------------------------------------------72

        ldfjac = num
        iflag = 1
        ml = num
        mu = num
        epsfcn = 1.0e-5

        pars[1 -1:NSPT +1 -1] = pt[Lz].conc[:,1 -1]
        pars[1+NSPT -1:2*NSPT + 1 -1] = pt[Lz].conc[:,2 -1]
        pars[1+2*NSPT -1:3*NSPT + 1 -1] = pt[Lz].conc[:,5 -1]
        pars[1+3*NSPT -1:4*NSPT + 1 -1] = pt[Lz].conc[:,6 -1]
        pars[1+4*NSPT -1] = pt[Lz].vol[1 -1]
        pars[2+4*NSPT -1] = pt[Lz].vol[2 -1]
        pars[3+4*NSPT -1] = pt[Lz].vol[5 -1]
        pars[4+4*NSPT -1] = pt[Lz].pres

        pars[5+ 4*NSPT -1] = pt[Lz+1].volEinit
        pars[6+ 4*NSPT -1] = pt[Lz+1].volPinit
        
        if idid == 0:
            pars[7+ 4*NSPT -1] = dimLPT
            
        pars[8+ 4*NSPT -1] = CPimpref
        pars[9+ 4*NSPT -1] = CPbuftot1
        pars[10+ 4*NSPT -1] = pt[Lz+1].dkd[1 -1]
        pars[11+ 4*NSPT -1] = pt[Lz+1].dkd[2 -1]
        pars[12+ 4*NSPT -1] = pt[Lz+1].dkd[5 -1]
        pars[13+ 4*NSPT -1] = pt[Lz+1].dkh[1 -1]
        pars[14+ 4*NSPT -1] = pt[Lz+1].dkh[2 -1]
        pars[15+ 4*NSPT -1] = pt[Lz+1].dkh[5 -1]
        pars[16+ 4*NSPT -1] = ncompl2*1.0
        pars[17+ 4*NSPT -1] = ntorq2*1.0
        pars[18+ 4*NSPT -1] = Vol0[1 -1]

        from fcn2PT import fcn2PT
        fvec = fcn2PT(num, x, iflag, numpar, pars, pt, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
        from jacobi2_2PT import jacobi2_2PT 
        fjac, wa1, fvec_J = jacobi2_2PT(num, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, pt, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)

        fjac_org = fjac

# # #---------------------------------------------------------------------72
# # # invert Jacobian matrix
# # #---------------------------------------------------------------------72

        fjac_n = fjac_org
        fjac_inv = np.linalg.inv(fjac_n)
        fjac = fjac_inv
        
# ---------------------------------------------------------------------72
# Calculate AVF: product of fjac (inverted Jacobian) and fvec
# ---------------------------------------------------------------------72

        for L in range(1, num + 1):
            AVF[L - 1] = 0.0
            for M in range(1, num + 1):
                AVF[L-1] = AVF[L-1] + 1.0*fjac[L-1,M-1]*fvec[M-1]  # original = 0.500
            
#---------------------------------------------------------------------72
# Calculate updated concentrations, volumes, and potentials
# Then update "old" values
#---------------------------------------------------------------------72
        
        for I in range(1, NSPT + 1):
            Cb[I-1, 1-1] = np.abs( Cprev[I-1, 1-1] - AVF[1 + 3*(I-1) -1] )
            Cb[I-1, 2-1] = np.abs( Cprev[I-1, 2-1] - AVF[2 + 3*(I-1) -1] )
            Cb[I-1, 5-1] = np.abs( Cprev[I-1, 5-1] - AVF[3 + 3*(I-1) -1] )
            res = max(res, abs(Cb[I-1, 1-1] / Cprev[I-1, 1-1] - 1.0))
            res = max(res, abs(Cb[I-1, 2-1] / Cprev[I-1, 2-1] - 1.0))
            res = max(res, abs(Cb[I-1, 5-1] / Cprev[I-1, 5-1] - 1.0))
                    
        phb[1-1] = -np.log10(Cb[12-1, 1-1] / 1.0e3)
        phb[2-1] = -np.log10(Cb[12-1, 2-1] / 1.0e3)
        phb[5-1] = -np.log10(Cb[12-1, 5-1] / 1.0e3)
        
        Volb[1-1] = Volprev[1-1] - AVF[1 + 3 * NSPT -1]
        res = max(res, abs(Volb[1-1] - Volprev[1-1]))
        Volb[2-1] = Volprev[2-1] - AVF[2 + 3 * NSPT -1]
        res = max(res, abs(Volb[2-1] - Volprev[2-1]))
        Volb[5-1] = Volprev[5-1] - AVF[3 + 3 * NSPT -1]
        res = max(res, abs(Volb[5-1] - Volprev[5-1]))
        
        EPb[1-1] = EPprev[1-1] - AVF[4 + 3 * NSPT -1]
        res = max(res, 1.0e-3 * abs(EPb[1-1] - EPprev[1-1]))
        EPb[2-1] = EPprev[2-1] - AVF[5 + 3 * NSPT -1]
        res = max(res, 1.0e-3 * abs(EPb[2-1] - EPprev[2-1]))
        EPb[5-1] = EPprev[5-1] - AVF[6 + 3 * NSPT -1]
        res = max(res, 1.0e-3 * abs(EPb[5-1] - EPprev[5-1]))
        
        PMb = PMprev - AVF[7 + 3 * NSPT -1]
        res = max(res, abs(PMb - PMprev))
        
# update "previous" concentrations, volumes, and potentials

        for I in range(1, NSPT + 1):
            Cprev[I-1, 1-1] = Cb[I-1, 1-1]
            Cprev[I-1, 2-1] = Cb[I-1, 2-1]
            Cprev[I-1, 5-1] = Cb[I-1, 5-1]

        phprev[0] = phb[0]
        Volprev[0] = Volb[0]
        EPprev[0] = EPb[0]
        
        phprev[1] = phb[1]
        Volprev[1] = Volb[1]
        EPprev[1] = EPb[1]

        phprev[4] = phb[4]
        Volprev[4] = Volb[4]
        EPprev[4] = EPb[4]

        PMprev = PMb
        
        if iterat >= 11:
            if iterat < 20:
                TOL = 1.0e-3
            else:
                TOL = res * 1.010
       
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Update concentrations at Lz + 1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72         

    for I in range(1, NSPT + 1):
        pt[Lz+1].conc[I-1, 1-1] = Cb[I-1, 1-1]
        pt[Lz+1].conc[I-1, 2-1] = Cb[I-1, 2-1]
        pt[Lz+1].conc[I-1, 5-1] = Cb[I-1, 5-1]

    pt[Lz+1].ph[1-1] = phb[1-1]
    pt[Lz+1].vol[1-1] = Volb[1-1]
    pt[Lz+1].ep[1-1] = EPb[1-1]

    pt[Lz+1].ph[2-1] = phb[2-1]
    pt[Lz+1].vol[2-1] = Volb[2-1]
    pt[Lz+1].ep[2-1] = EPb[2-1]

    pt[Lz+1].ph[5-1] = phb[5-1]
    pt[Lz+1].vol[5-1] = Volb[5-1]
    pt[Lz+1].ep[5-1] = EPb[5-1]
    
    pt[Lz+1].pres = PMb

    return
