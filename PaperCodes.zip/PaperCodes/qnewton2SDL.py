# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# sdlprev in the code is replaced by sdl[Lz]
# sdl in the code is replaced by sdl[Lz+1]

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** NEWTON SOLVER *************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This is the Newton solver used to determine the luminal and epithelial
# concentrations, volumes, and EP below the inlet
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 

def qnewton2SDL(sdl, Lz, idid, Vol0, ND, PTinitVol):
    
    Cb = np.zeros((NS, NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    AVF = np.zeros(ND)
    A = np.zeros((ND, ND))
    
    Cprev = np.zeros((NS, NC))
    Volprev = np.zeros(NC)
    EPprev = np.zeros(NC)
    phprev = np.zeros(NC)
    
    osmol = np.zeros(NC)
    
    num = 2 + NS2
    numpar = 8 + 4 * NS
    
    x = np.zeros(num)
    fvec = np.zeros(num)
    fjac = np.zeros((num, num))
    wa1 = np.zeros(num)
    wa2 = np.zeros(num)
    
    pars = np.zeros(numpar)
    
    pconv = 1.3
    
    lwork = 10000
    
    ipiv = np.zeros(ND)
    
    work = np.zeros(lwork)

    TOL = 1e-5  
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIAL GUESS: ASSUME SAME VALUES AS AT PREVIOUS STEP
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# store initial concentrations
# CPREV's are used in computing iteration residue
#---------------------------------------------------------------------72
    
    for k in range(1, NC-1+1):
        for i in range(1, NS+1):
            Cb[i-1, k-1] = sdl[Lz].conc[i-1, k-1]  # Cz(I,K,Lz)
            Cprev[i-1, k-1] = Cb[i-1, k-1]
            
        phb[k-1] = sdl[Lz].ph[k-1]
        phprev[k-1] = phb[k-1]
        
        Volb[k-1] = sdl[Lz].vol[k-1]
        Volprev[k-1] = Volb[k-1]
        
        EPb[k-1] = sdl[Lz].ep[k-1]
        EPprev[k-1] = EPb[k-1]

    PMb = sdl[Lz].pres  # PMz[Lz]
    PMprev = PMb
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# START ITERATION LOOP TO DETERMINE SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    res = 1.0
    iterat = 0

    while res > TOL and iterat < 21:
        res = 0.0
        iterat += 1
        
#---------------------------------------------------------------------72
# Create vector x of variables to solve for
#---------------------------------------------------------------------72

        for i in range(1, NS2 + 1):
            x[i-1] = Cb[i-1, 1-1]
            
        x[1 + NS2 - 1] = Volb[1 - 1]
        x[2 + NS2 - 1] = PMb
        
#---------------------------------------------------------------------72
# determine vector fvec of non-linear equations to be solved
# determine Jacobian matrix fjac corresponding to fvec
# fjac is a (NUxNU) matrix
#---------------------------------------------------------------------72
      
        ldfjac = num
        iflag = 1
        ml = num
        mu = num
        epsfcn = 1.0e-5
        
        pars[1:NS + 1] = sdl[Lz].conc[:, 1-1]  # Cz(:,1,Lz)
        pars[1 + NS:2*NS + 1] = sdl[Lz].conc[:, 2-1]  # Cz(:,2,Lz)
        pars[1 + 2*NS:3*NS + 1] = sdl[Lz].conc[:, 5-1]  # Cz(:,5,Lz)
        pars[1 + 3*NS - 1] = sdl[Lz].vol[1-1]
        pars[2 + 3*NS - 1] = sdl[Lz].vol[2-1]
        pars[3 + 3*NS - 1] = sdl[Lz].vol[5-1]
        pars[4 + 3*NS - 1] = sdl[Lz].pres  # PMz(Lz)
        pars[5 + 3*NS:4 + 4*NS + 1] = sdl[Lz].conc[:, 6-1]   # Cz(:,6,Lz)
        pars[5 + 4*NS - 1] = dimLSDL
        pars[6 + 4*NS - 1] = CPimprefSDL
        pars[7 + 4*NS - 1] = DiamSDL
        pars[8 + 4*NS - 1] = Vol0[1-1]


        from fcn2SDL import fcn2SDL
        fvec = fcn2SDL(num, x, iflag, numpar, pars, sdl, idid, Lz, PTinitVol)
        
        from jacobi2_2SDL import jacobi2_2SDL 
        fjac, wa1, fvec_J = jacobi2_2SDL(num, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, sdl, idid, Lz, PTinitVol)

        fjac_org = fjac

# # #---------------------------------------------------------------------72
# # # invert Jacobian matrix
# # #---------------------------------------------------------------------72

        fjac_n = fjac_org
        
        if np.linalg.det(fjac_n) >= 1:
            fjac_inv = np.linalg.inv(fjac_n)
            fjac = fjac_inv

#---------------------------------------------------------------------72
# Calculate AVF: product of fjac (inverted Jacobian) and fvec
#---------------------------------------------------------------------72

            for L in range(1, num + 1):
                AVF[L - 1] = 0.0
                for M in range(1, num + 1):
                    AVF[L-1] = AVF[L-1] + 1.0*fjac[L-1,M-1]*fvec[M-1]  # original = 0.200
                    # 
        else:
            
            for L in range(1, num + 1):
                AVF[L - 1] = 0.0
                for M in range(1, num + 1):
                    AVF[L-1] = AVF[L-1] + 0  # original = 0.200
                                
         
#---------------------------------------------------------------------72
# Calculate updated concentrations, volumes, and potentials
# Then update "old" values
#---------------------------------------------------------------------72

        for i in range(1, NS2 + 1):
            Cb[i-1, 1-1] = Cprev[i-1, 1-1] - AVF[i-1]
            
            if i == 14:  
                res = max(res, abs(Cb[i-1, 1-1] / Cprev[i-1, 1-1] - 1.0) * 0.1)
            else:
                res = max(res, abs(Cb[i-1, 1-1] / Cprev[i-1, 1-1] - 1.0))

        phb[1-1] = -np.log10(abs(Cb[12-1, 1-1] / 1e3))
        Volb[1-1] = Volprev[1-1] - AVF[1+ NS2 -1]
        res = max(res, abs(Volb[1-1] - Volprev[1-1]))

        PMb = PMprev - AVF[2+ NS2 -1]
        res = max(res, abs(PMb - PMprev))
        
        EPb[1-1] = EPprev[1-1] - AVF[4+ 3*NS2 -1]
        res = max(res, 1e-3 * abs(EPb[1-1] - EPprev[1-1]))
        
# update "previous" concentrations, volumes, and potentials        
        for i in range(1, NS + 1):
            Cprev[i-1, 1-1] = Cb[i-1, 1-1]
            Cprev[i-1, 2-1] = Cb[i-1, 2-1]
            Cprev[i-1, 5-1] = Cb[i-1, 5-1]

        PMprev = PMb
        phprev[0] = phb[0]
        Volprev[0] = Volb[0]
        EPprev[0] = EPb[0]
        
        if iterat >= 22:
            if iterat < 40:
                TOL = 1.0e-3
            else:
                TOL = res * 1.010

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Update concentrations at Lz + 1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    for i in range(1, NS + 1):
        sdl[Lz+1].conc[i-1, 1-1] = Cb[i-1, 1-1]
        sdl[Lz+1].conc[i-1, 2-1] = Cb[i-1, 2-1]
        sdl[Lz+1].conc[i-1, 5-1] = Cb[i-1, 5-1]

    sdl[Lz+1].vol[0] = Volb[0]
    sdl[Lz+1].pres = PMb
    sdl[Lz+1].ph[0] = -np.log10(abs(Cb[12-1, 1-1] / 1e3))
    
    if Lz == NZ - 1:
        for jz in range(NZ + 1):
            for i in range(1, NS + 1):
                sdl[jz].conc[i-1, 1-1] *= pconv
                
            sdl[jz].vol[1-1] /= pconv
            
    return 
