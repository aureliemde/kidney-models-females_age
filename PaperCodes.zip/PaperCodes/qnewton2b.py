# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# tube in Fortran means tube[Lz+1] 
# tubeprev in Fortran means tube[Lz] 

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** NEWTON SOLVER *************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This is the Newton solver used to determine the luminal and epithelial
# concentrations, volumes, and EP below the inlet
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 


def qnewton2b(tube, Vol0, Lz, idid, ND, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
        
    Cb = np.zeros((NS,NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    AVF = np.zeros(ND)
    A = np.zeros((ND,ND))
    
    Cprev = np.zeros((NS,NC)) 
    Volprev = np.zeros(NC)
    EPprev = np.zeros(NC) 
    phprev = np.zeros(NC)

    osmol = np.zeros(NC)
    
    num = 7 + 3 * NS2
    numpar = 8 + 5 * NS
    
    x = np.zeros(num)
    fvec = np.zeros(num)
    fjac = np.zeros((num,num))
    wa1 = np.zeros(num)
    wa2 = np.zeros(num)
    
    pars = np.zeros(numpar)
    
    lwork = 10000
    
    ipiv = np.zeros(ND)
    work = np.zeros(lwork)

    TOL = 1e-5
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIAL GUESS: ASSUME SAME VALUES AS AT PREVIOUS STEP
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# store initial concentrations
# CPREV's are used in computing iteration residue
#---------------------------------------------------------------------72

    for k in range(1, NC - 1 + 1):
        for i in range(1, NS + 1):
            Cb[i-1, k-1] = tube[Lz].conc[i-1, k-1]
            Cprev[i-1, k-1] = Cb[i-1, k-1]
        
        phb[k-1] = tube[Lz].ph[k-1]
        phprev[k-1] = phb[k-1]
        
        Volb[k-1] = tube[Lz].vol[k-1]
        Volprev[k-1] = Volb[k-1]
        
        EPb[k-1] = tube[Lz].ep[k-1]
        EPprev[k-1] = EPb[k-1]

    PMb = tube[Lz].pres
    PMprev = PMb

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# START ITERATION LOOP TO DETERMINE SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

    res = 1.0
    iterat = 0

    while res > TOL and iterat < 21:
        res = 0.0
        iterat += 1

#---------------------------------------------------------------------72
# Create vector x of variables to solve for
#---------------------------------------------------------------------72

        for i in range(1, NS2 + 1):
            x[1 + 3 * (i - 1) - 1] = Cb[i-1, 1-1]
            x[2 + 3 * (i - 1) - 1] = Cb[i-1, 2-1]
            x[3 + 3 * (i - 1) - 1] = Cb[i-1, 5-1]
            
        x[1+ 3*NS2 -1] = Volb[1 -1]
        x[2+ 3*NS2 -1] = Volb[2 -1]
        x[3+ 3*NS2 -1] = Volb[5 -1]
        x[4+ 3*NS2 -1] = EPb[1 -1]
        x[5+ 3*NS2 -1] = EPb[2 -1]
        x[6+ 3*NS2 -1] = EPb[5 -1]
        x[7+ 3*NS2 -1] = PMb

#---------------------------------------------------------------------72
# determine vector fvec of non-linear equations to be solved
# determine Jacobian matrix fjac corresponding to fvec
# fjac is a (NUxNU) matrix
#---------------------------------------------------------------------72

        ldfjac = num
        iflag = 1
        ml = num
        mu = num
        epsfcn = 1.0e-5
        
        pars[1 -1:NS +1 -1] = tube[Lz].conc[:,1 -1]
        pars[1+NS -1:2*NS + 1 -1] = tube[Lz].conc[:,2 -1]
        pars[1+2*NS -1:3*NS + 1 -1] = tube[Lz].conc[:,5 -1]
        pars[1+3*NS -1] = tube[Lz].vol[1 -1]
        pars[2+3*NS -1] = tube[Lz].vol[2 -1]
        pars[3+3*NS -1] = tube[Lz].vol[5 -1]
        pars[4+3*NS -1] = tube[Lz].pres
        pars[5+3*NS -1:4+ 4*NS + 1 -1] = tube[Lz].conc[:,6 -1]
        pars[5+4*NS -1:4+ 5*NS + 1 -1] = tube[Lz+1].conc[:,6 -1]
        pars[5+5*NS -1] = tube[Lz+1].ep[6-1]
        
        if idid == 3: #mTAL
            pars[6+ 5*NS -1] = dimLA
            pars[7+ 5*NS -1] = CPimprefA
            pars[8+ 5*NS -1] = DiamA
            
        elif idid == 4: #cTAL
            pars[6+ 5*NS -1] = dimLT
            pars[7+ 5*NS -1] = CPimprefT
            pars[8+ 5*NS -1] = DiamT
            
        elif idid == 5: # DCT
            pars[6+ 5*NS -1] = dimLD
            pars[7+ 5*NS -1] = CPimprefD
            pars[8+ 5*NS -1] = DiamD
            
        elif idid == 9: # IMCD
            pars[6+ 5*NS -1] = dimLIMC
            pars[7+ 5*NS -1] = CPimprefIMC
            pars[8+ 5*NS -1] = DiamIMC
                  
        from fcn2b import fcn2b
        fvec = fcn2b(num, x, iflag, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
        
        from jacobi2_2b import jacobi2_2b
        fjac, wa1, fvec_J = jacobi2_2b(num, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)

        fjac_org = fjac
        
# # #---------------------------------------------------------------------72
# # # invert Jacobian matrix
# # #---------------------------------------------------------------------72

        fjac_n = fjac_org
        fjac_inv = np.linalg.inv(fjac_n)
        fjac = fjac_inv
        
#---------------------------------------------------------------------72
# Calculate AVF: product of fjac (inverted Jacobian) and fvec
#---------------------------------------------------------------------
        
        for L in range(1, num + 1):
            AVF[L - 1] = 0.0
            for M in range(1, num + 1):
                if idid == 9:
                    AVF[L-1] = AVF[L-1] + 1.0*fjac[L-1,M-1]*fvec[M-1]  # original = 0.500
                else:
                    AVF[L-1] = AVF[L-1] + 1.0*fjac[L-1,M-1]*fvec[M-1]  # original = 0.250

#---------------------------------------------------------------------72
# Calculate updated concentrations, volumes, and potentials
# Then update "old" values
#---------------------------------------------------------------------72
   
        for I in range(1, NS2 + 1):
            Cb[I-1, 1-1] = np.abs( Cprev[I-1, 1-1] - AVF[1 + 3*(I-1) -1] )
            Cb[I-1, 2-1] = np.abs( Cprev[I-1, 2-1] - AVF[2 + 3*(I-1) -1] )
            Cb[I-1, 5-1] = np.abs( Cprev[I-1, 5-1] - AVF[3 + 3*(I-1) -1] )
            
            if I == 14:
                res = max(res, 0.01 * abs(Cb[I-1, 1-1] / Cprev[I-1, 1-1] - 1.0))
                res = max(res, 0.01 * abs(Cb[I-1, 2-1] / Cprev[I-1, 2-1] - 1.0))
                res = max(res, 0.01 * abs(Cb[I-1, 5-1] / Cprev[I-1, 5-1] - 1.0))
            
            else:
                res = max(res, abs(Cb[I-1, 1-1] / Cprev[I-1, 1-1] - 1.0))
                res = max(res, abs(Cb[I-1, 2-1] / Cprev[I-1, 2-1] - 1.0))
                res = max(res, abs(Cb[I-1, 5-1] / Cprev[I-1, 5-1] - 1.0))
            
            if Cb[I-1, 2-1] <= 0.0 or Cb[I-1, 5-1] <= 0.0:  # Python uses 0-based indexing
                print("Warning in newton2b", I-1, Cb[I-1, 2-1], Cb[I-1, 5-1])
    
        phb[1-1] = -np.log10(Cb[12-1, 1-1] / 1.0e3)
        phb[2-1] = -np.log10(Cb[12-1, 2-1] / 1.0e3)
        phb[5-1] = -np.log10(Cb[12-1, 5-1] / 1.0e3)
        
        Volb[1-1] = Volprev[1-1] - AVF[1 + 3 * NS2 -1]
        res = max(res, abs(Volb[1-1] - Volprev[1-1]))
        
        Volb[2-1] = Volprev[2-1] - AVF[2 + 3 * NS2 -1]
        res = max(res, abs(Volb[2-1] - Volprev[2-1]))
        
        Volb[5-1] = Volprev[5-1] - AVF[3 + 3 * NS2 -1]
        res = max(res, abs(Volb[5-1] - Volprev[5-1]))
        

        EPb[1-1] = EPprev[1-1] - AVF[4 + 3 * NS2 -1]
        res = max(res, 1.0e-3 * abs(EPb[1-1] - EPprev[1-1]))
        EPb[2-1] = EPprev[2-1] - AVF[5 + 3 * NS2 -1]
        res = max(res, 1.0e-3 * abs(EPb[2-1] - EPprev[2-1]))
        EPb[5-1] = EPprev[5-1] - AVF[6 + 3 * NS2 -1]
        res = max(res, 1.0e-3 * abs(EPb[5-1] - EPprev[5-1]))
        
        PMb = PMprev - AVF[7 + 3 * NS2 -1]
        res = max(res, abs(PMb - PMprev))
        
# update "previous" concentrations, volumes, and potentials

        for I in range(1, NS + 1):
            Cprev[I-1, 1-1] = Cb[I-1, 1-1]
            Cprev[I-1, 2-1] = Cb[I-1, 2-1]
            Cprev[I-1, 5-1] = Cb[I-1, 5-1]

        phprev[0] = phb[0]
        Volprev[0] = Volb[0]
        EPprev[0] = EPb[0]
        
        phprev[1] = phb[1]
        Volprev[1] = Volb[1]
        EPprev[1] = EPb[1]

        phprev[4] = phb[4]
        Volprev[4] = Volb[4]
        EPprev[4] = EPb[4]

        PMprev = PMb
        
        if iterat >= 11:
            if iterat < 21:
                TOL = 1.0e-4          

            elif iterat < 31:
                TOL = 1.0e-3            
            
            else:
                TOL = res * 1.010
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Update concentrations at Lz + 1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for I in range(1, NS + 1):
        tube[Lz+1].conc[I-1, 1-1] = Cb[I-1, 1-1]
        tube[Lz+1].conc[I-1, 2-1] = Cb[I-1, 2-1]
        tube[Lz+1].conc[I-1, 5-1] = Cb[I-1, 5-1]

    tube[Lz+1].ph[1-1] = phb[1-1]
    tube[Lz+1].vol[1-1] = Volb[1-1]
    tube[Lz+1].ep[1-1] = EPb[1-1]

    tube[Lz+1].ph[2-1] = phb[2-1]
    tube[Lz+1].vol[2-1] = Volb[2-1]
    tube[Lz+1].ep[2-1] = EPb[2-1]

    tube[Lz+1].ph[5-1] = phb[5-1]
    tube[Lz+1].vol[5-1] = Volb[5-1]
    tube[Lz+1].ep[5-1] = EPb[5-1]
    
    tube[Lz+1].pres = PMb
    
    return
