# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# tube in Fortran means tube[Lz+1] 
# tubeprev in Fortran means tube[Lz] 

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# *************************** NEWTON SOLVER *************************
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# This is the Newton solver used to determine the luminal and epithelial
# concentrations, volumes, and EP below the inlet
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72

import numpy as np

from values import *
from glo import *
from defs import * 


def qnewton2icb(tube, Lz, idid, Vol0, VolEinit, VolPinit, VolAinit, VolBinit, ND, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT):
        
    Cb = np.zeros((NS,NC))
    Volb = np.zeros(NC)
    EPb = np.zeros(NC)
    phb = np.zeros(NC)
    
    AVF = np.zeros(NDC)
    A = np.zeros((NDC,NDC))
    
    Cprev = np.zeros((NS,NC)) 
    Volprev = np.zeros(NC)
    EPprev = np.zeros(NC) 
    phprev = np.zeros(NC)

    osmol = np.zeros(NC)
    
    numpar = 1 + (NC-1) * (NS+2)
    pars = np.zeros(numpar)
    
    num = 11 + 5 * NS2
    
    x = np.zeros(num)
    fvec = np.zeros(num)
    fjac = np.zeros((num,num))
    wa1 = np.zeros(num)
    wa2 = np.zeros(num)
        
    lwork = 10000
    
    ipiv = np.zeros(NDC)
    
    work = np.zeros(lwork)

    TOL = 1e-5
    
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# INITIAL GUESS: ASSUME SAME VALUES AS AT PREVIOUS STEP
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# store initial concentrations
# CPREV's are used in computing iteration residue
#---------------------------------------------------------------------72

    for k in range(1, NC - 1 + 1):
        for i in range(1, NS + 1):
            Cb[i-1, k-1] = tube[Lz].conc[i-1, k-1]
            Cprev[i-1, k-1] = Cb[i-1, k-1]
        
        phb[k-1] = tube[Lz].ph[k-1]
        phprev[k-1] = phb[k-1]
        
        Volb[k-1] = tube[Lz].vol[k-1]
        Volprev[k-1] = Volb[k-1]
        
        EPb[k-1] = tube[Lz].ep[k-1]
        EPprev[k-1] = EPb[k-1]

    PMb = tube[Lz].pres  
    PMprev = PMb

#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# START ITERATION LOOP TO DETERMINE SOLUTION
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
    
    nwrite = 0
    res = 1.0
    iterat = 0

    while res > TOL and iterat < 21:
        res = 0.0
        iterat += 1

#---------------------------------------------------------------------72
# Create vector x of variables to solve for
#---------------------------------------------------------------------72

        for i in range(1, NS2 + 1):
            x[1 + 5 * (i - 1) - 1] = Cb[i-1, 1-1]
            x[2 + 5 * (i - 1) - 1] = Cb[i-1, 2-1]
            x[3 + 5 * (i - 1) - 1] = Cb[i-1, 3-1]
            x[4 + 5 * (i - 1) - 1] = Cb[i-1, 4-1]
            x[5 + 5 * (i - 1) - 1] = Cb[i-1, 5-1]
        
        for j in range(1, NC - 1 + 1):
            x[j + 5*NS2 -1] = Volb[j -1]
            x[j + 5*NS2 +5 -1] = EPb[j -1]
        
        x[11 + 5*NS2 -1] = PMb

#---------------------------------------------------------------------72
# determine vector fvec of non-linear equations to be solved
# determine Jacobian matrix fjac corresponding to fvec
# fjac is a (NUxNU) matrix
#---------------------------------------------------------------------72

        ldfjac = num
        iflag = 1
        ml = num
        mu = num
        epsfcn = 1.0e-5
        
        for k in range(1, NC - 1 + 1):
            for i in range(1, NS + 1):
                pars[i + (k-1)*NS -1] = tube[Lz].conc[i-1, k-1]
        
        for k in range(1, NC - 1 + 1):
            pars[k + (NC-1)*NS -1] = tube[Lz].vol[k-1]
                
        for k in range(1, NC - 1 + 1):
            pars[k + (NC-1)*(NS+1) -1] = tube[Lz].ep[k-1]
                
        pars[1 + (NC-1)*(NS+2) -1] = tube[Lz].pres   
        
        if idid == 6: 
            from fcn2C import fcn2C
            fvec = fcn2C(num, x, iflag, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
            
            from jacobi2_2icb import jacobi2_2icb
            fjac, wa1, fvec_J = jacobi2_2icb(num, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)

        elif idid == 7: 
            from fcn2C import fcn2C
            fvec = fcn2C(num, x, iflag, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
            
            from jacobi2_2icb import jacobi2_2icb
            fjac, wa1, fvec_J = jacobi2_2icb(num, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)

        elif idid == 8: 
            from fcn2OMC import fcn2OMC
            fvec = fcn2OMC(num, x, iflag, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)
            
            from jacobi2_2icbOMC import jacobi2_2icbOMC
            fjac, wa1, fvec_J = jacobi2_2icbOMC(num, x, fvec, ldfjac, iflag, epsfcn, numpar, pars, tube, idid, Lz, PTinitVol, xNaPiIIaPT, xNaPiIIcPT, xPit2PT)

        fjac_org = fjac
        
# # #---------------------------------------------------------------------72
# # # invert Jacobian matrix
# # #---------------------------------------------------------------------72

        fjac_n = fjac_org
        fjac_inv = np.linalg.inv(fjac_n)
        fjac = fjac_inv
        
#---------------------------------------------------------------------72
# Calculate AVF: product of fjac (inverted Jacobian) and fvec
#---------------------------------------------------------------------
        
        for L in range(1, num + 1):
            AVF[L - 1] = 0.0
            if idid == 7:  # CCD
                for M in range(1, num + 1):
                    AVF[L-1] = AVF[L-1] + 0.50*fjac[L-1,M-1]*fvec[M-1]  
            else:
                for M in range(1, num + 1):
                    AVF[L-1] = AVF[L-1] + 0.50*fjac[L-1,M-1]*fvec[M-1]  
        
#---------------------------------------------------------------------72
# Calculate updated concentrations, volumes, and potentials
# Then update "old" values
#---------------------------------------------------------------------72
   
        for I in range(1, NS2 + 1):
            Cb[I-1, 1-1] = np.abs( Cprev[I-1, 1-1] - AVF[1 + 5*(I-1) -1] )
            Cb[I-1, 2-1] = np.abs( Cprev[I-1, 2-1] - AVF[2 + 5*(I-1) -1] )
            Cb[I-1, 3-1] = np.abs( Cprev[I-1, 3-1] - AVF[3 + 5*(I-1) -1] )
            Cb[I-1, 4-1] = np.abs( Cprev[I-1, 4-1] - AVF[4 + 5*(I-1) -1] )
            Cb[I-1, 5-1] = np.abs( Cprev[I-1, 5-1] - AVF[5 + 5*(I-1) -1] )
            
            if I == 14:
                res = max(res, 0.01 * abs(Cb[I-1, 1-1] / Cprev[I-1, 1-1] - 1.0))
                res = max(res, 0.01 * abs(Cb[I-1, 2-1] / Cprev[I-1, 2-1] - 1.0))
                res = max(res, 0.01 * abs(Cb[I-1, 3-1] / Cprev[I-1, 3-1] - 1.0))
                res = max(res, 0.01 * abs(Cb[I-1, 4-1] / Cprev[I-1, 4-1] - 1.0))
                res = max(res, 0.01 * abs(Cb[I-1, 5-1] / Cprev[I-1, 5-1] - 1.0))
            
            else:
                res = max(res, abs(Cb[I-1, 1-1] / Cprev[I-1, 1-1] - 1.0))
                res = max(res, abs(Cb[I-1, 2-1] / Cprev[I-1, 2-1] - 1.0))
                res = max(res, abs(Cb[I-1, 3-1] / Cprev[I-1, 3-1] - 1.0))
                res = max(res, abs(Cb[I-1, 4-1] / Cprev[I-1, 4-1] - 1.0))
                res = max(res, abs(Cb[I-1, 5-1] / Cprev[I-1, 5-1] - 1.0))
            
            for K in range(1, 5 + 1):
                if Cb[I-1, K-1] <= 0.0:  
                    print("Warning in newton2icb", I-1, K-1, Cb[I-1, K-1])

        for J in range(1, 5 + 1):
            phb[J-1] = -np.log10( Cb[12-1, J-1] / 1.0e3 )
            Volb[J-1] = Volprev[J-1] - AVF[J + 5*NS2 -1]
            res = max( res , abs( Volb[J-1] - Volprev[J-1] ) )
            EPb[J-1] = EPprev[J-1] - AVF[J + 5 + 5*NS2 -1]
            res = max( res , 1e-3 * abs( EPb[J-1] - EPprev[J-1] ) )

        PMb = PMprev - AVF[11 + 5*NS2 -1]
        res = max( res, abs( PMb - PMprev ) )
        
# update "previous" concentrations, volumes, and potentials
        
        for K in range(1, 5 + 1):
            for I in range(1, NS + 1):
                Cprev[I-1, K-1] = Cb[I-1, K-1]        
       
            phprev[K-1] = phb[K-1]
            Volprev[K-1] = Volb[K-1]
            EPprev[K-1] = EPb[K-1]

        PMprev = PMb
        
        if iterat >= 11:
            if iterat < 21:
                TOL = 1.0e-4          

            elif iterat < 31:
                TOL = 1.0e-3            
            
            else:
                TOL = res * 1.010
        
#---------------------------------------------------------------------72
#---------------------------------------------------------------------72
# Update concentrations at Lz + 1
#---------------------------------------------------------------------72
#---------------------------------------------------------------------

    for K in range(1, 5 + 1):
        for I in range(1, NS + 1):
            tube[Lz+1].conc[I-1, K-1] = Cb[I-1, K-1]
            
        tube[Lz+1].ph[K-1] = phb[K-1]
        tube[Lz+1].vol[K-1] = Volb[K-1]
        tube[Lz+1].ep[K-1] = EPb[K-1]
    
    tube[Lz+1].pres = PMb
    
    return
