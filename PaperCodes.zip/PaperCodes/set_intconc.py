# Written originally in Fortran by Prof. Aurelie Edwards
# Translated to Python by Dr. Mohammad M. Tajdini

# Department of Biomedical Engineering
# Boston University 

###################################################

# This subroutine sets interstitial concentrations for a given nephron segment

import numpy as np

from values import *
from glo import *
from defs import * 

def set_intconc(tube, iN, ireg, pos):
    
# bdiabetes # true if simulating a diabetic kidney
# furo # true in the presence of furosemide

    if ireg == 1:  # cortex
    
        tube[0].ph[5] = 7.323
        
        facbic = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHCO3))
        facpot = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHPO4))
        facamm = np.exp(np.log(10.0) * (tube[0].ph[5] - pKNH3))
        fachco2 = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHCO2))

        for j in range(iN + 1):
            tube[j].ph[5] = tube[0].ph[5]

            tube[j].conc[0, 5] = TotSodCM
            tube[j].conc[1, 5] = TotPotCM
            tube[j].conc[2, 5] = TotCloCM
            tube[j].conc[3, 5] = TotBicCM
            tube[j].conc[4, 5] = TotHcoCM
            tube[j].conc[5, 5] = TotCo2CM

            tube[j].conc[6, 5] = TotPhoCM * facpot / (1.0 + facpot)
            tube[j].conc[7, 5] = TotPhoCM / (1.0 + facpot)

            tube[j].conc[8, 5] = TotureaCM

            Ammtotz = (TotAmmCT + (TotAmmCM - TotAmmCT) * pos[j])
            tube[j].conc[2, 5] = TotCloCM + (Ammtotz - TotAmmCM)
            tube[j].conc[9, 5] = Ammtotz * facamm / (1.0 + facamm)
            tube[j].conc[10, 5] = Ammtotz / (1.0 + facamm)

            tube[j].conc[11, 5] = np.exp(-np.log(10.0) * tube[j].ph[5]) * 1e3  # Convert to mM

            tube[j].conc[12, 5] = TotHco2CM * fachco2 / (1.0 + fachco2)
            tube[j].conc[13, 5] = TotHco2CM / (1.0 + fachco2)

            tube[j].conc[14, 5] = TotgluCM

            tube[j].conc[15, 5] = TotCaCM

            # Set chloride concentration so as to satisfy electroneutrality
            ElecS = 0.0
            for i in range(1, NS + 1):  
                ElecS += zval[i-1] * tube[j].conc[i-1, 6-1]
            tube[j].conc[2, 5] += ElecS

    elif ireg == 2:  # OM
    
        tube[0].ph[5] = 7.323
        
        facbic = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHCO3))
        facpho = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHPO4))
        facamm = np.exp(np.log(10.0) * (tube[0].ph[5] - pKNH3))
        fachco2 = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHCO2))

        for j in range(iN + 1):
            tube[j].ph[5] = tube[0].ph[5]

            tube[j].conc[0, 5] = TotSodCM + (TotSodOI - TotSodCM) * pos[j]
            tube[j].conc[1, 5] = TotPotCM + (TotPotOI - TotPotCM) * pos[j]
            tube[j].conc[2, 5] = TotCloCM + (TotCloOI - TotCloCM) * pos[j]
            tube[j].conc[3, 5] = TotBicCM + (TotBicOI - TotBicCM) * pos[j]
            tube[j].conc[4, 5] = TotHcoCM + (TotHcoOI - TotHcoCM) * pos[j]
            tube[j].conc[5, 5] = TotCo2CM + (TotCo2OI - TotCo2CM) * pos[j]

            Phototz = (TotPhoCM + (TotPhoOI - TotPhoCM) * pos[j])
            tube[j].conc[6, 5] = Phototz * facpho / (1.0 + facpho)
            tube[j].conc[7, 5] = Phototz / (1.0 + facpho)

            tube[j].conc[8, 5] = TotureaCM + (TotureaOI - TotureaCM) * pos[j]

            Ammtotz = TotAmmCM + (TotAmmOI - TotAmmCM) * pos[j]
            tube[j].conc[9, 5] = Ammtotz * facamm / (1.0 + facamm)
            tube[j].conc[10, 5] = Ammtotz / (1.0 + facamm)

            tube[j].conc[11, 5] = np.exp(-np.log(10.0) * tube[j].ph[5]) * 1e3  # Convert to mM

            Hco2totz = TotHco2CM + (TotHco2OI - TotHco2CM) * pos[j]
            tube[j].conc[12, 5] = Hco2totz * fachco2 / (1.0 + fachco2)
            tube[j].conc[13, 5] = Hco2totz / (1.0 + fachco2)

            tube[j].conc[14, 5] = TotgluCM + (TotGluOI - TotgluCM) * pos[j]

            tube[j].conc[15, 5] = TotCaCM + (TotCaOI - TotCaCM) * pos[j]

            # Set chloride concentration so as to satisfy electroneutrality
            ElecS = 0.0
            for i in range(1, NS + 1):  
                ElecS += zval[i-1] * tube[j].conc[i-1, 6-1]
            tube[j].conc[2, 5] += ElecS

    elif ireg == 3:  # IM
    
        tube[0].ph[5] = 7.323
        
        facbic = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHCO3))
        facpho = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHPO4))
        facamm = np.exp(np.log(10.0) * (tube[0].ph[5] - pKNH3))
        fachco2 = np.exp(np.log(10.0) * (tube[0].ph[5] - pKHCO2))

        for j in range(iN + 1):
            tube[j].ph[5] = tube[0].ph[5]

            tube[j].conc[0, 5] = TotSodOI + (TotSodPap - TotSodOI) * pos[j]
            tube[j].conc[1, 5] = TotPotOI + (TotPotPap - TotPotOI) * pos[j]
            tube[j].conc[2, 5] = TotCloOI + (TotCloPap - TotCloOI) * pos[j]
            tube[j].conc[3, 5] = TotBicOI + (TotBicPap - TotBicOI) * pos[j]
            tube[j].conc[4, 5] = TotHcoOI + (TotHcoPap - TotHcoOI) * pos[j]
            tube[j].conc[5, 5] = TotCo2OI + (TotCo2Pap - TotCo2OI) * pos[j]

            Phototz = (TotPhoOI + (TotPhoPap - TotPhoOI) * pos[j])
            tube[j].conc[6, 5] = Phototz * facpho / (1.0 + facpho)
            tube[j].conc[7, 5] = Phototz / (1.0 + facpho)

            tube[j].conc[8, 5] = TotureaOI + (TotureaPap - TotureaOI) * pos[j]

            Ammtotz = TotAmmOI + (TotAmmPap - TotAmmOI) * pos[j]
            tube[j].conc[9, 5] = Ammtotz * facamm / (1.0 + facamm)
            tube[j].conc[10, 5] = Ammtotz / (1.0 + facamm)

            tube[j].conc[11, 5] = np.exp(-np.log(10.0) * tube[0].ph[5]) * 1e3

            Hco2totz = TotHco2OI + (TotHco2Pap - TotHco2OI) * pos[j]
            tube[j].conc[12, 5] = Hco2totz * fachco2 / (1.0 + fachco2)
            tube[j].conc[13, 5] = Hco2totz / (1.0 + fachco2)

            tube[j].conc[14, 5] = TotGluOI + (TotGluPap - TotGluOI) * pos[j]

            tube[j].conc[15, 5] = TotCaOI + (TotCaPap - TotCaOI) * pos[j]

            # Set chloride concentration so as to satisfy electroneutrality
            ElecS = 0.0
            for i in range(1, NS + 1):  
                ElecS += zval[i-1] * tube[j].conc[i-1, 6-1]
            tube[j].conc[2, 5] += ElecS

    else:
        print("wrong region ID")
